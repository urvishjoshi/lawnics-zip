// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyBHwGSw1Vx3ZRRhElbogopV4UstwkOgyVc",
    authDomain: "lawnicstech-f06bc.firebaseapp.com",
    databaseURL: "https://lawnicstech-f06bc.firebaseio.com",
    projectId: "lawnicstech-f06bc",
    storageBucket: "lawnicstech-f06bc.appspot.com",
    messagingSenderId: "920443516161",
    appId: "1:920443516161:web:280c1dc216439b6ef65700",
    measurementId: "G-PB65Z99GSJ"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();