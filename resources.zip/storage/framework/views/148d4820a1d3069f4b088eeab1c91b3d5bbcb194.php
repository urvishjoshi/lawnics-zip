
<?php $__env->startSection('title','Area'); ?>
<?php $__env->startSection('content'); ?>
<section>
<?php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; ?>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Area</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="<?php echo e(route('o.areas.show','add')); ?>" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Map</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>District</th>
                            <th>City</th>
                            <th>Area name</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($locations<1): ?>
                        <tr>
                            <td colspan="7"><h3>No Areas created yet</h3></td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($state)): ?> <?php continue; ?> <?php endif; ?>
                        <?php $__currentLoopData = $s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($district)): ?> <?php continue; ?> <?php endif; ?>
                        <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($city)): ?> <?php continue; ?> <?php endif; ?>
                        <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($key)): ?> <?php continue; ?> <?php endif; ?>
                            <tr>
                                <td><i class="fas fa-map-marked-alt"></i></td>
                                <td>India</td>
                                <td><?php echo e($state); ?></td>
                                <td><?php echo e($district); ?></td>
                                <td><?php echo e($city); ?></td>
                                <th value="<?php echo e($key); ?>"><?php echo e($area['area']); ?></th>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('o.areas.show','edit?id='.$key)); ?>" class="btn btn-sm btn-dark"><i class="fas fa-pen"></i> Edit</a>
                                        <form action="<?php echo e(route('o.areas.destroy',$key)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="state" value="<?php echo e($state); ?>">
                                            <input type="hidden" name="district" value="<?php echo e($district); ?>">
                                            <input type="hidden" name="city" value="<?php echo e($city); ?>">
                                            <input type="hidden" name="area" value="<?php echo e($area['area']); ?>">
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<?php echo $__env->make('admin.layouts.assets.locationsModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('jquery'); ?>
<?php echo $__env->make('admin.layouts.assets.allLocationsAjax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();

        $('#cancel').click(function (event) {
            $('tbody tr*').show();
        });

        $('#apply').click(function (event) {
            $('tbody tr').each(function() {
                if (stateFilter($(this)) && districtFilter($(this)) && cityFilter($(this)) && areaFilter($(this)))
                    $(this).show();
                else $(this).hide();
            });
        });
        function stateFilter(tr) {
            var state = $('#SAstate').val(), flag=false; if (state=='') return true;
            for (var i = 0; i < state.length; i++) {
                if ( strcmp( tr.find("td").eq(2).text(), state[i] ) ) flag = true;
            } return flag;
        }
        function districtFilter(tr) {
            var district = $('#SAdistrict').val(), flag=false; if (district=='') return true;
            for (var i = 0; i < district.length; i++) {
                if ( strcmp( tr.find("td").eq(3).text(), district[i] ) ) flag = true;
            } return flag;
        }
        function cityFilter(tr) {
            var city = $('#SAcity').val(), flag=false; if (city=='') return true;
            for (var i = 0; i < city.length; i++) {
                if ( strcmp( tr.find("td").eq(4).text(), city[i] ) ) flag = true;
            } return flag;
        }
        function areaFilter(tr) {
            var area = $('#SAarea').val(), flag=false; if (area=='') return true;
            for (var i = 0; i < area.length; i++) {
                if ( strcmp( tr.find("th").attr('value'), area[i] ) ) flag = true;
            } return flag;
        }
        //__str compare__
        function strcmp(str1='', str2='') {
            if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
            return false;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Work\adminLawnics\resources\views/admin/operation/area/dashboard.blade.php ENDPATH**/ ?>