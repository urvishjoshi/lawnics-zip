
<?php $__env->startSection('title','Order - Operations'); ?>
<?php $__env->startSection('content'); ?>
<style>h3{color: white;margin:0;}</style>
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card-header pt-3 pl-3 ">
				<div class="">
					<div class="row text-white">
						<div class="col-lg-2">
							<h6 class="heading-small text-muted mb-0">Order Id</h6>
							<h3><?php echo e($id); ?></h3>
						</div>
						<div class="col-lg-2">
							<h6 class="heading-small text-muted mb-0">Order type</h6>
							<h3><?php echo e($order['order_type'] ??'N/A'); ?></h3>
						</div>
						<div class="col-lg-8 d-flex justify-content-end align-items-end">
							<button class="btn btn-sm btn-primary">Complete</button>
							<button class="btn btn-sm btn-primary">Cancel</button>
						</div>
					</div>
						<hr class="mt-3 mb-3 text-white" style="border: 0.5px solid white;">
						<h3>Status</h3>
				</div>
			</div>
			<?php $status=0;
				if(strtolower($order['status']??'N/A')=='pending') $status=2;
				elseif(strtolower($order['status']??'N/A')=='printed') $status=3;
				$d = explode('_',$date); 
			?>
			<div class="card-body pt-4 pl-3">
				<div class="text-center">
					<div class="row">
						<div class="col">
							<i class="fas fa-shopping-cart <?php echo e($status>0?'text-success':''); ?>"></i>
							<h4>Order</h4>
							<h5><?php echo e($d[2].'/'.$d[1].'/'.$d[0]); ?></h5>
							<h5>10:30 AM</h5>
						</div>
						<div class="col">
							<i class="fas fa-print <?php echo e($status>1?'text-success':''); ?>"></i>
							<h4>Printing</h4>
							<h5>03/01/2020</h5>
							<h5>10:30 AM</h5>
						</div>
						<div class="col">
							<i class="fas fa-hourglass-half <?php echo e($status>2?'text-success':''); ?>"></i>
							<h4>Printed</h4>
							<h5>Estimated time</h5>
							<h5>30 min</h5>
						</div>
						<div class="col">
							<i class="fas fa-truck <?php echo e($status>3?'text-success':''); ?>"></i>
							<h4>Delivery</h4>
							<h5>Estimated time</h5>
							<h5>30 min</h5>
						</div>
						<div class="col">
							<i class="fas fa-check-circle <?php echo e($status>4?'text-success':''); ?>"></i>
							<h4>Delivered</h4>
							<h5>Estimated time</h5>
							<h5>30 min</h5>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Items</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Document ID
		                    <th>Document name
		                    <th>Quantity
		                    <th>Paper type
		                    <th>Total pages
		                    <th>Credits
	                    </tr>
	                </thead>
	                <tbody> <?php $total=0; ?>
	                <?php if(is_array($order)): ?>
		                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <?php if(is_array($doc)): ?> <?php $total+=$doc['credits']??0; ?>
		                	<tr>
			                    <th><?php echo e($doc['filename']??'N/A'); ?>

			                    <td><?php echo e($doc['filename']??'N/A'); ?>

			                    <td><?php echo e($doc['copies']??'N/A'); ?>

			                    <td><?php echo e(($doc['paper_color']??'N/A').' '.($doc['paper_size']??'N/A').' '.($doc['gsm']??'N/A')); ?>

			                    <td><?php echo e($doc['pages']??'N/A'); ?>

			                    <td><?php echo e($doc['credits']??'N/A'); ?>

		                    </tr>
	                    <?php endif; ?>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            <?php endif; ?>
	                    <tr>
	                    	<td colspan="6">
				            	<span class="btn btn-sm btn-dark" style="float: right;"><?php echo e($total); ?></span>
	                    	</td>
	                    </tr>
	                </tbody>
	            </table>
	        </div>
	    </div>
	    <div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">User</h3>
					</div>
				</div>
			</div>
			<div class="card-body px-5">
				<div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Name</h6>
						<h4><?php echo e(($user['first_name']??'N/A').' '.($user['last_name']??'N/A')); ?></h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">ID</h6>
						<h4><?php echo e($key); ?></h4>
					</div>
		        </div>
		        <div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Mobile number</h6>
						<h4><?php echo e($phone??'N/A'); ?></h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Rating by printing partner</h6>
						<?php for($i = 0; $i < 5; ++$i): ?>
						    <i class="font-20 fas fa-star"></i>
						<?php endfor; ?>
					</div>
		        </div>
		        <div class="row">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Reviews</h6>
						<h4 style="padding: 5px;border: 1px solid lightgrey;border-radius: 5px;width: fit-content;">Paper quality</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Comments</h6>
						<h4>Nice service</h4>
					</div>
		        </div>
	    	</div>
	    </div>
	    <div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Printing Partner</h3>
					</div>
				</div>
			</div>
			<div class="card-body px-5">
				<div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Name</h6>
						<h4><?php echo e($order['printing_partner_name']??'N/A'); ?></h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Shop address</h6>
						<h4><?php echo e($order['printing_partner_location']??'N/A'); ?></h4>
					</div>
		        </div>
		        <div class="row">
					<div class="col-md-6">
						<h6 class="heading-small text-muted mb-0">Mobile number</h6>
						<h4><?php echo e($phone['printing_partner_phone']??'N/A'); ?></h4>
					</div>
		        </div>
		    </div>
	    </div>
	    <div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Delivery</h3>
					</div>
				</div>
			</div>
			<div class="card-body px-5">
				<div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Name</h6>
						<h4>ABC DEF</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Mobile number</h6>
						<h4>987456321</h4>
					</div>
		        </div>
		        <div class="row">
					<div class="col-md-6">
						<h6 class="heading-small text-muted mb-0">Gender</h6>
						<h4>Male</h4>
					</div>
		        </div>
		    </div>
	    </div>
	</div>
	
</section>

<?php $__env->startSection('jquery'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\adminLawnics\resources\views/admin/operation/order/order.blade.php ENDPATH**/ ?>