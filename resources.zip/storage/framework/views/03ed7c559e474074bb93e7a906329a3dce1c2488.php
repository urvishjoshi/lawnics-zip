
<?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('content'); ?>
<section>
    <!-- Reports Header -->
    <div class="m-3">
        <!-- Page content -->
        <div class="">
          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-header border-0 p-3">
                  <div class="row align-items-center">
                    <div class="col">
                      <h3 class="mb-0 mx-1">Users</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="<?php echo e(route('t.users.show','reports')); ?>" class="btn btn-block btn-sm btn-primary mt-2">Reports</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Projects table -->
                <div class="table-responsive">
                  <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                      <tr>
                        <th>ID
                        <th>Name
                        <th>City
                        <th>Total packs used
                        <th>Total credits
                        <th>Total price
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row"><a href="<?php echo e(route('t.users.show','transact')); ?>">0175757</a>
                        <td><i class="fas fa-user-check"></i> ABC
                        <td>Mumbai
                        <td>99
                        <td>990
                        <td>9900
                      </tr><tr>
                        <th scope="row"><a href="<?php echo e(route('t.users.show','transact')); ?>">0175757</a>
                        <td><i class="fas fa-user-check"></i> ABC
                        <td>Mumbai
                        <td>99
                        <td>990
                        <td>9900
                      </tr><tr>
                        <th scope="row"><a href="<?php echo e(route('t.users.show','transact')); ?>">0175757</a>
                        <td><i class="fas fa-user-check"></i> ABC
                        <td>Mumbai
                        <td>99
                        <td>990
                        <td>9900
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
        	<div class="col-md-6">
        		<div class="form-group">
                    <label class="form-control-label" for="designation">Designation</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                        <option>Senior Advocate</option>
                        <option>Junior Advocate</option>
                    </select>
                </div>
        	</div>
        	<div class="col-lg-6">
        		<div class="form-group">
        			<label class="form-control-label" for="state">State</label>
        			<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" name="state">
                        <option>Rajasthan</option>
                        <option>Gujarat</option>
                        <option>Punjab</option>
                    </select>
        		</div>
        	</div>
        </div>
        <div class="row">
        	<div class="col-lg-6">
        		<div class="form-group">
        			<label class="form-control-label" for="district">District</label>
        			<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true" name="district">
                        <option>Jaipur</option>
                        <option>Chaksur</option>
                        <option>Renwal</option>
                    </select>
        		</div>
        	</div>
        	<div class="col-lg-6">
        		<div class="form-group">
        			<label class="form-control-label" for="city">City</label>
        			<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" name="city" placeholder="City">
                        <option>Mumbai</option>
                        <option>Ahmedabad</option>
                        <option>New Delhi</option>
                    </select>
        		</div>
        	</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">Apply</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->startSection('jquery'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\adminLawnics\resources\views/admin/transaction/user/dashboard.blade.php ENDPATH**/ ?>