
<?php $__env->startSection('title','Segmentation - User'); ?>
<?php $__env->startSection('content'); ?>
<section>
	
	<div class="col p-3">
		<div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Advocates</h3>
					</div>
					<div class="col text-right">
						<a href="<?php echo e(route('u.segments.show','add')); ?>" class="btn btn-primary">Add</a>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Icons</th>
		                    <th>Gender</th>
		                    <th>Age</th>
		                    <th>Action</th>
	                    </tr>
	                </thead>
	                <tbody>
	                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                	<?php if(strtolower($value['category']??'N/A')!='lawyer'): ?> <?php continue; ?> <?php endif; ?>
	                	<tr>
		                    <th><i class="ni ni-circle-08" style="font-size: 24px;"></i></th>
		                    <td><?php echo e($value['gender']??'N/A'); ?></td>
		                    <td>26-41</td>
		                    <td><button class="btn btn-sm btn-primary">Edit</button></td>
	                    </tr>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
	
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\adminLawnics\resources\views/admin/user/segments/lawyer.blade.php ENDPATH**/ ?>