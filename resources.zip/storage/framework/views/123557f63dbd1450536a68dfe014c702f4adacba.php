
<?php $__env->startSection('title','Transaction'); ?>
<?php $__env->startSection('content'); ?>
<style>h3,h4,h5{color: white;margin:0;}
.passBookBody h4{color: black;}
.bg-black{background-color: black;}
.h3,.h5{color: white!important;}
.bg-black{background-color: black;}
#baner-name > *{color: white!important;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
hr{border: 1px solid lightgrey!important;width: 100%;margin: 2% 0px 2% 0px;}
</style>
<section>

    <div class="col p-3">
        <div class="card mb-0">
            <div class="card card-profile border-bottom bg-black mb-0 pb-3">
                <div class="card-img-top pt-7"></div>
                <div class="row justify-content-center">
                    <div class="col-sm-3 order-sm-2">
                        <div class="card-profile-image">
                            <a href="#">
                                <div class="overlay">
                                    <img src="<?php echo e(asset('icons/0.png')); ?>" class="overicon" alt="badge" style="width: 18px;margin-top:<?php echo e(isset($user['profile'])?40:20); ?>px;margin-left: <?php echo e(isset($user['profile'])?40:20); ?>px;"> 
                                </div>
                                <img src="<?php if(isset($user['profile'])): ?> <?php echo e($user['profile']); ?> <?php else: ?> <?php echo e(asset('icons/'.ucfirst($user['gender'] ?? 'N/A').'.png')); ?> <?php endif; ?>" alt="user_icon" width="<?php echo e(isset($user['profile'])?105:55); ?>" height="<?php echo e(isset($user['profile'])?105:55); ?>" class="rounded-circle">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
                    <div class="d-flex justify-content-end">
                    </div>
                </div>
                <div class="card-body pt-3 pb-1">
                    <div class="text-center" id="baner-name">
                        <h5 class="h3">
                            <?php echo e(($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A')); ?>

                        </h5>
                        <div class="h5 font-weight-300">
                            <i class="ni location_pin mr-2"></i><?php echo e(($user['city'] ?? 'N/A').', '.($user['state'] ?? 'N/A')); ?>

                        </div>
                        <div class="h5 font-weight-300">
                            7896543
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-header pl-3 ">
                <div class="">
                    <h4 class="text-left">Package</h4>
                    <div class="row text-white text-center">
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Total amount spent</h6>
                            <h3>15000</h3>
                        </div>
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Credits provide</h6>
                            <h3>500</h3>
                        </div>
                    </div>
                </div>
                <HR>
                <div class="">
                    <h4 class="text-left">Storage</h4>
                    <div class="row text-white text-center">
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Activated pack</h6>
                            <h3>Basic package</h3>
                        </div>
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Validity</h6>
                            <h3>20 days left</h3>
                        </div>
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Storage left</h6>
                            <h3>20 GB out of of 30 GB</h3>
                        </div>
                    </div>
                </div>
                <HR>
                <div class="">
                    <h4 class="text-left">Subscription</h4>
                    <div class="row text-white text-center">
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Activated pack</h6>
                            <h3>Basic package</h3>
                        </div>
                        <div class="col-sm-4">
                            <h6 class="heading-small text-muted mb-0">Validity</h6>
                            <h3>20 days left</h3>
                        </div>
                    </div>
                </div>
                <HR>
                <div class="row align-items-center">
                    <div class="col">
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            <a href="<?php echo e(route('u.list.show','reports')); ?>" class="btn btn-block btn-sm btn-primary mt-2">Reports</a>
                            <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Packages table -->
            <div class="card mt-1 mb-0">
                <div class="card-header border-0 p-3">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0 mx-1">Package</h3>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush text-center">
                        <thead class="thead-light">
                            <tr>
                                <th>Packs</th>
                                <th>Number of pack</th>
                                <th>Pack</th>
                                <th>Credits</th>
                                <th>Total pack amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Basic package</td>
                                <td>50</td>
                                <td>80</td>
                                <td>80</td>
                                <td>8000</td>
                            </tr>
                            <tr>
                                <td colspan="4"></td>
                                <td>
                                    <span class="btn btn-success">20000</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Packages table -->
            <div class="card mt-1 mb-0">
                <div class="card-header border-0 p-3">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0 mx-1">Storages</h3>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush text-center">
                        <thead class="thead-light">
                            <tr>
                                <th>Packs</th>
                                <th>Number of pack</th>
                                <th>Storage</th>
                                <th>Cost / Package</th>
                                <th>Total pack amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Basic package</td>
                                <td>50</td>
                                <td>80</td>
                                <td>80</td>
                                <td>8000</td>
                            </tr>
                            <tr>
                                <td colspan="4"></td>
                                <td>
                                    <span class="btn btn-success">20000</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Packages table -->
            <div class="card mt-1 mb-0">
                <div class="card-header border-0 p-3">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0 mx-1">Subsriptions</h3>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush text-center">
                        <thead class="thead-light">
                            <tr>
                                <th>Packs</th>
                                <th>Number of pack</th>
                                <th>Cost / Package</th>
                                <th>Total pack amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Basic package</td>
                                <td>50</td>
                                <td>80</td>
                                <td>8000</td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                                <td>
                                    <span class="btn btn-success">20000</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card pb-3 mb-3 mt-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Passbook</h3>
                    </div>
                </div>
            </div>
            <div class="card mb-0 mt-3">
                <div class="mx-3 pass-border-dark">
                    <div class="">
                        <a class="alert alert-<?php echo e(($order['order_type'] ??'N/A')=='Pending'?'fail':'dark'); ?> d-flex mb-1 order-header" href="">
                            <div class="pr-5">
                                <h5 class="heading-small text-muted">Transaction ID</h5>
                                <h4>413654195</h4>
                            </div>
                            <div class="pr-5">
                                <h5 class="heading-small text-muted">Date</h5>
                                <h4>24/06/2020</h4>
                            </div>
                            <div class="pr-5">
                                <h5 class="heading-small text-muted">Time</h5>
                                <h4>10:00 PM</h4>
                            </div>
                            <div class="pr-5">
                                <h5 class="heading-small text-muted">Status</h5>
                                <h4>Pending</h4>
                            </div>
                            <div class="pr-5">
                                <h5 class="heading-small text-muted">Recharge through</h5>
                                <h4>Printing partner</h4>
                            </div>
                        </a>
                        <div class="alert container mb-0 passBookBody">
                            <div class="row mb-2 d-flex">
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Mode</h5>
                                    <h4>UPI</h4>
                                </div>
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Pack</h5>
                                    <h4>Popular pack</h4>
                                </div>
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Pack price</h5>
                                    <h4>250</h4>
                                </div>
                            </div>
                            <div class="row d-flex">
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Credits</h5>
                                    <h4>500</h4>
                                </div>
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Available credits</h5>
                                    <h4>1000</h4>
                                </div>
                                <div class="col-md pr-5">
                                    <h5 class="heading-small text-muted">Delivery Partner</h5>
                                    <h4>ABC DEF</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="designation">Area</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                                <option>Bani park</option>
                                <option>Bani park</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary">Apply</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('jquery'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Work\adminLawnics\resources\views/admin/transaction/user/transact.blade.php ENDPATH**/ ?>