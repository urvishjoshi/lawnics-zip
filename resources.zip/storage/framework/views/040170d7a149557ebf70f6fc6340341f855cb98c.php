
<?php $__env->startSection('title','Timeslots'); ?>
<?php $__env->startSection('content'); ?>
<style>
    hr{border: 1px solid lightgrey!important;width: 100%;margin: 5% 0px 5% 0px;}
    .day-active{padding:5px; color: white; background-color: grey; border-radius: 5px;}
    .day{cursor: pointer;padding:5px;}
    .flex-column{font-size: 90%} input[type=number]{width: 33%}
    .overlayClose{position: relative;} .overClose:hover{color: red;cursor: pointer;}
    .overClose{position: absolute;margin-top: 2.5%;margin-left: 87%;color: white;z-index: 5;font-size: 20px;display:none;}
    /*.data-toggle{background-color: black!important;color: white!important;}*/
</style>
<?php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; ?>
<section>
    <div class="col p-3">
        <div class="card mb-3 pt-0">
            <div class="card-header border-0 p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Timeslots</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="searchew" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            
                            <button class="btn btn-block btn-sm btn-primary mt-2"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($locations<1): ?>
                <center><div class="card-body"><h2>No areas created yet</h2></div></center>
            <?php else: ?>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($state)): ?> <?php continue; ?> <?php endif; ?>
                <?php $__currentLoopData = $s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($district)): ?> <?php continue; ?> <?php endif; ?>
                <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($city)): ?> <?php continue; ?> <?php endif; ?>
                <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(!Clas::isPlace($key)): ?> <?php continue; ?> <?php endif; ?>
                    <?php echo $__env->make('admin.serviceproduct.timeslot.component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>



</section>
<!-- Modal -->
<div class="modal fade" id="timeslotModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('sp.timeslots.show',1)); ?>" method="POST" id="form" class="mb-0">
                <?php echo csrf_field(); ?> <?php echo method_field('GET'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Timeslot</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label class="form-control-label" for="input-username">Day</label>
                                <select class="custom-select" name="modalDays" id="modalDays">
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-first-name">From</label>
                                <div class="d-flex">
                                    <input type="number" name="fromHour" id="fromHour" class="form-control" step="01" min="01" max="12" value="01" oninput="format(this)">
                                    <input type="number" name="fromMinute" id="fromMinute" class="form-control" step="01" min="00" max="59" value="00" oninput="format(this)">
                                    <select class="custom-select" name="fromTime" id="fromTime" style="width:34%">
                                        <option>AM</option>
                                        <option>PM</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-first-name">To</label>
                                <div class="d-flex">
                                    <input type="number" name="toHour" id="toHour" class="form-control" step="01" min="01" max="12" value="01" oninput="format(this)">
                                    <input type="number" name="toMinute" id="toMinute" class="form-control" step="01" min="00" max="59" value="00" oninput="format(this)">
                                    <select class="custom-select" name="toTime" id="toTime" style="width:34%">
                                        <option>AM</option>
                                        <option>PM</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer timeslotModal">
                    <img src="<?php echo e(asset('icons/load.gif')); ?>" alt="" width="40" class="mr-2" id="load" style="display: none;">
                    <i class="fas fa-check-circle text-success mr-2" style="font-size: 40px!important;display: none;"></i>
                    <input type="hidden" name="addBtn" value="">
                    <input type="hidden" name="editBtn" value="">
                    <button type="submit" name="btn" class="btn btn-dark" value="">Add</button>
                    <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<?php echo $__env->make('admin.layouts.assets.locationsModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('jquery'); ?>
<?php echo $__env->make('admin.layouts.assets.allLocationsAjax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<script>
    $('.day').click(function(e) {
        var displayData='', div = $(this).parent().parent().parent().find('#displayTimeslots');
        var location = $(this).parent('div').attr('value');
        var day = $(this).attr('value');
        $.ajax({
            method:"GET",
            url: '<?php echo e(route('sp.timeslots.show',2)); ?>',
            data: {
                'day': day,
                'location': location,
                '_token': '<?php echo e(csrf_field()); ?>',
                '_method': '<?php echo e(method_field('GET')); ?>',
            },
            dataType:'JSON',
            success:function(data){
                if(data==0)
                    div.html('<h2 class="text-center">No timeslots created yet</h2>')
                else{
                    $.each(data, function (key, timeslot) {
                        displayData+= '<div class="overlayClose d-inline-flex"><span class="overClose" onclick="closeBtn(this)">&times;</span><button data-toggle="button" aria-pressed="false" class="btn btn-dark mx-2 my-2" value="'+location+'/Timeslots/'+day+'/'+key+'">'+timeslot.fromHour+':'+timeslot.fromMinute+' '+timeslot.fromTime+' - '+timeslot.toHour+':'+timeslot.toMinute+' '+timeslot.toTime+'</button></div>';
                    });
                    div.html(displayData);
                }
            }
        });
        $(this).siblings().removeClass('day-active');
        $(this).addClass('day-active');
    });


    var today = new Date();
    var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    var nextDay = new Date(today);
    week(nextDay,today,days);

    function week(nextDay,day) {
        for(i=1;i<=7;i++){
            nextDay.setDate(today.getDate()+i);

            if(today.getDay()+i > 7)
                var day = days[ (today.getDay()+i-1)%7 ];
            else
                var day = days[ (today.getDay()+i-1) ];
            $('#day'+i+'*').attr('value',day).html(day);
            $('#modalDays').append('<option>'+day+'</option>');

            var d=today.getDate()+i-1;
            var m=today.getMonth()+1;
            var y=today.getFullYear();

            $('#date'+i+'*').html(d+'/'+m+'/'+y);
        }
    }

    function format(input){
        if (input.value.length > 2) input.value = input.value.slice(0, 2)
        $(input).blur(function() {
           if(input.value.length == 1) input.value=0+input.value;
           if(input.value.length == 0) input.value='01';
        });
    }

    $('.select2').select2();

    $("#form").on('submit',function(event){
        
        $("#load").css('display','block');
        event.preventDefault();
        $.ajax({
            method:"GET",
            url: $(this).attr('action'),
            data: $(this).serialize(),
            dataType:'JSON',
            success:function(data){
                $("#load").hide();
                $('.fa-check-circle').show();
            }
        });
    });

    var $rows = $('card mb-0 px-3 pb-3');
    $('#searchnew').keyup(function() {

        var val = '^(?=.*\\b' + $.trim($(this).val()).split(/\s+/).join('\\b)(?=.*\\b') + ').*$',
        reg = RegExp(val, 'i'),
        text;

        $rows.show().filter(function() {
            text = $(this).text().replace(/\s+/g, ' ');
            return !reg.test(text);
        }).hide();
    });

    ////__Filters__\\\\
    function cancel(service) {
        $('.'+service).show();
    }

    function filter(service) { var sNameOptions='';
        $('#serviceLabel').text(service)
        $('#apply').attr('onclick','applyFilter("'+service+'")')
        $('#cancel').attr('onclick','cancel("'+service+'")')
        $('.'+service).each(function () {
            $(this).find('#'+service+'LocDiv .col').each(function() {
                if ($(this).find('h6').text()=='Name') {
                    var sName = $(this).find("h3").text();
                    sNameOptions += '<option>'+sName+'</option>';
                } 
            });
        });
        $('#serviceName').html(sNameOptions);
    }
    $('#apply').click(function (event) {
        $('.timeslotDiv').each(function () {

            if( stateFilter($(this)) && districtFilter($(this))  && cityFilter($(this)) && areaFilter($(this)) )
                $(this).show();
            else $(this).hide();

        });
    })

    function stateFilter(div) {
        var state = $('#SAstate').val(), flag=false; if (state=='') return true;
        div.find('#locationsDiv .col').each(function() {
            if ($(this).find('h6').text()=='State') {
                for (var i = 0; i < state.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), state[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function districtFilter(div) {
        var city = $('#SAdistrict').val(), flag=false; if (city=='') return true;
        div.find('#locationsDiv .col').each(function() {
            if ($(this).find('h6').text()=='District') {
                for (var i = 0; i < city.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), city[i].split(' - ')[0] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function cityFilter(div) {
        var city = $('#SAcity').val(), flag=false; if (city=='') return true;
        div.find('#locationsDiv .col').each(function() {
            if ($(this).find('h6').text()=='City') {
                for (var i = 0; i < city.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), city[i].split(' - ')[0] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function areaFilter(div) {
        var area = $('#SAarea').val(), flag=false; if (area=='') return true;
        div.find('#areaDiv .col').each(function() {
            if ($(this).find('h6').text()=='Area') {
                for (var i = 0; i < area.length; i++) {
                    if ( strcmp( $(this).find("h3").attr('value'), area[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    //__str compare__
    function strcmp(str1='', str2='') {
        if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
        return false;
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<script>
    function add(el) {
        $('.fa-check-circle').hide();
        var editBtn = $(el).siblings('button');
        if (editBtn.attr('aria-pressed')=='true')
            editBtn.click();
        $('input[name=addBtn]').val($(el).val());
        $('input[name=editBtn]').val('');
        $('.modal-footer>button[type=submit]').text('Add');
        $('#modalDays').removeAttr("disabled"); 
    }
    function closeBtn(el) {
        var timeslot = $(el).siblings('button').val();
        $(el).parent('div').remove();
        $.ajax({
            method:"GET",
            url: '<?php echo e(route('sp.timeslots.show',4)); ?>',
            data: {
                'ref': timeslot,
                '_token': '<?php echo e(csrf_field()); ?>',
                '_method': '<?php echo e(method_field('GET')); ?>',
            },
            dataType:'JSON',
            success:function(data){
            }
        });
    }
    function editBtn(btn) {
        $('.fa-check-circle').hide();
        var ref = $('input[name=editBtn]').val($(btn).val());
        var text = $(btn).text().split(' - ')
        var fromHour = text[0].substring(0, 2);
        var fromMinute = text[0].substring(3, 5);
        var fromTime = text[0].substring(6, 8);
        var toHour = text[1].substring(0, 2);
        var toMinute = text[1].substring(3, 5);
        var toTime = text[1].substring(6, 8);
        $('#fromHour').val(fromHour);
        $('#fromMinute').val(fromMinute);
        $('#fromTime').val(fromTime);
        $('#toHour').val(toHour);
        $('#toMinute').val(toMinute);
        $('#toTime').val(toTime);
        var day = $(btn).parents('.col-md-9').siblings().children('.d-flex').children('.day-active').text();
        $('#modalDays').val(day).attr("disabled", true);
    }
    function edit(el) {
        var div = $(el).parents('.card').children('.card-body').children('.col-md-9').children('.container').children('#displayTimeslots').children('.overlayClose').children('.overClose');
        if ($(el).attr('aria-pressed')=='false') {
            $('input[name=addBtn]').val('');
            div.css('display','block')
            div.siblings('button').attr({"data-toggle":"modal","data-target":"#timeslotModal","onclick":"editBtn(this)"})
            $('.modal-footer>button[type=submit]').text('Update');
            $('.flex-fill.active').click()
        }
        else{
            div.css('display','none')
            $('input[name=editBtn]').val('');
        }
    }
</script>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Work\adminLawnics\resources\views/admin/serviceproduct/timeslot/dashboard.blade.php ENDPATH**/ ?>