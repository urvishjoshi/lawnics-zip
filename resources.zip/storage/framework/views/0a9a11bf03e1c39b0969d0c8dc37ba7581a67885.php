<h2 class="m-0 mb-2 text-dark">Overview</h2>
<div class="row">
	<div class="col-lg-3 col-6">
		<a href="<?php echo e(route('dashboard.show',1)); ?>">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/1*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/user.png')); ?>">
				<h1><?php echo e(count($all['Users'])); ?></h1>
				<h5>Total user</h5>
			</div>
		</a>
	</div>
	<div class="col-lg-3 col-6">
		<a href="#">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/2*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/user.png')); ?>">
				<h1><?php echo e(count($all['Printing_partner'])); ?></h1>
				<h5>Total printing partner</h5>
			</div>
		</a>
	</div>
	<div class="col-lg-3 col-6">
		<a href="#">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/3*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/user.png')); ?>">
				<h1>150</h1>
				<h5>Total delivery partner</h5>
			</div>
		</a>
	</div>
	<div class="col-lg-3 col-6">
		<a href="<?php echo e(route('dashboard.show',4)); ?>">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/4*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/order.png')); ?>">
				<h1>150</h1>
				<h5>Total order</h5>
			</div>
		</a>
	</div>
</div>
<div class="row">
	<div class="col-lg-3 col-6">
		<a href="<?php echo e(route('dashboard.show',5)); ?>">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/5*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/transaction.png')); ?>">
				<h1>150</h1>
				<div class="d-flex">
					<h5 >Transactions</h5>
					<img src="<?php echo e(asset('icons/donut.png')); ?>" class="ml-auto" width="35px">
				</div>
			</div>
		</a>
	</div>
	<div class="col-lg-3 col-6">
		<a href="<?php echo e(route('dashboard.show',6)); ?>">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/6*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/user.png')); ?>">
				<h1>150</h1>
				<div class="d-flex">
					<h5>Service & products</h5>
					<img src="<?php echo e(asset('icons/donut.png')); ?>" class="ml-auto" width="35px">
				</div>
			</div>
		</a>
	</div>
	<div class="col-lg-3 col-6">
		<a href="<?php echo e(route('dashboard.show',7)); ?>">
			<div class="small-box p-3 <?php echo e((Request::is('admin/dashboard/7*')) ? 'active' : ''); ?>">
				<img src="<?php echo e(asset('icons/sales.png')); ?>">
				<h1>150</h1>
				<div class="d-flex">
					<h5>Sales</h5>
					<img src="<?php echo e(asset('icons/donut.png')); ?>" class="ml-auto" width="35px">
				</div>
			</div>
		</a>
	</div>
</div><?php /**PATH D:\xampp\htdocs\Work\Lawnics\adminLawnics\resources\views/admin/dashboard/layout.blade.php ENDPATH**/ ?>