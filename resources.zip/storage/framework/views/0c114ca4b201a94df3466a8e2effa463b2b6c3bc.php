
<?php $__env->startSection('link'); ?>
<style>.crop{
      white-space: nowrap; 
  width: 20%!important; 
  overflow: hidden;
  text-overflow: ellipsis; display: inline-block;
    }</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','FAQ - Advocate App'); ?>
<?php $__env->startSection('content'); ?>
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">FAQ's</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="<?php echo e(route('aa.faqs.show','add')); ?>" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Heading</th>
                            <th>Question</th>
                            <th width="10%">Answer</th>
                            <th>Language</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($faqs < 1): ?>
                        <tr>
                            <td colspan="5"><h3>No English FAQs created yet</h3></td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($heading); ?></th>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $que => $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($que); ?></td>
                                <td><?php echo e($ans); ?></td>
                                <th>English</th>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('aa.faqs.show','edit?id='.$heading.'&lang=English')); ?>" class="btn btn-sm btn-dark">Edit</a>
                                        <form action="<?php echo e(route('aa.faqs.destroy',1)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="question" value="<?php echo e($que); ?>">
                                            <input type="hidden" name="heading" value="<?php echo e($heading); ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if($faqsH < 1): ?>
                        <tr>
                            <td colspan="5"><h3>No Hindi FAQs created yet</h3></td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $faqsH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($heading); ?></th>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $que => $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($que); ?></td>
                                <td><?php echo e(strip_tags($ans)); ?></td>
                                <th>Hindi</th>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('aa.faqs.show','edit?id='.$heading.'&lang=Hindi')); ?>" class="btn btn-sm btn-dark">Edit</a>
                                        <form action="<?php echo e(route('aa.faqs.destroy',2)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <input type="hidden" name="question" value="<?php echo e($que); ?>">
                                            <input type="hidden" name="heading" value="<?php echo e($heading); ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('jquery'); ?>
<script>
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Work\adminLawnics\resources\views/admin/advocateapp/faq/dashboard.blade.php ENDPATH**/ ?>