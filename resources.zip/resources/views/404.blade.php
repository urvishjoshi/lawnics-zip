@extends('admin.layouts.app')
@section('title','Data Not found')
@section('content')
<section>
    <div class="container p-3 my-8">
        <div class="my-5">
            <div class="text-center">
                <h6><i class="fas fa-exclamation-triangle" style="font-size: 500%!important"></i></h6>
                
                <h1>Oops, we didn't found what you are looking for!</h1>
                <h3>Return <a href="{{url()->previous()}}" onclick="javascript:window.history.back(-1);return false;" class="text-primary">back</a> to previous page</h3>
            </div>
        </div>
    </div>
</section>
@endsection