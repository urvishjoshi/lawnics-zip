@extends('admin.layouts.app')
@section('title','Edit - Service')
@section('content')
<section>
	@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
	<div class="col p-3">
		<form class="card mb-0" action="{{ route('sp.services.store') }}" method="POST" id="form"> @csrf @method('POST')
			<!-- Professional -->
			<div class="card-header mb-3 text-white">Edit {{ucfirst($serviceName)}}</div>
			<div class="px-lg-4">
				<div class="row">
					<div class="col-lg-8">
						<div class="form-group">
                            <label class="form-control-label" for="image">{{ucfirst($serviceName)}} Image</label>
                            <input type="file" id="image" name="image" class="form-control"/>
                            <input type="hidden" value="" name="imagePath" id="imagePath"/>
                            <input type="hidden" value="" name="imageName" id="imageName"/>
                            <input type="hidden" name="imageToBeDelete" id="imageToBeDelete" value="{{$imageToBeDelete}}" />
                            <input type="hidden" value="{{$Skey}}" name="Skey" id="Skey"/>
                        </div>
					</div>
                    <div class="col-lg-4 align-items-center">
                        Current Image: <img src="{{ $service['image']??'' }}" alt="{{ $service['imageName']??'' }}" width="100">
                    </div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="name">Name</label>
							<input type="text" id="name" name="name" class="form-control" placeholder="Name of {{$serviceName}}" value="{{$service['name']}}" required/>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="state">State</label>
                            <select name="state" class="form-control" id="state" disabled>
                                <option value="">-select-</option>
                                <option>All</option>
                                @foreach($locations as $State => $s)
                                	@if(Clas::isPlace($State))
                                		
                                    <option @if($state==$State || $state=='All')selected @endif>{{ $state }}</option>
                                    	
                                    @endif
                                @endforeach
                            </select>
						</div>
					</div>
				</div>
				<input type="hidden" id="district" name="district" value="{{$district}}">
				<div class="row">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="city">City</label>
                            <select name="city" class="form-control" id="city" disabled>
                                <option value="">-select State-</option>
                                @foreach($locations as $State => $s)
                                	@if(Clas::isPlace($State))

                                		@foreach($s as $District => $d)
                                		@if(Clas::isPlace($District))
                                		@foreach($d as $City => $c)
	                                		@if(Clas::isPlace($City))
		                                    <option @if($city==$City || $city=='All')selected @endif>{{ $city }}</option>
		                                    @endif
		                                @endforeach
	                                    @endif
		                                @endforeach
                                    	
                                    @endif
                                @endforeach
                            </select>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="area">Area</label>
                            <select name="area" class="form-control" id="area" disabled>
                                <option value="">-select City-</option>
                                @foreach($locations as $State => $s)
                                	@if(Clas::isPlace($State))

                                		@foreach($s as $District => $d)
                                		@if(Clas::isPlace($District))
                                		@foreach($d as $City => $c)
	                                		@if(Clas::isPlace($City))
	                                		@foreach($c as $key => $area)
		                                		@if(Clas::isPlace($key))
			                                    <option @if($key==$areaKey || $areaKey=='All')selected @endif value="{{$areaKey}}">{{ $areaName }}</option>
			                                    @endif
			                                @endforeach
		                                    @endif
		                                @endforeach
	                                    @endif
		                                @endforeach
                                    	
                                    @endif
                                @endforeach
                            </select>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="idnumber">ID</label>
							<input type="number" id="idnumber" name="idnumber" class="form-control" placeholder="ID number" value=""  min="0" required>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="category">Category</label>
							<select name="category" class="form-control" id="category" required>
                                <option>Lawyer</option>
                                <option>Non lawyer</option>
                            </select>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="designation">Designation</label>
							<select name="designation" class="form-control" id="designation" required>
                                <option>Senior Advocate</option>
                                <option>Junior Advocate</option>
                            </select>
						</div>
					</div>
					<div class="col-lg d-flex px-0">
						<div class="col-sm-6">
							<div class="form-group">
								<label class="form-control-label" for="minAge">Minimum Age</label>
								<input type="number" id="minAge" name="minAge" class="form-control" placeholder="Minimum Age"  value="{{$service['minAge']}}">
							</div>
							
						</div>
						<div class="col-sm-6">
							
						<div class="form-group">
							<label class="form-control-label" for="maxAge">Maximum Age</label>
							<input type="number" id="maxAge" name="maxAge" class="form-control" placeholder="Maximum Age"  value="{{$service['maxAge']}}">
						</div>
						</div>
					</div>
				</div>
				<div class="row">
					@if($serviceName=='Packages')
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="credits">Credits</label>
							<input type="number" id="credits" name="credits" class="form-control" placeholder="Credits" min="0" value="{{$service['credits']}}" required>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="features">Features</label>
							<div class="input-group mb-3 my-auto py-auto">
								<div class="input-group-prepend">
									<div class="input-group-text p-1">
										<input type="checkbox" aria-label="Checkbox for following text input">
									</div>
								</div>
								<label class="form-control-label my-auto">User ID</label>
							</div>
						</div>
					</div>
					@elseif($serviceName=='Storages')
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="storage">Storage</label>
							<input type="number" id="storage" name="storage" class="form-control" placeholder="Storage in GB" value="{{$service['storage']}}" min="0" step="0.1" required>
						</div>
					</div>
					@endif
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="validityInDays">Validity</label>
							<input type="number" id="validityInDays" name="validityInDays" class="form-control" value="{{$service['validity']}}" placeholder="Validity" min="0" required>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="price">Price</label>
							<input type="number" id="price" name="price" class="form-control" placeholder="Price" min="0" value="{{$service['price']}}" required>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="desc">Description</label>
							<input type="text" id="desc" value="{{$service['desc']}}" name="desc" class="form-control" placeholder="Description" required>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label" for="type">Type</label>
							<select name="type" class="form-control" id="type">
                                <option {{$service['type']=='Normal'?'selected':''}}>Normal</option>
                                <option {{$service['type']=='Limited'?'selected':''}}>Limited</option>
                            </select>
						</div>
					</div>
				</div>
			</div>
			<div id="limited">
				<div class="card-header mb-3 text-white">Activation (Date & Time)</div>
				<input type="hidden" name="limited" value="1">
				<div class="px-lg-4">
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group">
								<label class="form-control-label" for="fromDate">Date</label>
								<input type="date" id="fromDate" name="fromDate" class="form-control" placeholder="Name of {{$serviceName}}" value="{{isset($service['limit'])?$service['limit']['fromDate']:''}}" required/>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
                                <label class="form-control-label" for="input-first-name">Time</label>
                                <div class="d-flex">
                                    <input type="number" name="fromHour" id="fromHour" class="form-control" step="01" min="01" max="12" value="{{isset($service['limit'])?$service['limit']['fromHour']:'01'}}" oninput="format(this)">
                                    <input type="number" name="fromMinute" id="fromMinute" class="form-control" step="01" min="00" max="59" value="{{isset($service['limit'])?$service['limit']['fromMinute']:'00'}}" oninput="format(this)">
                                    <select class="custom-select" name="fromTime" id="fromTime" style="width:34%">
                                        <option{{isset($service['limit'])?($service['limit']['toTime']=='AM'?'selected':''):''}}>AM</option>
                                        <option{{isset($service['limit'])?($service['limit']['toTime']=='PM'?'selected':''):''}}>PM</option>
                                    </select>
                                </div>
                            </div>
						</div>
					</div>
				</div>
				<div class="card-header mb-3 text-white">Ending (Date & Time)</div>
				<div class="px-lg-4">
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group">
								<label class="form-control-label" for="toDate">Date</label>
								<input type="date" id="toDate" name="toDate" class="form-control" placeholder="Name of {{$serviceName}}" value="{{isset($service['limit'])?$service['limit']['toDate']:''}}" required/>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group">
							    <label class="form-control-label" for="input-first-name">Time</label>
							    <div class="d-flex">
							        <input type="number" name="toHour" id="toHour" class="form-control" step="01" min="01" max="12" value="{{isset($service['limit'])?$service['limit']['toHour']:'01'}}" oninput="format(this)">
							        <input type="number" name="toMinute" id="toMinute" class="form-control" step="01" min="00" max="59" value="{{isset($service['limit'])?$service['limit']['fromHour']:'00'}}" oninput="format(this)">
							        <select class="custom-select" name="toTime" id="toTime" style="width:34%">
							            <option {{isset($service['limit'])?($service['limit']['toTime']=='AM'?'selected':''):''}}>AM</option>
							            <option {{isset($service['limit'])?($service['limit']['toTime']=='PM'?'selected':''):''}}>PM</option>
							        </select>
							    </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="p-4 d-flex justify-content-end">
				<img src="{{asset('icons/load.gif')}}" alt="uploading" width="40" height="40" class="mr-2" id="load" style="display: none;">
				<span id="errorSpan" class="text-danger mx-2 my-auto" style="display: none;"></span>
				<input type="hidden" name="editBtn" value="{{ucfirst($serviceName)}}"/>
				<a href="{{route('sp.services.index')}}" class="btn btn-dark">Cancel</a>
				<button type="button" class="btn btn-dark" onclick="upload()">Update</button>
			</div>
				<button type="submit" id="hiddenSubmit" style="border:none;cursor: none;"></button>
		</form>
	</div>
	
</section>

@section('jquery')
<script>

    $(document).ready(function() {
    	var limited = $('#limited *')
    	@if(empty($service['limit']))
    		limited.attr('disabled','disabled');
		@endif
    	$("#type").on('change',function(){
    		if($(this).val()=='Limited') limited.removeAttr("disabled");
    		else limited.attr('disabled','disabled');
        });
        
        $("#state").on('change',function(){
        	if ($(this).val()=='All') {
                $("#city").html('<option>All</option>');
                $("#area").html('<option>All</option>');
                $("#district").val('All');
        		return;
        	}
            $.ajax({
                method:"GET",
                url:"{{ route('sp.papers.show',2.5) }}",
                data: {
                   'state': $(this).val(),
                   '_token': '@csrf',
                   '_method': '@method('GET')',
                },
                dataType:'html',
                success:function(data){
                if(data==0) {
                    $("#city").html('<option value="">-No City found-</option>');
                    $("#area").html('<option value="">-No Area found-</option>');
                }
                else {
                    $("#area").html('<option value="">-select City-</option>');
                    $("#city").html(data);
                }}
            });
        });

        $("#city").on('change',function(){
        	if ($(this).val()=='All') {
                $("#area").html('<option>All</option>');
                $("#district").val('All');
        		return;
        	}
            $.ajax({
                method:"GET",
                url:"{{ route('sp.papers.show',3.5) }}",
                data: {
                   'state': $('#state').val(),
                   'city': $(this).val(),
                   '_token': '@csrf',
                   '_method': '@method('GET')',
                },
                dataType:'html',
                success:function(data){
                if(data<1)
                    $("#area").html('<option value="">-No Area found-</option>');
                else {
                	var json = JSON.parse(data)
                    $("#area").html(json.data);
                    $("#district").val(json.district);
                }}
            });
        });
    });
</script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-storage.js"></script>
<script src="{{ asset('assets/js/firebaseJs.js') }}"></script>
<script>
  

    function upload() {
    	document.getElementById("errorSpan").style.display = 'none';
        var image=document.getElementById("image").files[0];
        var deleteImage = document.getElementById("imageToBeDelete").value;
        var type = document.getElementById("type").value;
        var formcheck=false;
        var dateValid=true;
        var service = '{{strtolower($serviceName)}}';
        if (type=='Limited') {
	        var fromD = document.getElementById("fromDate").value;
	        var toD = document.getElementById("toDate").value;
	        if(!(fromD && toD))
	        	dateValid=false;
	        else
	        	dateValid=true;
	        if ($('#fromHour').val()>13||$('#toHour').val()>13){ alert('Hour must be less than 12'); return false; }
	        if ($('#fromMinute').val()>60||$('#toMinute').val()>60){ alert('Minute must be less than 60'); return false; }
        }

        if(validate(service)){

	        if (image && dateValid){

	        	var imgExt = image.name.toLowerCase(),
		            regex = new RegExp("(.*?)\.(jpg|jpeg|png)$");
		        if (!(regex.test(imgExt))) {
		            alert('Please select .jpg/.jpeg or .png file format');
		            return false;
		        }

	          var imageN=image.name;
	          var s = new Date().getTime();
	          var imageName = s+'_'+imageN;
	          var storageRef=firebase.storage().ref(service+'Icons/'+imageName);

	          document.getElementById("imageName").value = imageName;
	          var uploadTask=storageRef.put(image);
		      
		      locationJS();

	          uploadTask.on('state_changed',function (snapshot) {
	              document.getElementById("load").style.display = 'block';
	          },function (error) {
	              //handle error here
	              console.log(error.message);
	          },function () {
	              uploadTask.snapshot.ref.getDownloadURL().then(function (downlaodURL) {
	                  document.getElementById("imagePath").value = downlaodURL;

	                  if(deleteImage!="") {
	                    storageRef = firebase.storage().ref(service+'Icons/');
	                    var desertRef = storageRef.child(deleteImage);
	                    desertRef.delete().then(function() {
	                      console.log('deleted');

	                    }).catch(function(error) {
	                      console.log(error.message);
	                    });
	                  }
	                  document.getElementById('hiddenSubmit').click()
	              });
	          });
	        } else {
	        	if(!image) {
	        	document.getElementById("errorSpan").innerHTML = 'Please upload image';
	        	document.getElementById("errorSpan").style.display = 'block';
		        }
		        if(!dateValid){
	        	document.getElementById("errorSpan").innerHTML = 'Please enter dates';
	        	document.getElementById("errorSpan").style.display = 'block';

		        }
		    }
        }

    }
    function locationJS() {
    	document.getElementById('state').removeAttribute('disabled');
    	document.getElementById('city').removeAttribute('disabled');
    	document.getElementById('area').removeAttribute('disabled');
    	document.getElementById('state').setAttribute('readonly','readonly');
    	document.getElementById('city').setAttribute('readonly','readonly');
    	document.getElementById('area').setAttribute('readonly','readonly');
    }
    function validate(service) {
    	if (!$('#name').val()){ alert('name is required'); return false; }
    	if (!$('#state').val()){ alert('state is required'); return false; }
    	if (!$('#city').val()){ alert('city is required'); return false; }
    	if (!$('#area').val()){ alert('area is required'); return false; }
    	if (!$('#idnumber').val()){ alert('id number is required'); return false; }
    	if (!$('#minAge').val()){ alert('minimun age is required'); return false; }
    	if (!$('#maxAge').val()){ alert('maximum age is required'); return false; }
    	if (!$('#validityInDays').val()){ alert('validity is required'); return false; }
    	if (!$('#desc').val()){ alert('description is required'); return false; }
    	if (!$('#price').val()){ alert('price is required'); return false; }

    	if(service=='storages'){ if (!$('#storage').val()){ alert('storage is required'); return false; } }
    	if(service=='packages'){ if (!$('#credits').val()){ alert('credits is required'); return false; } }
    		
    	return true;
    }
</script>
@endsection
@endsection
<script>
	function format(input){
	    if (input.value.length > 2) input.value = input.value.slice(0, 2)
	    $(input).blur(function() {
	       if(input.value.length == 1) input.value=0+input.value;
	       if(input.value.length == 0) input.value='01';
	       if(input.value <= 0) input.value='01';
	    });
	}
</script>