<!-- Filter Modal -->
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="serviceName"><span id="serviceLabel"></span> name</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="serviceName" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="serviceName" id="serviceName">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="state">State</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" name="state" id="statePermi">
                            @foreach($locations as $state => $s)
                                @if(Clas::isPlace($state))
                                <option>
                                    {{ $state }}
                                </option>
                                @endif
                            @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="city">City</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" name="city" placeholder="City" id="cityPermi">
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="area">Area</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="area" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" name="area" placeholder="area" id="areaPermi">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="category">Category</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="18" tabindex="-1" aria-hidden="true" name="category" id="category">
                                <option>Lawyer</option>
                                <option>Non Lawyer</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="designation">Designation</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="designation" style="width: 100%;" data-select2-id="19" tabindex="-1" aria-hidden="true" name="designation" placeholder="designation" id="designation">
                                <option>Senior Advocate</option>
                                <option>Junior Advocate</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal" onclick="cancel(service)" id="cancel">Cancel</button>
                <button type="button" class="btn btn-dark" data-dismiss="modal" onclick="filterApply(service)" id="apply">Apply</button>
            </div>
        </div>
    </div>
</div>