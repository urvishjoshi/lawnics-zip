@extends('admin.layouts.app')
@section('title','Services')
@section('content')
<style>
    hr{border: 1px solid lightgrey!important;width: 100%;margin: 5% 0px 5% 0px;}
    .day-active{padding:5px; color: white; background-color: grey; border-radius: 5px;}
    .day{cursor: pointer;padding:5px;}
    .flex-column{font-size: 90%} input[type=number]{width: 33%}
    .overlayClose{position: relative;} .overClose:hover{color: red;cursor: pointer;}
    .overClose{position: absolute;margin-top: 2.5%;margin-left: 87%;color: white;z-index: 5;font-size: 20px;display:none;}
    /*.data-toggle{background-color: black!important;color: white!important;}*/
</style>
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; $exists=null;@endphp
<section>
    <div class="col px-3 pt-3">
        <div class="card mb-0 pt-0">
            <div class="card-header border-0 p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Storages</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="searchew" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            <a href="{{route('sp.services.create')}}?service=storages" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                            <button class="btn btn-block btn-sm btn-primary mt-2"  data-toggle="modal" data-target="#exampleModal" onclick="filter('Storages')" id="Strfilter">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            @if($locations<1)
                <center><div class="card-body"><h2>No areas created yet</h2></div></center>
            @else
                @foreach($locations as $state => $s) <?php $serviceName='Storages'; ?>
                    @if($state=='Storages') <?php $cityAll=1; $onlyState=1; $areaAll=1;?>
                        @foreach($s as $Skey => $service)
                        @include('admin.serviceproduct.service.component')
                        @endforeach <?php unset($cityAll); unset($onlyState); unset($areaAll);?>
                    @endif

                    @foreach($s as $district => $d)
                        @if($district=='Storages') <?php $cityAll=1; $areaAll=1; $onlyCity=1;?>
                            @foreach($d as $Skey => $service)
                            @include('admin.serviceproduct.service.component')
                            @endforeach <?php unset($cityAll); unset($areaAll); unset($onlyCity);?>
                        @endif

                        @foreach($d as $city => $c) @if(Clas::isService($district)) <?php continue; ?> @endif
                            @if(is_array($c) || is_object($c))
                                @foreach($c as $key => $area)

                                    @if($key=='Storages')
                                        @foreach($area as $Skey => $service) 
                                        @include('admin.serviceproduct.service.component')
                                        @endforeach
                                    @endif

                                    @if(isset($area['Storages']))
                                    @foreach($area['Storages'] as $Skey => $service)
                                        @include('admin.serviceproduct.service.component')
                                    @endforeach
                                    @endif

                                @endforeach
                            @endif
                        @endforeach
                    @endforeach
                @endforeach
                {{-- @if($exists!='Storages')
                    <center><div class="card-body"><h2>No Storages created yet</h2></div></center>
                @endif <?php $serviceName=null; $exists=null?> --}}
            @endif
        </div>
    </div>
</section>

<section>
    <div class="col px-3 pt-3">
        <div class="card mb-0 pt-0">
            <div class="card-header border-0 p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Packages</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="searchew" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            <a href="{{route('sp.services.create')}}?service=packages" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                            <button class="btn btn-block btn-sm btn-primary mt-2"  data-toggle="modal" data-target="#exampleModal" onclick="filter('Packages')" id="Pfilter">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            @if($locations<1)
                <center><div class="card-body"><h2>No areas created yet</h2></div></center>
            @else
                @foreach($locations as $state => $s) <?php $serviceName='Packages'; ?>
                    @if($state=='Packages') <?php $cityAll=1; $onlyState=1; $areaAll=1;?>
                        @foreach($s as $Skey => $service)
                        @include('admin.serviceproduct.service.component')
                        @endforeach <?php unset($cityAll); unset($onlyState); unset($areaAll);?>
                    @endif

                    @foreach($s as $district => $d)
                        @if($district=='Packages') <?php $cityAll=1; $areaAll=1; $onlyCity=1;?>
                            @foreach($d as $Skey => $service)
                            @include('admin.serviceproduct.service.component')
                            @endforeach <?php unset($cityAll); unset($areaAll); unset($onlyCity);?>
                        @endif

                        @foreach($d as $city => $c) @if(Clas::isService($district)) <?php continue; ?> @endif
                            @if(is_array($c) || is_object($c))
                                @foreach($c as $key => $area)

                                    @if($key=='Packages')
                                        @foreach($area as $Skey => $service) 
                                        @include('admin.serviceproduct.service.component')
                                        @endforeach
                                    @endif

                                    @if(isset($area['Packages']))
                                    @foreach($area['Packages'] as $Skey => $service)
                                        @include('admin.serviceproduct.service.component')
                                    @endforeach
                                    @endif

                                @endforeach
                            @endif
                        @endforeach
                    @endforeach
                @endforeach
                {{-- @if($exists!='Packages')
                    <center><div class="card-body"><h2>No Packages created yet</h2></div></center>
                @endif <?php $serviceName=null; $exists=null?> --}}
            @endif
        </div>
    </div>
</section>

<section>
    <div class="col px-3 pt-3">
        <div class="card mb-0 pt-0">
            <div class="card-header border-0 p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Subscriptions</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="searchew" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            <a href="{{route('sp.services.create')}}?service=subscriptions" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                            <button class="btn btn-block btn-sm btn-primary mt-2"  data-toggle="modal" data-target="#exampleModal" onclick="filter('Subscriptions')" id="SubFilter">Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            @if($locations<1)
                <center><div class="card-body"><h2>No areas created yet</h2></div></center>
            @else
                @foreach($locations as $state => $s) <?php $serviceName='Subscriptions'; ?>
                    @if($state=='Subscriptions') <?php $cityAll=1; $onlyState=1; $areaAll=1;?>
                        @foreach($s as $Skey => $service)
                        @include('admin.serviceproduct.service.component')
                        @endforeach <?php unset($cityAll); unset($onlyState); unset($areaAll);?>
                    @endif

                    @foreach($s as $district => $d)
                        @if($district=='Subscriptions') <?php $cityAll=1; $areaAll=1; $onlyCity=1;?>
                            @foreach($d as $Skey => $service)
                            @include('admin.serviceproduct.service.component')
                            @endforeach <?php unset($cityAll); unset($areaAll); unset($onlyCity);?>
                        @endif

                        @foreach($d as $city => $c) @if(Clas::isService($district)) <?php continue; ?> @endif
                            @if(is_array($c) || is_object($c))
                                @foreach($c as $key => $area)

                                    @if($key=='Subscriptions')
                                        @foreach($area as $Skey => $service) 
                                        @include('admin.serviceproduct.service.component')
                                        @endforeach
                                    @endif

                                    @if(isset($area['Subscriptions']))
                                    @foreach($area['Subscriptions'] as $Skey => $service)
                                        @include('admin.serviceproduct.service.component')
                                    @endforeach
                                    @endif

                                @endforeach
                            @endif
                        @endforeach
                    @endforeach
                @endforeach
                {{-- @if($exists!='Subscriptions')
                    <center><div class="card-body"><h2>No Subsriptions created yet</h2></div></center>
                @endif <?php $serviceName=null; $exists=null?> --}}
            @endif
        </div>
    </div>
</section>

<!-- Modals -->
@include('admin.serviceproduct.service.modals')

@section('jquery')
@include('admin.layouts.assets.multiLocationAjax') 
<script>
    $('.select2').select2();

    $('.day').click(function(e) {
        var displayData='', div = $(this).parent().parent().parent().find('#displayTimeslots');
        var location = $(this).parent('div').attr('value');
        var day = $(this).attr('value');
        $.ajax({
            method:"GET",
            url: '{{ route('sp.timeslots.show',2) }}',
            data: {
                'day': day,
                'location': location,
                '_token': '{{csrf_field()}}',
                '_method': '{{method_field('GET')}}',
            },
            dataType:'JSON',
            success:function(data){
                if(data==0)
                    div.html('<h2 class="text-center">No timeslots created yet</h2>')
                else{
                    $.each(data, function (key, timeslot) {
                        displayData+= '<div class="overlayClose d-inline-flex"><span class="overClose" onclick="closeBtn(this)">&times;</span><button data-toggle="button" aria-pressed="false" class="btn btn-dark mx-2 my-2" value="'+location+'/Timeslots/'+day+'/'+key+'">'+timeslot.fromHour+':'+timeslot.fromMinute+' '+timeslot.fromTime+' - '+timeslot.toHour+':'+timeslot.toMinute+' '+timeslot.toTime+'</button></div>';
                    });
                    div.html(displayData);
                }
            }
        });
        $(this).siblings().removeClass('day-active');
        $(this).addClass('day-active');
    });


    var today = new Date();
    var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    var nextDay = new Date(today);
    week(nextDay,today,days);

    function week(nextDay,day) {
        for(i=1;i<=7;i++){
            nextDay.setDate(today.getDate()+i);

            if(today.getDay()+i > 7)
                var day = days[ (today.getDay()+i-1)%7 ];
            else
                var day = days[ (today.getDay()+i-1) ];
            $('#day'+i+'*').attr('value',day).html(day);
            $('#modalDays').append('<option>'+day+'</option>');

            var d=today.getDate()+i-1;
            var m=today.getMonth()+1;
            var y=today.getFullYear();

            $('#date'+i+'*').html(d+'/'+m+'/'+y);
        }
    }

    function format(input){
        if (input.value.length > 2) input.value = input.value.slice(0, 2)
        $(input).blur(function() {
           if(input.value.length == 1) input.value=0+input.value;
           if(input.value.length == 0) input.value='01';
        });
    }

    $("#form").on('submit',function(event){
        
        $("#load").css('display','block');
        event.preventDefault();
        $.ajax({
            method:"GET",
            url: $(this).attr('action'),
            data: $(this).serialize(),
            dataType:'JSON',
            success:function(data){
                $("#load").hide();
                $('.fa-check-circle').show();
            }
        });
    });

    var $rows = $('card mb-0 px-3 pb-3');
    $('#searchnew').keyup(function() {

        var val = '^(?=.*\\b' + $.trim($(this).val()).split(/\s+/).join('\\b)(?=.*\\b') + ').*$',
        reg = RegExp(val, 'i'),
        text;

        $rows.show().filter(function() {
            text = $(this).text().replace(/\s+/g, ' ');
            return !reg.test(text);
        }).hide();
    });

</script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-storage.js"></script>
<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyBHwGSw1Vx3ZRRhElbogopV4UstwkOgyVc",
    authDomain: "lawnicstech-f06bc.firebaseapp.com",
    databaseURL: "https://lawnicstech-f06bc.firebaseio.com",
    projectId: "lawnicstech-f06bc",
    storageBucket: "lawnicstech-f06bc.appspot.com",
    messagingSenderId: "920443516161",
    appId: "1:920443516161:web:280c1dc216439b6ef65700",
    measurementId: "G-PB65Z99GSJ"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  
</script>
@endsection

@endsection
<script>
    function deleteImg(form,deleteImage,service) {
        if(deleteImage!="") {
            storageRef = firebase.storage().ref(service+'Icons/');
            var desertRef = storageRef.child(deleteImage);
            desertRef.delete().then(function() {
            }).catch(function(error) {
              console.log(error.message);
          });
        }
        $(form).parents("form").submit()
        // document.getElementById('delform')
    }
    function add(el) {
        $('.fa-check-circle').hide();
        var editBtn = $(el).siblings('button');
        if (editBtn.attr('aria-pressed')=='true')
            editBtn.click();
        $('input[name=addBtn]').val($(el).val());
        $('input[name=editBtn]').val('');
        $('.modal-footer>button[type=submit]').text('Add');
        $('#modalDays').removeAttr("disabled"); 
    }
    function closeBtn(el) {
        var timeslot = $(el).siblings('button').val();
        $(el).parent('div').remove();
        $.ajax({
            method:"GET",
            url: '{{ route('sp.timeslots.show',4) }}',
            data: {
                'ref': timeslot,
                '_token': '{{csrf_field()}}',
                '_method': '{{method_field('GET')}}',
            },
            dataType:'JSON',
            success:function(data){
            }
        });
    }
    function editBtn(btn) {
        $('.fa-check-circle').hide();
        var ref = $('input[name=editBtn]').val($(btn).val());
        var text = $(btn).text().split(' - ')
        var fromHour = text[0].substring(0, 2);
        var fromMinute = text[0].substring(3, 5);
        var fromTime = text[0].substring(6, 8);
        var toHour = text[1].substring(0, 2);
        var toMinute = text[1].substring(3, 5);
        var toTime = text[1].substring(6, 8);
        $('#fromHour').val(fromHour);
        $('#fromMinute').val(fromMinute);
        $('#fromTime').val(fromTime);
        $('#toHour').val(toHour);
        $('#toMinute').val(toMinute);
        $('#toTime').val(toTime);
        var day = $(btn).parents('.col-md-9').siblings().children('.d-flex').children('.day-active').text();
        $('#modalDays').val(day).attr("disabled", true);
    }
    function edit(el) {
        var div = $(el).parents('.card').children('.card-body').children('.col-md-9').children('.container').children('#displayTimeslots').children('.overlayClose').children('.overClose');
        if ($(el).attr('aria-pressed')=='false') {
            $('input[name=addBtn]').val('');
            div.css('display','block')
            div.siblings('button').attr({"data-toggle":"modal","data-target":"#timeslotModal","onclick":"editBtn(this)"})
            $('.modal-footer>button[type=submit]').text('Update');
            $('.flex-fill.active').click()
        }
        else{
            div.css('display','none')
            $('input[name=editBtn]').val('');
        }
    }
    ////__Filters__\\\\
    function cancel(service) {
        $('.'+service).show();
    }

    function filter(service) { var sNameOptions='';
        $('#serviceLabel').text(service)
        $('#apply').attr('onclick','applyFilter("'+service+'")')
        $('#cancel').attr('onclick','cancel("'+service+'")')
        $('.'+service).each(function () {
            $(this).find('#'+service+'LocDiv .col').each(function() {
                if ($(this).find('h6').text()=='Name') {
                    var sName = $(this).find("h3").text();
                    sNameOptions += '<option>'+sName+'</option>';
                } 
            });
        });
        $('#serviceName').html(sNameOptions);
    }
    function applyFilter(S) {

        $('.'+S).each(function () {

            if( nameFilter($(this),S) &&  stateFilter($(this),S) && cityFilter($(this),S) && areaFilter($(this),S) && catFilter($(this),S) && desFilter($(this),S) )
                $(this).show();
            else $(this).hide();

        });
    }

    function nameFilter(div,S) {
        var name = $('#serviceName').val(), flag=false; if (name=='') return true;
        div.find('#'+S+'LocDiv .col').each(function() {
            if ($(this).find('h6').text()=='Name') {
                for (var i = 0; i < name.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), name[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function stateFilter(div,S) {
        var state = $('#statePermi').val(), flag=false; if (state=='') return true;
        div.find('#'+S+'LocDiv .col').each(function() {
            if ($(this).find('h6').text()=='State') {
                for (var i = 0; i < state.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), state[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function cityFilter(div,S) {
        var city = $('#cityPermi').val(), flag=false; if (city=='') return true;
        div.find('#'+S+'LocDiv .col').each(function() {
            if ($(this).find('h6').text()=='City') {
                for (var i = 0; i < city.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), city[i].split(' - ')[0] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function areaFilter(div,S) {
        var area = $('#areaPermi').val(), flag=false; if (area=='') return true;
        div.find('#'+S+'LocDiv .col').each(function() {
            if ($(this).find('h6').text()=='Area') {
                for (var i = 0; i < area.length; i++) {
                    if ( strcmp( $(this).find("h3").attr('value'), area[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    function catFilter(div,S) {
        var category = $('#category').val(), flag=false; if (category=='') return true;
        div.find('#'+S+'Div div').each(function() {
            if ($(this).find('h6').text()=='Category') {
                for (var i = 0; i < category.length; i++) {
                    switch (category[i]) {
                        case 'Lawyer':
                            if ( strcmp( $(this).find("h3").text(), category[i] ) ) flag = true; break;
                        case 'Non Lawyer':
                            if ( !strcmp( $(this).find("h3").text(), 'Lawyer' ) ) flag = true; break;
                    }
                } 
            } 
        }); return flag;
    }
    function desFilter(div,S) {
        var designation = $('#designation').val(), flag=false; if (designation=='') return true;
        div.find('#'+S+'Div div').each(function() {
            if ($(this).find('h6').text()=='Designation') {
                for (var i = 0; i < designation.length; i++) {
                    if ( strcmp( $(this).find("h3").text(), designation[i] ) ) flag = true;
                } 
            } 
        }); return flag;
    }
    //__str compare__
    function strcmp(str1='', str2='') {
        if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
        return false;
    }
</script>
