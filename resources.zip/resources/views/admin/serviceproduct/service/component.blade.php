@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; $exists=ucfirst($serviceName); @endphp
<div class="card mb-0 px-3 pb-3 {{ucfirst($serviceName)}}">
    <div class="card-header pt-3 pl-3">
        <div class="">
            <div class="row px-2">
                <div class="col-9">
                    <div class="row text-white" id="{{ucfirst($serviceName)}}LocDiv">
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">Name</h6>
                            <h3>{{ $service['name']??'' }}</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">State</h6>
                            <h3>{{ (Clas::isPlace($state))? $state:'All' }}</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">City</h6>
                            <h3>{{ (isset($cityAll))? 'All':$city }}</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">Area</h6>
                            <h3 value="{{$key??''}}">{{ (isset($areaAll))? 'All':($area['area']??'All') }}</h3>
                        </div>
                    </div>
                </div>
                <?php if (Clas::isPlace($state)) $State=$state; else $State='';
                    if(Clas::isPlace($district)&&Clas::isPlace($city)&&empty($onlyState)){ if (isset($cityAll)) { $District=$district; $City=''; } else { $District=$district; $City=$city; } }
                    if(Clas::isPlace($key)&&empty($onlyState)&&empty($onlyCity)){ if (isset($areaAll)) $Akey=''; else $Akey=$key; }
                ?>
                <div class="col-3 d-flex align-items-center mobile-align-top mobile-px-0 h-fit">
                    <form action="{{route('sp.services.update','edit')}}" class="col-md-6 m-0 pl-2 pr-0" method="POST"> @csrf @method('PUT')
                        <input type="hidden" name="state" value="{{$State}}">
                        <input type="hidden" name="district" value="{{$District??''}}">
                        <input type="hidden" name="city" value="{{$City??''}}">
                        <input type="hidden" name="area" value="{{$Akey??''}}">
                        <input type="hidden" name="areaName" value="{{$area['area']??''}}">
                        <input type="hidden" name="serviceName" value="{{$serviceName}}">
                        <input type="hidden" name="Skey" value="{{$Skey}}">
                        <input type="hidden" name="imageToBeDelete" value="{{$service['imageName']??''}}">
                        <button type="submit" name="btn" class="btn btn-sm btn-primary btn-block" value="">Edit</button>
                    </form>
                    <form action="{{route('sp.services.destroy',1)}}" class="col-md-6 m-0 pl-2 pr-0" id="delform" method="POST"> @csrf @method('DELETE')
                        <input type="hidden" name="state" value="{{$State}}">
                        <input type="hidden" name="district" value="{{$District??''}}">
                        <input type="hidden" name="city" value="{{$City??''}}">
                        <input type="hidden" name="area" value="{{$Akey??''}}">
                        <input type="hidden" name="serviceName" value="{{$serviceName}}">
                        <input type="hidden" name="Skey" value="{{$Skey}}">
                        <button type="button" name="btn" class="btn btn-sm btn-primary btn-block"  onclick="deleteImg(this,'{{ $service['imageName']??'' }}','{{strtolower($serviceName)}}')">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-4 d-flex border rounded-bottom">
        <div class="col-md mobile-px-0 pl-0">
            <div class="d-flex flex-column justify-content-center">
                <img src="{{ $service['image']??'' }}" alt="{{ $service['imageName']??'' }}" width="100%">
            </div>
        </div>
        <div class="col-md-9 d-flex align-items-center table-responsive">
            <div class="container mx-auto pl-0">
                <div class="row d-md-flex justify-content-between" id="{{ucfirst($serviceName)}}Div">
                    <div class="col-md-5">
                        <h6 class="heading-small text-muted mb-0">ID</h6>
                        <h3>{{ $Skey }}</h3>
                    </div>
                    <div class="col-md-3">
                        <h6 class="heading-small text-muted mb-0">Category</h6>
                        <h3>{{ $service['category']??'N/A' }}</h3>
                    </div>
                    <div class="col-md-4">
                        <h6 class="heading-small text-muted mb-0">Designation</h6>
                        <h3>{{ $service['designation']??'N/A' }}</h3>
                    </div>
                </div>
                <div class="row d-md-flex justify-content-between mt-3">
                    <div class="col-md-5">
                        <h6 class="heading-small text-muted mb-0">Age Group</h6>
                        <h3>{{ ($service['minAge']??'N/A').' - '.($service['maxAge']??'N/A') }}</h3>
                    </div>
                    @if(isset($service['credits']))
                    <div class="col-md-4">
                        <h6 class="heading-small text-muted mb-0">Credits</h6>
                        <h3>{{ $service['credits']??'N/A' }}</h3>
                    </div>
                    @endif
                    @if(isset($service['storage']))
                    <div class="col-md-4">
                        <h6 class="heading-small text-muted mb-0">Storage</h6>
                        <h3>{{ $service['storage']??'N/A' }} GB</h3>
                    </div>
                    @endif
                </div>
                <div class="row d-md-flex justify-content-between my-3">
                    <div class="col-md-5">
                        <h6 class="heading-small text-muted mb-0">Validity</h6>
                        <h3>{{ $service['validity']??'N/A' }} days</h3>
                    </div>
                    <div class="col-md-3">
                        <h6 class="heading-small text-muted mb-0">Price</h6>
                        <h3>{{ $service['price']??'N/A' }}</h3>
                    </div>
                    <div class="col-md-4">
                        <h6 class="heading-small text-muted mb-0">Description</h6>
                        <h3>{{ $service['desc']??'N/A' }}</h3>
                    </div>
                </div>
                @if(isset($service['limit']))
                <div class="row d-md-flex justify-content-between">
                    <div class="col-md">
                        <h6 class="heading-small text-muted mb-0">Activation Period</h6>
                        <h3>{{ Clas::activePeroid($service['limit']) }}</h3>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>