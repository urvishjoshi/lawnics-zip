<?php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; $exists=ucfirst($serviceName);
    if (Clas::isPlace($state)) $State=$state; else $State='';
    if(Clas::isPlace($district)&&Clas::isPlace($city)&&empty($onlyState)){ if (isset($cityAll)) { $District=$district; $City=''; } else { $District=$district; $City=$city; } }
    if(Clas::isPlace($key??'')&&empty($onlyState)&&empty($onlyCity)){ if (isset($areaAll)) $Akey=''; else $Akey=$key??''; }
?>
<div class="card-body py-3 d-flex border">
    <div class="d-flex align-items-center table-responsive">
        <div class="container mx-auto pl-0">
            <div class="row d-sm-flex justify-content-around">
                <div class="col-sm">
                    <h6 class="heading-small text-muted mb-0">Size</h6>
                    <h3>{{ $paper['size'] }}</h3>
                </div>
                <div class="col-sm">
                    <h6 class="heading-small text-muted mb-0">Color</h6>
                    <h3>{{ $paper['color'] }}</h3>
                </div>
                <div class="col-sm">
                    <h6 class="heading-small text-muted mb-0">Quality</h6>
                    <h3>{{ $paper['quality'] }}</h3>
                </div>
                <div class="col-sm">
                    <h6 class="heading-small text-muted mb-0">Credits</h6>
                    <h3>{{ $paper['credits'] }}</h3>
                </div>
                <div class="col-sm">
                    <h6 class="heading-small text-muted mb-0">Pages/<b>Rupees</b></h6>
                    <h3>{{ $paper['pages']}}/<b>₹{{$paper['rupees'] }}</b></h3>
                </div>
            </div>
        </div>
        <div class="col-sm-auto d-flex justify-content-end align-items-center mobile-align-top mobile-px-0 h-fit px-0">
                <div class="d-flex">
                    <form action="{{ route('sp.papers.show','edit') }}" method="POST" onclick="click(event)" id="editForm" class="mb-0">
                        <input type="hidden" name="statePermi" value="{{ $State??'' }}">
                        <input type="hidden" name="districtPermi" value="{{ $District??'' }}">
                        <input type="hidden" name="cityPermi" value="{{ $City??'' }}">
                        <input type="hidden" name="areaPermi" value="{{ $Akey??'' }}">
                        <button class="btn btn-sm btn-dark mr-2" type="submit" id="editBtn" name="editBtn" value="{{$Pkey}}" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-pen"></i> Edit</button>
                    </form>
                    <form action="{{ route('sp.papers.destroy',$Pkey) }}" method="POST" class="mb-0"> @csrf @method('DELETE')
                        <input type="hidden" name="deleteState" value="{{ $State??'' }}">
                        <input type="hidden" name="deleteDistrict" value="{{ $District??'' }}">
                        <input type="hidden" name="deleteCity" value="{{ $City??'' }}">
                        <input type="hidden" name="deleteAreaKey" value="{{ $Akey??'' }}">
                        <input type="hidden" name="deleteArea" value="{{ $area['area']??'' }}">
                        <button type="submit" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
                    </form>
                </div>
            </div>
    </div>
</div>
