<?php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; $exists=ucfirst($serviceName); ?>
<div class="card mb-0 px-3 pb-3">
    <div class="card-header pt-3 pl-3">
        <div class="">
            <div class="row px-2">
                <div class="col">
                    <div class="row text-white">
                        <div class="col-4">
                            <h6 class="heading-small text-muted mb-0">State</h6>
                            <h3>{{ (Clas::isPlace($state))? $state:'All' }}</h3>
                        </div>
                        <div class="col-4">
                            <h6 class="heading-small text-muted mb-0">City</h6>
                            <h3>{{ (isset($cityAll))? 'All':$city }}</h3>
                        </div>
                        <div class="col-4">
                            <h6 class="heading-small text-muted mb-0">Area</h6>
                            <h3>{{ (isset($areaAll))? 'All':($area['area']??'All') }}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>