@extends('admin.layouts.app')
@section('title','Papers')
@section('content')
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3 mb-3">
                <div class="row align-items-center">
                    <div class="col mobile-col-12">
                        <h3 class="mb-0 mx-1">Paper Size & Quality</h3>
                    </div>
                    <div class="col">
                    </div>
                    <div class="col-3 mobile-col-12 align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-sm btn-primary w-100 mt-2"  data-toggle="modal" data-target="#exampleModal" onclick="add()">Add</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Projects table -->
            @if($locations<1)
                <center><div class="card-body"><h2>No areas created yet</h2></div></center>
            @else
                @foreach($locations as $state => $s) <?php $serviceName='Papers'; ?>
                    @if($state=='Papers') <?php $cityAll=1; $onlyState=1; $areaAll=1;?>
                            @foreach($s as $Pkey => $paper)
                                @if(empty($head))
                            @include('admin.serviceproduct.paper.components.head') <?php $head=1; ?>
                            @endif
                                @include('admin.serviceproduct.paper.components.body')
                            @endforeach <?php unset($cityAll); unset($onlyState); unset($areaAll); $head=null;?>
                        </div>
                    @endif

                    @foreach($s as $district => $d)
                        @if($district=='Papers') <?php $cityAll=1; $areaAll=1; $onlyCity=1;?>
                            @foreach($d as $Pkey => $paper)
                                @if(empty($head))
                                @include('admin.serviceproduct.paper.components.head') <?php $head=1; ?>
                                @endif
                                @include('admin.serviceproduct.paper.components.body')
                            @endforeach <?php unset($cityAll); unset($areaAll); unset($onlyCity); $head=null;?>
                            </div>
                        @endif

                        @foreach($d as $city => $c) @if(Clas::isService($district)) <?php continue; ?> @endif
                            @if(is_array($c) || is_object($c))
                                @foreach($c as $key => $area)

                                    @if($key=='Papers')
                                        @foreach($area as $Pkey => $paper) 
                                            @if(empty($head))
                                            @include('admin.serviceproduct.paper.components.head') <?php $head=1; ?>
                                            @endif
                                            @include('admin.serviceproduct.paper.components.body')
                                        @endforeach <?php $head=null; ?>
                                        </div>
                                    @endif

                                    @if(isset($area['Papers']))
                                        @foreach($area['Papers'] as $Pkey => $paper)
                                            @if(empty($head))
                                            @include('admin.serviceproduct.paper.components.head') <?php $head=1; ?>
                                            @endif
                                            @include('admin.serviceproduct.paper.components.body')
                                        @endforeach <?php $head=null; ?>
                                    </div>
                                    @endif

                                @endforeach
                            @endif
                        @endforeach
                    @endforeach
                @endforeach
                {{-- @if($exists!='Papers')
                    <center><div class="card-body"><h2>No Papers created yet</h2></div></center>
                @endif <?php $serviceName=null; $exists=null?> --}}
            @endif
        </div>
    </div>
</section>

@include('admin.serviceproduct.paper.modal')

@section('jquery')
@include('admin.layouts.assets.multiLocationAjax')
<script>

    $(document).ready(function() {
        $('.select2').select2();
        var key, editState, editCity, editDistrict, editAreaKey, editArea, editBtn;
        $("form[id=editForm]").on('submit',function(event){
            event.preventDefault();
            document.getElementById("load").style.display = 'block';
            $('.modal-footer>button[name=submitBtn]').text('Update');
            key = $(this).find("button[type=submit]:focus" ).val();
            editState = $(this).find('input[name=statePermi]').val();
            editCity = $(this).find('input[name=cityPermi]').val();
            editDistrict = $(this).find('input[name=districtPermi]').val();
            editAreaKey = $(this).find('input[name=areaPermi]').val();
            editArea = $(this).find('input[name=areaName]').val();
            editBtn = $(this).find('button[name=editBtn]').val();
            $('input[name=updateBtn]').val(key);
            $('input[name=oldState]').val(editState);
            $('input[name=oldCity]').val(editCity);
            $('input[name=oldDistrict]').val(editDistrict);
            $('input[name=oldAreaKey]').val(editAreaKey);
            $('input[name=oldBtn]').val(editBtn);
            $('#statePermi, #cityPermi, #areaPermi').attr('disabled','disabled');
            $.ajax({
                method:"GET",
                url: $(this).attr('action'),
                data: {
                    'state':    editState,
                    'city':     editCity,
                    'district': editDistrict,
                    'areaKey':  editAreaKey,
                    'area':     editArea,
                    'editBtn':  editBtn,
                    '_token':   '{{csrf_field()}}',
                    '_method':  '{{method_field('GET')}}',
                },
                dataType:'JSON',
                success:function(data){
                    $('#statePermi').html(data.state);
                    // $('#districtPermi').html(data.district);
                    $('#cityPermi').html(data.city);
                    $('#areaPermi').html(data.area);
                    $('select[name=color]').val(data.color);
                    $('select[name=quality]').val(data.quality);
                    $('input[name=size]').val(data.size);
                    $('input[name=credits]').val(data.credits);
                    $('input[name=pages]').val(data.pages);
                    $('input[name=rupees]').val(data.rupees);
                    document.getElementById("load").style.display = 'none';
                }
            });
        });
        $('[name=submitBtn]').on('click',function (event) {

            $('#statePermi, #cityPermi, #areaPermi').removeAttr('disabled');
            $(this).parents('form').submit();
        })
    });
</script>
@endsection

@endsection
<script>
    function add() {
        $('.modal-footer>button[name=submitBtn]').text('Add');
        $('input[name=updateBtn]').val("");
        $('#statePermi, #cityPermi, #areaPermi').attr('disabled',false);
    }
</script>