<!-- Modal -->
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="{{ route('sp.papers.store') }}" class="modal-content" method="POST" name="submitForm">
            @csrf @method('POST')
            <div class="modal-header py-3">
                <h2 class="title m-0" id="exampleModalLabel">Add/Edit</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body py-0">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="statePermi">State</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="statePermi" style="width: 100%;" data-select2-id="0" tabindex="-1" aria-hidden="true" id="statePermi" name="statePermi[]" placeholder="statePermi">
                            @foreach($locations as $state => $s)
                                @if(Clas::isPlace($state))
                                    <option>{{ $state }}</option>
                                @endif
                            @endforeach
                            </select>
                        </div>
                    </div>
                    {{-- <input type="hidden" id="district" name="district"> --}}
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="cityPermi">City</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="cityPermi" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" id="cityPermi" name="cityPermi[]" placeholder="cityPermi">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md">
                        <div class="form-group">
                            <label class="form-control-label" for="areaPermi">Area</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="areaPermi" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" id="areaPermi" name="areaPermi[]" placeholder="areaPermi">
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md">
                        <div class="form-group">
                            <label class="form-control-label" for="size">Paper size</label>
                            <input type="text" name="size" id="size" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="credits">Credits</label>
                            <input type="number" id="credits" name="credits" class="form-control" min="1" value="1" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="color">Paper color</label>
                            <select name="color" class="form-control" id="color" required>
                                <option>White</option>
                                <option>Green</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="quality">Paper quality</label>
                            <select name="quality" class="form-control" id="quality" required>
                                <option>70 GSM</option>
                                <option>80 GSM</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md">
                        <div class="form-group">
                            <label class="form-control-label" for="rupees">Rupees</label>
                            <input type="number" id="rupees" name="rupees" class="form-control" min="1" value="1" required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="pages">Pages</label>
                            <input type="number" id="pages" name="pages" class="form-control" min="1" value="1" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <img src="{{asset('icons/load.gif')}}" alt="" width="40" class="mr-2" id="load" style="display: none;">
                <input type="hidden" name="oldState" value="">
                <input type="hidden" name="oldDistrict" value="">
                <input type="hidden" name="oldCity" value="">
                <input type="hidden" name="oldAreaKey" value="">
                <input type="hidden" name="oldBtn" value="">
                <input type="hidden" name="updateBtn" value="">
                <button type="button" class="btn btn-dark" name="submitBtn">Add</button>
                <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
            </div>
        </form>
    </div>
</div>