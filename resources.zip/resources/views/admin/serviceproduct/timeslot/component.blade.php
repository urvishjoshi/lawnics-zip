<div class="card mb-0 px-3 pb-3 timeslotDiv">
    <div class="card-header pt-3 pl-3">
        <div class="">
            <div class="row px-2">
                <div class="col-8">
                    <div class="row text-white" id="areaDiv">
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">Area</h6>
                            <h3 value="{{$key}}">{{ $area['area'] }}</h3>
                        </div>
                    </div>
                    <div class="row text-white" id="locationsDiv">
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">Country</h6>
                            <h3>India</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">State</h6>
                            <h3>{{ $state }}</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">District</h6>
                            <h3>{{ $district }}</h3>
                        </div>
                        <div class="col">
                            <h6 class="heading-small text-muted mb-0">City</h6>
                            <h3>{{ $city }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-4 d-flex align-items-center mobile-align-top mobile-px-0 h-fit">
                    <button class="btn btn-sm btn-primary flex-fill" data-toggle="modal" data-target="#timeslotModal" onclick="add(this)" value="{{$state.'/'.$district.'/'.$city.'/'.$key}}">Add</button>
                    <button class="btn btn-sm btn-primary flex-fill" data-toggle="button" aria-pressed="false" onclick="edit(this)" value="{{$state.'/'.$district.'/'.$city.'/'.$key}}">Edit</button>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-4 d-flex border rounded-bottom">
        <div class="col-md-3 mobile-px-0">
            <div class="d-flex flex-column text-center" value="{{$state.'/'.$district.'/'.$city.'/'.$key}}">
                <div id="day1" class="day"></div><HR>
                <div id="day2" class="day"></div><HR>
                <div id="day3" class="day"></div><HR>
                <div id="day4" class="day"></div><HR>
                <div id="day5" class="day"></div><HR>
                <div id="day6" class="day"></div><HR>
                <div id="day7" class="day"></div>
            </div>
        </div>
        <div class="col-md-9 d-flex align-items-center table-responsive">
            <div class="container d-md-flex justify-content-center mx-auto">
                <div class="col-md my-2 mobile-d-flex" id="displayTimeslots">
                    <center><h2>Click on a day to get its timeslots</h2></center>
                {{-- @if(isset($area['Timeslots']))
                    @foreach($area['Timeslots'] as $day => $timeslots) @php $flag=-1; @endphp
                        {{'ll'}}
                        @if(\Carbon\Carbon::now('Asia/Kolkata')->englishDayOfWeek==ucfirst($day)) 
                        {{$day}}
                                @php $flag++; @endphp
                            @foreach($timeslots as $tKey => $timeslot)
                            <div class="overlayClose d-inline-flex">
                                <span class="overClose" onclick="closeBtn(this)">&times;</span>
                                <button class="btn btn-dark mx-2 my-2" value="{{$state.'/'.$district.'/'.$city.'/'.$key.'/Timeslots/'.$day.'/'.$tKey}}">{{$timeslot['fromHour'].':'.$timeslot['fromMinute'].' '.$timeslot['fromTime']}} - {{$timeslot['toHour'].':'.$timeslot['toMinute'].' '.$timeslot['toTime']}}</button>
                            </div>
                            @endforeach
                        @else @php $flag--; @endphp
                        @endif
                    @endforeach
                        @if($flag<1)
                            <h2 class="text-center">No timeslots created yet 1</h2>
                        @endif
                @else
                    <h2 class="text-center">No timeslots created yet 2</h2>
                @endif --}}
                </div>
            </div>
        </div>
    </div>
</div>