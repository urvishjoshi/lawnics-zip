@extends('admin.layouts.app')
@section('link')
    <link rel="stylesheet" href="{{ asset('assets/css/summernote-bs4.min.css') }}">
    <style> .btn-light,.btn-light.disabled{color:black;}.btn-light:hover{color: inherit;}.dropdown-item>h3{color: #32325d!important;}</style>
@endsection
@section('title','Terms & Policy - Printing Partner App')
@section('content')
<section>
    <!-- Reports Header -->
    <div class="m-3">
        <!-- Page content -->
        <div class="">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header p-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0 mx-1">Terms & Policy</h3>
                                </div>
                                <div class="col-6">
                                </div>
                            </div>
                        </div>
                        <!-- Projects table -->
                        <div class="table-responsive">
                            <div class="card-body pad p-0">
                                <form action="{{ route('ppa.terms&policy.store') }}" method="POST">
                                    @csrf @method('POST')
                                    <textarea class="textarea" placeholder="Place some text here" name="termsandpolicy" style="width: 100%; height: 400px!important; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                                    <span id="content" hidden>{{$about['htmlText']}}</span>
                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-dark m-3">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@section('jquery')
<script src="{{ asset('assets/js/summernote-bs4.min.js') }}"></script>
<script>
    $(function () {
      $('.textarea').summernote();
      var html = $('#content').text()
      $('p').html(html)
    })
</script>
@endsection

@endsection