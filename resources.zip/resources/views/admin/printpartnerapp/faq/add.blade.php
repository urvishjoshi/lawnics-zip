@extends('admin.layouts.app')
@section('link')
    <link rel="stylesheet" href="{{ asset('assets/css/summernote-bs4.min.css') }}">
    <style> .btn-light,.btn-light.disabled{color:black;}.btn-light:hover{color: inherit;}.dropdown-item>h3{color: #32325d!important;} label{color: white!important;}</style>
@endsection
@section('title','Add FAQ - Printing Partner App')
@section('content')
<section>
    <!-- Reports Header -->
    <div class="m-3">
        <!-- Page content -->
        <div class="">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header p-3">
                            <div class="row">
                                <div class="col-lg-6">
                                <form action="{{ route('ppa.faqs.store') }}" method="POST">
                                    @csrf @method('POST')
                                    <div class="form-group">
                                        <label class="form-control-label" for="heading">Heading</label>
                                        <input type="text" id="heading" name="heading" class="form-control @error('heading') is-invalid @enderror" placeholder="Heading">
                                        @error('heading')
                                            <span class="invalid-feedback pl-1" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="form-control-label" for="question">Question</label>
                                        <input type="text" id="question" name="question" class="form-control @error('question') is-invalid @enderror" placeholder="Question">
                                        @error('question')
                                            <span class="invalid-feedback pl-1" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="form-control-label" for="language">Language</label>
                                        <select name="language" id="language" class="form-control">
                                            <option>English</option>
                                            <option>Hindi</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0 mx-1">Answer</h3>
                                </div>
                                <div class="col-6">
                                </div>
                            </div>
                        </div>
                        <!-- Projects table -->
                        <div class="table-responsive">
                            <div class="card-body pad p-0">
                                    <textarea class="textarea" data-placeholder="Place some text here" name="answer" style="width: 100%; height: 400px!important; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                                    <span id="content" hidden></span>
                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-dark m-3">Add</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@section('jquery')
<script src="{{ asset('assets/js/summernote-bs4.min.js') }}"></script>
<script>
    $(function () {
        $('.textarea').summernote();
        var html = $('#content').text()
        $('p').html(html)
    })
</script>
@endsection

@endsection