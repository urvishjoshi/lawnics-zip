@extends('admin.layouts.app')
@section('title','Credits')
@section('content')
<style>h3{color: white;margin:0;}
.bg-black{background-color: black;}
.h3,.h5{color: white!important;}
</style>
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile mb-0 bg-black border-bottom">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="d-flex justify-content-center">
							<a href="#">
								<div class="overlay">
									<img src="{{asset('icons/1.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:37px;margin-left: 37px;"> 
								</div>
								<img src="{{asset('icons/'.($user[$uId]['gender'] ?? 'Male').'.png')}}" alt="user_icon">
							</a>
						</div>
					</div>
				</div>
				<div class="card-body pt-2">
					<div class="text-center">
						<h5 class="h3">
							{{($user[$uId]['first_name'] ?? 'N/A').' '.($user[$uId]['last_name'] ?? 'N/A')}}
						</h5>
						<div class="h5 font-weight-400">
							<i class="ni location_pin mr-2"></i>{{($user[$uId]['city'] ?? 'N/A').', '.($user[$uId]['state'] ?? 'N/A')}}
						</div>
					</div>
				</div>
			</div>
			<div class="card-header pl-3 ">
				<div class="">
					<div class="row text-white text-center">
						<div class="col-lg">
							<h6 class="heading-small text-muted mb-0">Credits purchase</h6>
							<h3 id="printCPurchase">N/A</h3>
						</div>
						<div class="col-lg">
							<h6 class="heading-small text-muted mb-0">Balance</h6>
							<h3 id="printBalance">N/A</h3>
						</div>
						<div class="col-lg">
							<h6 class="heading-small text-muted mb-0">Credit spent</h6>
							<h3 id="printCSpent">N/A</h3>
						</div>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center" id="table">
					<thead class="thead-light">
	                    <tr>
		                    <th>Icon Photo
		                    <th>Date & time
		                    <th>OR / TR ID
		                    <th>Items
		                    <th>Credits purchase
		                    <th>Credits spent
		                    <th>Credits balance
	                    </tr>
	                </thead>
	                <tbody>
                	@foreach($user as $key => $value)

	                    @if(isset($value['transactions']))
	                        @foreach($value['transactions'] as $date => $t)
	                        @if(is_array($t) || is_object($t))
	                            @foreach($t as $time => $transact)
	                            @if(empty($transact['Storage']))
	                                <tr>
	                                	<td>N/A</td>
	                                    <th>
	                                    	@php $d = explode('_',$date); $T = explode('_',$time); $balance=$value['transactions']['total_credits']??'N/A'; @endphp
		                                    {{ $d[2].'/'.$d[1].'/'.$d[0].' & '.$T[0].':'.$T[1]}}
	                                    </th>
	                                    <td>N/A</td>
	                                    <td>N/A</td>
	                                    <td>{{$transact['added_credits']??0}}</td>
	                                    <td>0</td>
	                                    <td>{{$transact['current_credits']??0}}</td>
	                                </tr>
		                        @endif
	                            @endforeach
	                        @endif
	                        @endforeach
	                    @else
		                    <tr><td colspan="7"><h2>No transactions done yet</h2></td></tr>
	                    @endif {{-- transactions --}}
                        <input type="hidden" id="balanceCredits" value="{{$balance??0}}">

	                    @if(isset($value['orders']))
	                        @foreach($value['orders'] as $date => $o)
	                            @foreach($o as $time => $orders)
	                            @foreach($orders as $oId => $order)
									<tr>
	                                	<td>
	                                		@if(is_array($order)||is_array($order))
	                                    		@foreach($order as $f => $file)
	                                    		<?php if(isset($file['image'])) $src=$file['image']; ?>
	                                    		@endforeach
	                                    	@endif
	                                    	<img src="{{$src}}" alt="file" width="100%" class="border"></img>
	                                	</td>
	                                    <th>
	                                    	<?php $d = explode('_',$date); $T = explode('_',$time); $items=0; ?>
		                                    {{ $d[2].'/'.$d[1].'/'.$d[0].' & '.$T[0].':'.$T[1]}}
	                                    </th>
	                                    <td>{{ $oId }}</td>
	                                    <td>
	                                    	@if(is_array($order)||is_array($order))
	                                    		@foreach($order as $f => $file)
	                                    		<?php isset($file['copies'])?($items=$items+$file['copies']):'' ?>
	                                    		@endforeach
	                                    	@endif
	                                    	{{$items}}
	                                    </td>
	                                    <td>0</td>
	                                    <td>{{$order['total_creds']??0}}</td>
	                                    <td>0</td>
	                                </tr>
	                            @endforeach
	                            @endforeach
	                        @endforeach
	                    @else
		                    <tr>
			                    <td colspan="7"><h2>No orders done yet</h2></td>
		                    </tr>
	                    @endif {{-- orders --}}

                    @endforeach
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });

        $('#printBalance').html($('#balanceCredits').val());
        $('#printCPurchase').html(CSum(4));
        $('#printCSpent').html(CSum(5));


        function CSum(cell) {
            var table = document.getElementById("table"), sumVal = 0;
            for(var i = 1; i < table.rows.length; i++)
                sumVal = sumVal + parseFloat(table.rows[i].cells[cell].innerHTML);
            return sumVal;
        }
    });
</script>
@endsection

@endsection