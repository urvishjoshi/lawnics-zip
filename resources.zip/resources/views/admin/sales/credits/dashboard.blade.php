@extends('admin.layouts.app')
@section('title','Credits - Sales')
@section('content')
<style>
    /*thead>tr>th{padding-left: initial; padding-right: initial;}*/
    /*tbody>tr>th,td{padding-left: 1%!important; padding-right: 1%!important;}*/
</style>
<section>
    <!-- Reports Header -->
    <div class="m-3">
        <!-- Page content -->
        <div class="">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header border-0 p-3">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0 mx-1">Credits</h3>
                                </div>
                                <div class="col-6">
                                </div>
                                <div class="col align-self-end">
                                    <div class="input-group input-group-sm">
                                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                                        <div class="input-group-append">
                                            <button class="btn btn-sm border" type="submit">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="d-flex">
                                        <a href="{{ route('s.credits.show','report') }}" class="btn btn-block btn-sm btn-primary mt-2">Reports</a>
                                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Projects table -->
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush text-center">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Designation</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Balance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($users as $key => $user)
                                <tr>
                                    <th>{{$key}}</th>
                                    <th>
                                        <a href="{{ route('s.credits.show','profile') }}?id={{$key}}" class="d-flex">
                                            <div class="overlay">
                                            </div>
                                            <img src="{{asset('icons/'.ucfirst($user['gender'] ?? 'N/A').'.png')}}" width="32" alt="user_icon" class="mr-1">
                                            <span class="my-auto mx-auto">{{ ($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A')  }}
                                            </span>
                                        </a>
                                    </th>
                                    <td>{{$user['category']??'N/A'}}</td>
                                    <td>{{$user['designation']??'N/A'}}</td>
                                    <td>{{$user['state']??'N/A'}}</td>
                                    <td>{{$user['city']??'N/A'}}</td>
                                        @if(isset($user['transactions']))
                                            @foreach($user['transactions'] as $date => $t)
                                            @if(is_array($t) || is_object($t))
                                                <td>{{$user['transactions']['total_credits']??'N/A'}}</td>
                                                    <?php break; ?>    
                                            @endif
                                            @endforeach
                                        @else
                                        <td>N/A</td>
                                        @endif
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@section('jquery')
<script>
    $('.select2').select2();
    
    $('#cancel').click(function (event) {
        $('tbody tr*').show();
    });
    $('#apply').click(function (event) {
        $('tbody tr').each(function() {
            if ( desFilter($(this)) &&  catFilter($(this)) && stateFilter($(this)) && cityFilter($(this))) 
                $(this).show();
            else $(this).hide();
        });
    });

    function catFilter(tr) {
        var category = $('#category').val(), flag=false; if (category=='') return true;
        for (var i = 0; i < category.length; i++) {
            switch (category[i]) {
                case 'Lawyer':
                    if ( strcmp( tr.find("td").eq(0).text(), category[i] ) ) flag = true; break;
                case 'Non Lawyer':
                    if ( !strcmp( tr.find("td").eq(0).text(), 'Lawyer' ) ) flag = true; break;
            }
        } return flag;
    }
    function desFilter(tr) {
        var designation = $('#designation').val(), flag=false; if (designation=='') return true;
        for (var i = 0; i < designation.length; i++) {
            if ( strcmp( tr.find("td").eq(1).text(), designation[i] ) ) flag = true;
        } return flag;
    }
    function stateFilter(tr) {
        var state = $('#state').val(), flag=false; if (state=='') return true;
        for (var i = 0; i < state.length; i++) {
            if ( strcmp( tr.find("td").eq(2).text(), state[i] ) ) flag = true;
        } return flag;
    }
    function cityFilter(tr) {
        var city = $('#city').val(), flag=false; if (city=='') return true;
        for (var i = 0; i < city.length; i++) {
            if ( strcmp( tr.find("td").eq(3).text(), city[i] ) ) flag = true;
        } return flag;
    }
    //__str compare__
    function strcmp(str1='', str2='') {
        if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
        return false;
    }
</script>
@endsection

@endsection