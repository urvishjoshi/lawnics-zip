@extends('admin.layouts.app')
@section('link')
<style>.crop{
      white-space: nowrap; 
  width: 20%!important; 
  overflow: hidden;
  text-overflow: ellipsis; display: inline-block;
    }</style>
@endsection
@section('title','FAQ - Advocate App')
@section('content')
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">FAQ's</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('aa.faqs.show','add') }}" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Heading</th>
                            <th>Question</th>
                            <th width="10%">Answer</th>
                            <th>Language</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if($faqs < 1)
                        <tr>
                            <td colspan="5"><h3>No English FAQs created yet</h3></td>
                        </tr>
                    @else
                        @foreach($faqs as $heading => $value)
                            <tr>
                                <th>{{$heading}}</th>
                        @foreach($value as $que => $ans)
                                <td>{{$que}}</td>
                                <td>{{$ans}}</td>
                                <th>English</th>
                                <td>
                                    <div class="d-flex">
                                        <a href="{{ route('aa.faqs.show','edit?id='.$heading.'&lang=English') }}" class="btn btn-sm btn-dark">Edit</a>
                                        <form action="{{route('aa.faqs.destroy',1)}}" method="POST">
                                            @csrf @method('DELETE')
                                            <input type="hidden" name="question" value="{{$que}}">
                                            <input type="hidden" name="heading" value="{{$heading}}">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                        @endforeach
                            </tr>
                        @endforeach
                    @endif
                    @if($faqsH < 1)
                        <tr>
                            <td colspan="5"><h3>No Hindi FAQs created yet</h3></td>
                        </tr>
                    @else
                        @foreach($faqsH as $heading => $value)
                            <tr>
                                <th>{{$heading}}</th>
                        @foreach($value as $que => $ans)
                                <td>{{$que}}</td>
                                <td>{{strip_tags($ans)}}</td>
                                <th>Hindi</th>
                                <td>
                                    <div class="d-flex">
                                        <a href="{{ route('aa.faqs.show','edit?id='.$heading.'&lang=Hindi') }}" class="btn btn-sm btn-dark">Edit</a>
                                        <form action="{{route('aa.faqs.destroy',2)}}" method="POST">
                                            @csrf @method('DELETE')
                                            <input type="hidden" name="question" value="{{$que}}">
                                            <input type="hidden" name="heading" value="{{$heading}}">
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </td>
                        @endforeach
                            </tr>
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

@section('jquery')
<script>
</script>
@endsection

@endsection
