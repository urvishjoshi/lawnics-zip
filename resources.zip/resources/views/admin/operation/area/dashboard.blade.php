@extends('admin.layouts.app')
@section('title','Area')
@section('content')
<section>
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Area</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('o.areas.show','add') }}" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Map</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>District</th>
                            <th>City</th>
                            <th>Area name</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if($locations<1)
                        <tr>
                            <td colspan="7"><h3>No Areas created yet</h3></td>
                        </tr>
                    @else
                        @foreach($locations as $state => $s) @if(!Clas::isPlace($state)) @php continue; @endphp @endif
                        @foreach($s as $district => $d) @if(!Clas::isPlace($district)) @php continue; @endphp @endif
                        @foreach($d as $city => $c) @if(!Clas::isPlace($city)) @php continue; @endphp @endif
                        @foreach($c as $key => $area) @if(!Clas::isPlace($key)) @php continue; @endphp @endif
                            <tr>
                                <td><i class="fas fa-map-marked-alt"></i></td>
                                <td>India</td>
                                <td>{{ $state }}</td>
                                <td>{{ $district }}</td>
                                <td>{{ $city }}</td>
                                <th value="{{$key}}">{{ $area['area'] }}</th>
                                <td>
                                    <div class="d-flex">
                                        <a href="{{ route('o.areas.show','edit?id='.$key) }}" class="btn btn-sm btn-dark"><i class="fas fa-pen"></i> Edit</a>
                                        <form action="{{route('o.areas.destroy',$key)}}" method="POST">
                                            @csrf @method('DELETE')
                                            <input type="hidden" name="state" value="{{ $state }}">
                                            <input type="hidden" name="district" value="{{ $district }}">
                                            <input type="hidden" name="city" value="{{ $city }}">
                                            <input type="hidden" name="area" value="{{ $area['area'] }}">
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        @endforeach
                        @endforeach
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
@include('admin.layouts.assets.locationsModal')

@section('jquery')
@include('admin.layouts.assets.allLocationsAjax')
<script>
    $(document).ready(function() {
        $('.select2').select2();

        $('#cancel').click(function (event) {
            $('tbody tr*').show();
        });

        $('#apply').click(function (event) {
            $('tbody tr').each(function() {
                if (stateFilter($(this)) && districtFilter($(this)) && cityFilter($(this)) && areaFilter($(this)))
                    $(this).show();
                else $(this).hide();
            });
        });
        function stateFilter(tr) {
            var state = $('#SAstate').val(), flag=false; if (state=='') return true;
            for (var i = 0; i < state.length; i++) {
                if ( strcmp( tr.find("td").eq(2).text(), state[i] ) ) flag = true;
            } return flag;
        }
        function districtFilter(tr) {
            var district = $('#SAdistrict').val(), flag=false; if (district=='') return true;
            for (var i = 0; i < district.length; i++) {
                if ( strcmp( tr.find("td").eq(3).text(), district[i] ) ) flag = true;
            } return flag;
        }
        function cityFilter(tr) {
            var city = $('#SAcity').val(), flag=false; if (city=='') return true;
            for (var i = 0; i < city.length; i++) {
                if ( strcmp( tr.find("td").eq(4).text(), city[i] ) ) flag = true;
            } return flag;
        }
        function areaFilter(tr) {
            var area = $('#SAarea').val(), flag=false; if (area=='') return true;
            for (var i = 0; i < area.length; i++) {
                if ( strcmp( tr.find("th").attr('value'), area[i] ) ) flag = true;
            } return flag;
        }
        //__str compare__
        function strcmp(str1='', str2='') {
            if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
            return false;
        }
    });
</script>
@endsection

@endsection
