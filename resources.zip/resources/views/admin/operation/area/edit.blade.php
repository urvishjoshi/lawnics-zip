@extends('admin.layouts.app')
@section('link')
	{{-- <style>#polygonCoords{height: 12px;border: none;width: 100%;}</style> --}}
@endsection
@section('title','Edit - Area')
@section('content')
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile mb-3 border-bottom">
				<div class="card-img-top">
					<button class="btn btn-dark px- map-btn1" data-toggle="button" aria-pressed="false" style="position: absolute;z-index: 99;max-width: 50%;float: right;top: 85.1%;right: 17.8%;" id="polygon">
                        <i class="fas fa-draw-polygon" style="font-size: 14.2px;" title="Place polygon"></i>
                    </button>
                    <button class="btn btn-dark px-3 map-btn2" data-toggle="button" aria-pressed="false" style="position: absolute;z-index: 99;max-width: 50%;float: right;top: 85.1%;right: 12%;" id="marker" title="Place marker">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                    </button>
                    <button class="btn btn-dark px-3 map-btn3" style="position: absolute;z-index: 99;max-width: 50%;float: right;top: 85.1%;right: 6%;" id="clear" title="Clear all">
                        <i class="fa fa-eraser" aria-hidden="true"></i>
                    </button>
					<div id="map" style="width:100%;height:400px;"></div>
					<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCGBvEqVEGH6-O3GAzwlH1aon9m0iVslTo&callback=myMap"></script>
				</div>
			</div>
			<div class="card-body pt-0 pl-3">
				<form action="{{route('o.areas.update',$area['key'])}}" method="POST">
					@csrf @method('PUT')
					<input type="hidden" name="polygonCoords" id="polygonCoords" value="@for($i=0;$i<count($area['polygonCoords']);$i++){{$area['polygonCoords'][$i][0]}},{{$area['polygonCoords'][$i][1]}}@if($i<count($area['polygonCoords'])-1),@else"@endif @endfor>
					<p id="polygonCoords"></p>
					<input type="hidden" name="markerCoords" id="markerCoords" value="{{$area['center'][0][0]}},{{$area['center'][0][1]}}">
					<h6 class="heading-small text-muted">Data</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">Country</label>
									<input type="text" id="input-username" class="form-control" placeholder="India" value="India" readonly>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="state">State</label>
									<input type="text" id="state" name="state" class="form-control @error('state') is-invalid @enderror" placeholder="State" value="{{ $area['state'] }}" readonly>
									@error('state')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="district">District</label>
									<input type="text" id="district" name="district" class="form-control @error('district') is-invalid @enderror" placeholder="District" value="{{ $area['district'] }}" readonly>
									@error('district')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="city">City</label>
									<input type="text" id="city" name="city" class="form-control @error('city') is-invalid @enderror" placeholder="City" value="{{ $area['city'] }}" readonly>
									@error('city')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="area">Area</label>
									<input type="text" id="area" name="area" class="form-control @error('area') is-invalid @enderror" placeholder="Area" value="{{ $area['area'] }}">
									@error('area')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="zoom">Zoom level</label>
									<input type="number" id="zoom" name="zoom" class="form-control @error('zoom') is-invalid @enderror" placeholder="Zoom" min="5" value="{{ $area['zoom'] }}">
									@error('zoom')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
						</div>
					</div>
					<div class="d-flex justify-content-end">
						<button class="btn btn-dark" name="btnUpdate">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>

@endsection
<script>

    var marker;
    var polygon;
    var destinations;
    var currentPath;
    var infowindow;
    var map;
    var oldPoly;
    var markerPressed;
    var polygonPressed;
    var myLatLng = {
     	lat: {{$area['center'][0][0]}}, 
     	lng: {{$area['center'][0][1]}}
    };

    function myMap() {
        var mapProp= {
			center: myLatLng,
			zoom:{{$area['zoom']}},
			gestureHandling: 'greedy'
		};
		map = new google.maps.Map(document.getElementById("map"),mapProp);

		setPolygon();

		placeMarker(map,myLatLng);

		// google.maps.event.addListener(map, 'click', function(event) {
		// 	if(pressed!='false') {
		// google.maps.event.addListener(polygon.getPath(), 'set_at', processVertex);
	 //    google.maps.event.addListener(polygon.getPath(), 'insert_at', processVertex);
		// 		placePolygon(event);
		// 	}
		// });
    }
    function setPolygon() {
		destinations = new google.maps.MVCArray();

		@for($i=0;$i<count($area['polygonCoords']);$i++) 
			destinations.push(new google.maps.LatLng({{$area['polygonCoords'][$i][0]}},{{$area['polygonCoords'][$i][1]}}));
		@endfor

		var polygonOptions = {
			path : destinations,
			strokeColor: '#ff0000',
			strokeWeight: 1,
			editable: true,
			clickable: false
		}
		polygon = new google.maps.Polygon(polygonOptions);
		polygon.setMap(map);
    }
    function placePolygon(event) {
		currentPath = polygon.getPath();
		currentPath.push(event.latLng);
		// google.maps.event.addListener(polygon.getPath(), 'set_at', processVertex);
	 //    google.maps.event.addListener(polygon.getPath(), 'insert_at', processVertex);
	}
    function processVertex(e) {
    	var logStr=[];
    	for (var i = 0; i < this.getLength(); i++) {
    		logStr[i] = this.getAt(i).toUrlValue(6);
    		$('#polygonCoords').val((logStr));
    		$('p[id=polygonCoords]').text((logStr));
	    }
	}
    function placeMarker(map, location) {
		if (!marker || !marker.setPosition) {
			marker = new google.maps.Marker({
				position: location,
				map: map,
				animation: google.maps.Animation.DROP
			});
		} else {
			marker.setPosition(location);
		}
	}

</script>
@section('jquery')
<script>
	oldPoly = $('#oldPoly').val()
	$('#clear').click(function(argument) {
			polygon.setPath([]);
		    path = polygon.getPath();
			$("p[id=polygonCoords]").text('');
			if(marker)
				marker.setPosition(null) 
		}
	);
	$('#marker').click(function(argument) {
		markerPressed = $(this).attr("aria-pressed")
		// polygonPressed = $("#polygon").attr("aria-pressed")
		// if(polygonPressed=='true')
		// 	$('#polygon').button('dispose');
		google.maps.event.addListener(map, 'click', function(event) {
			if (markerPressed=='false') {
				placeMarker(map, event.latLng);
				var a=[];
				a.push(event.latLng.lat())
				a.push(event.latLng.lng())
	        	document.getElementById("markerCoords").value = a;
	        }
	    });
	});
	$('#polygon').click(function(argument) {
		polygonPressed = $(this).attr("aria-pressed")
		// markerPressed = $('#marker').attr("aria-pressed")
		// if(markerPressed=='true')
		// 	$('#marker').button('dispose');
		google.maps.event.addListener(map, 'click', function(event) {
			if (polygonPressed=='false') {
				google.maps.event.addListener(polygon.getPath(), 'set_at', processVertex);
			    google.maps.event.addListener(polygon.getPath(), 'insert_at', processVertex);
				placePolygon(event);
			}
		});
	});
</script>
@endsection