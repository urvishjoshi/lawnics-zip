@extends('admin.layouts.app')
@section('title','Sub Admin')
@section('content')
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Sub Admins</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('o.subadmin.show','add') }}" class="btn btn-block btn-sm btn-primary mt-2">Add</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Name</th>
                            <th>Role</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Area</th>
                            <th width="3%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if(!$subadmins)
                        <tr><td colspan="7"><h2>No Sub Admins made yet</h2></td></tr>
                    @else
                        @foreach($subadmins as $key => $subadmin)
                            @if(isset($subadmin['subadmin']))
                            <tr>
                                <td class="d-flex">
                                    <div class="overlay">
                                        <img src="{{asset('icons/1.png')}}" class="overicon" alt="badge"> 
                                    </div>
                                    <img src="{{asset('icons/'.$subadmin['gender'].'.png')}}" width="32" alt="user_icon" class="mr-1">
                                    <span class="my-auto mx-auto">{{ $all[$key]->displayName }}
                                    </span>
                                </td>
                                <th>{{$subadmin['role']}}</th>
                                <td>
                                    @if(isset($subadmin['permissions']['statePermi']))
                                        @for($i=0 ; $i < 2 ; $i++)
                                            <span class="bg-dark rounded text-white py-1 px-2">{{$subadmin['permissions']['statePermi'][$i]??''}}</span>
                                            
                                        @endfor
                                        @if(count($subadmin['permissions']['statePermi'])>=2) ... @endif
                                    @else N/A
                                    @endif
                                </td>
                                <td>
                                    @if(isset($subadmin['permissions']['cityPermi']))
                                        @for($i=0 ; $i < 2 ; $i++)
                                            <span class="bg-dark rounded text-white py-1 px-2">{{$subadmin['permissions']['cityPermi'][$i]??''}}</span>
                                            
                                        @endfor
                                        @if(count($subadmin['permissions']['cityPermi'])>=2) ... @endif
                                    @else N/A
                                    @endif
                                </td>
                                <td>
                                    @if(isset($subadmin['permissions']['areaPermi']))
                                        @for($i=0 ; $i < 2 ; $i++)
                                            <span class="bg-dark rounded text-white py-1 px-2">{{$subadmin['permissions']['areaPermi'][$i]??''}}</span>
                                            
                                        @endfor
                                        @if(count($subadmin['permissions']['areaPermi'])>=2) ... @endif
                                    @else N/A
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex">
                                        
                                        <a class="btn btn-sm btn-primary" href="{{ route('o.subadmin.show','edit?id='.$key) }}" style="background-color: black;color: white;">Edit</a>
                                        <form action="{{route('o.subadmin.destroy',$key)}}" method="POST" class="mb-0"> @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>

                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endif
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
@include('admin.layouts.assets.locationsModal')

@section('jquery')
@include('admin.layouts.assets.allLocationsAjax') 
<script>
    $(document).ready(function() {
        $('.select2').select2();

        $('#cancel').click(function (event) {
            $('tbody tr*').show();
        });
        $('#apply').click(function (event) {
            $('tbody tr').each(function() {
                if (stateFilter($(this)) && districtFilter($(this)) && cityFilter($(this)) && areaFilter($(this)))
                    $(this).show();
                else $(this).hide();
            });
        });
        function stateFilter(tr) {
            var state = $('#SAstate').val(), flag=false; if (state=='') return true;
            for (var i = 0; i < state.length; i++) {
                if ( strcmp( tr.find("td").eq(1).text(), state[i] ) ) flag = true;
            } return flag;
        }
        function districtFilter(tr) {
            var district = $('#SAdistrict').val(), flag=false; if (district=='') return true;
            for (var i = 0; i < district.length; i++) {
                if ( strcmp( tr.find("td").eq(2).text(), district[i] ) ) flag = true;
            } return flag;
        }
        function cityFilter(tr) {
            var city = $('#SAcity').val(), flag=false; if (city=='') return true;
            for (var i = 0; i < city.length; i++) {
                if ( strcmp( tr.find("td").eq(2).text(), city[i] ) ) flag = true;
            } return flag;
        }
        function areaFilter(tr) {
            var area = $('#SAarea').val(), flag=false; if (area=='') return true;
            for (var i = 0; i < area.length; i++) {
                if ( strcmp( tr.find("td").eq(2).text(), area[i] ) ) flag = true;
            } return flag;
        }
        //__str compare__
        function strcmp(str1='', str2='') {
            if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
            return false;
        }
    });
</script>
@endsection

@endsection
