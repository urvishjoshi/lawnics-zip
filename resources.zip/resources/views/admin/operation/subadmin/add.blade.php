@extends('admin.layouts.app')
@section('title','Profile - Sub Admin')
@section('content')
<style>
.bg-black{background-color: black;}
#baner-name > *{color: white!important;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
</style>
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
@php use \App\Http\Controllers\Admin\Operation\SubAdminController as SAClas; @endphp
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile border-bottom bg-black mb-0 pb-3">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<div class="overlay">
									<img src="{{asset('icons/1.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:{{isset($user['profile'])?40:20}}px;margin-left: {{isset($user['profile'])?40:20}}px;"> 
								</div>
								<img src="{{asset('icons/Male.png')}}" alt="user_icon" width="55" height="55" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				<div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
					<div class="d-flex justify-content-end">
						{{-- <a href="#" class="btn btn-sm btn-info  mr-4 ">Connect</a> --}}
						<button id="edit" class="btn btn-white float-right" data-toggle="button" aria-pressed="false">Edit</button>
					</div>
				</div>
				<div class="card-body pt-0 pb-1">
					<div class="text-center" id="baner-name">
						<h5 class="h3">
							{{($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A')}}
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>{{($user['city'] ?? 'N/A').', '.($user['state'] ?? 'N/A')}}
						</div>
					</div>
				</div>
			</div>
			<div class="card-body p-0">
				<form action="{{ route('o.subadmin.store') }}" method="POST">
					@csrf @method('POST')
					<div class="card-header mb-3">Username & Password</div>
					<div class="px-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="username">Username</label>
									<input type="email" id="username" name="username" class="form-control @error('username') is-invalid @enderror" placeholder="username@lawnics.com" value="{{old('username')}}">
									@error('username')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="password">Password</label>
									<input type="password" id="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Password">
									@error('password')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="password_confirmation">Confirm Password</label>
									<input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Confirm Password">
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Personal information</div>
					<div class="px-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="name">Name</label>
									<input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror" placeholder="Abc Xyz" value="{{old('name')}}">
									@error('name')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="gender">Gender</label>
									<select name="gender" id="gender" class="form-control">
										<option value="Male">Male</option>
										<option value="Female">Female</option>
										<option value="Other">Other</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="dob">Date of birth</label>
									<input type="date" id="dob" name="dob" class="form-control" placeholder="dd-mm-yyyy" value="{{old('dob')}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="email">Email</label>
									<input type="text" id="email" name="email" class="form-control" placeholder="name@gmail.com" value="{{old('email')}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="idnumber">ID number</label>
									<input type="text" id="idnumber" name="idnumber" class="form-control" placeholder="ID number" value="{{old('idnumber')}}">
								</div>
								<div class="form-group">
									<label class="form-control-label" for="address">Address</label>
									<input type="text" id="address" name="address" class="form-control" placeholder="Address" value="{{old('address')}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="image">Identity Card</label>
									<div class="col-sm border p-0">
										<img src="" alt="No image uploaded" width="100%">
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Professional information</div>
					<div class="px-lg-4">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="role">Role</label>
									<input type="text" id="role" name="role" class="form-control @error('role') is-invalid @enderror" placeholder="Role name" value="{{old('role')}}">
									@error('role')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="statePermi12">State</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="statePermi12" style="width: 100%;" data-select2-id="0" tabindex="-1" aria-hidden="true" id="statePermi12" name="statePermi[]" placeholder="statePermi12">
									@foreach($userStates as $state)
									    <option>{{ $state }}</option>
									@endforeach
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="cityPermi12">City</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="cityPermi12" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" id="cityPermi12" name="cityPermi[]" placeholder="cityPermi12">
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="areaPermi12">Area</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="areaPermi12" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" id="areaPermi12" name="areaPermi[]" placeholder="areaPermi">
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Permissions</div>
					<div class="px-lg-4">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="userPermi">User</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="userPermi" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="userPermi[]" placeholder="userPermi">
										<option>List</option>
										<option>Verification</option>
										<option>Segmentation</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="ppPermi">Printing Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="ppPermi" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="ppPermi[]" placeholder="ppPermi">
										<option>List</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="dpPermi">Delivery Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="dpPermi" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="dpPermi[]" placeholder="dpPermi">
										<option>List</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="uxPermi">UX</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="uxPermi" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="uxPermi[]" placeholder="uxPermi">
										<option>Badges</option>
										<option>Engagement portals</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="operationPermi">Operations</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="operationPermi" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" name="operationPermi[]" placeholder="operationPermi">
										<option>Area</option>
										<option>Subadmin</option>
										<option>Order</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="salesPermi">Sales</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="salesPermi" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true" name="salesPermi[]" placeholder="salesPermi">
										<option>Credit</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="transactionPermi">Transactions</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="transactionPermi" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" name="transactionPermi[]" placeholder="transactionPermi">
										<option>User</option>
										<option>Printing partner</option>
										<option>Delivery partner</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="spPermi">Service & Product</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="spPermi" style="width: 100%;" data-select2-id="10" tabindex="-1" aria-hidden="true" name="spPermi[]" placeholder="spPermi">
										<option>Service</option>
										<option>Timeslot</option>
										<option>Paper size & Quality</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="amPermi">App Management</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="amPermi" style="width: 100%;" data-select2-id="11" tabindex="-1" aria-hidden="true" name="amPermi[]" placeholder="amPermi">
										<option>Advocate - About</option>
										<option>Advocate - Privacy Policy</option>
										<option>Advocate - Terms & Policy</option>
										<option>Advocate - FAQ's</option>
										<option>Printing Partner - About</option>
										<option>Printing Partner - Privacy Policy</option>
										<option>Printing Partner - Terms & Policy</option>
										<option>Printing Partner - FAQ's</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="p-4 d-flex justify-content-end">
						<button type="submit" name="btnAdd" class="btn btn-dark">Add</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
@include('admin.layouts.assets.multiLocationAjax')
@endsection

@endsection