@extends('admin.layouts.app')
@section('title','Profile - Sub Admin')
@section('content')
<style>
.bg-black{background-color: black;}
#baner-name > *{color: white!important;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
</style>
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
@php use \App\Http\Controllers\Admin\Operation\SubAdminController as SAClas; @endphp
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile border-bottom bg-black mb-0 pb-3">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<div class="overlay">
									<img src="{{asset('icons/1.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:{{isset($user->profile)?40:20}}px;margin-left: {{isset($user->profile)?40:20}}px;"> 
								</div>
								<img src="{{asset('icons/'.ucfirst($subadmin['gender']).'.png')}}" alt="user_icon" width="55" height="55" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				<div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
					<div class="d-flex justify-content-end">
						<button id="edit" class="btn btn-white float-right" data-toggle="button" aria-pressed="false">Edit</button>
					</div>
				</div>
				<div class="card-body pt-0 pb-1">
					<div class="text-center" id="baner-name">
						<h5 class="h3">
							{{ $user->displayName }}
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>{{ $subadmin['role'] }}
						</div>
					</div>
				</div>
			</div>
			<div class="card-body p-0">
				<form action="{{ route('o.subadmin.update',$user->uid) }}" method="POST">
					@csrf @method('PUT')
					<div class="card-header mb-3">Username & Password</div>
					<div class="px-3">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="username">Username</label>
									<input type="email" id="username" name="username" class="form-control @error('username') is-invalid @enderror" placeholder="username@lawnics.com" value="{{ $user->email }}" disabled>
									@error('username')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="password">Password</label>
									<input type="password" id="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Password" disabled>
									@error('password')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="password_confirmation">Confirm Password</label>
									<input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Confirm Password" disabled>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Personal information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="name">Name</label>
									<input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror" placeholder="Display name" value="{{ $user->displayName }}">
									@error('name')
									    <span class="invalid-feedback pl-1" role="alert">
									        <strong>{{ $message }}</strong>
									    </span>
									@enderror
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="gender">Gender</label>
									<select name="gender" id="gender" class="form-control">
										<option {{$subadmin['gender']=='Male'?'selected':''}}>Male</option>
										<option {{$subadmin['gender']=='Female'?'selected':''}}>Female</option>
										<option {{$subadmin['gender']=='Other'?'selected':''}}>Other</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="dob">Date of birth</label>
									<input type="date" id="dob" name="dob" class="form-control" placeholder="dd-mm-yyyy" value="{{$subadmin['dob']??'N/A'}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="email">Email</label>
									<input type="text" id="email" name="email" class="form-control" placeholder="name@gmail.com" value="{{$subadmin['email']??'N/A'}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="idnumber">ID number</label>
									<input type="text" id="idnumber" name="idnumber" class="form-control" placeholder="ID number" value="{{$subadmin['idnumber']??'N/A'}}">
								</div>
								<div class="form-group">
									<label class="form-control-label" for="address">Address</label>
									<input type="text" id="address" name="address" class="form-control" placeholder="Address" value="{{$subadmin['address']??'N/A'}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="image">Identity Card</label>
									<div class="col-sm border p-0">
										<img src="" alt="No image uploaded" width="100%">
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Professional information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="role">Role</label>
									<input type="text" id="role" name="role" class="form-control" placeholder="Role name" value="{{ $subadmin['role'] }}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="statePermi12">State</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="statePermi12" style="width: 100%;" data-select2-id="0" tabindex="-1" aria-hidden="true" name="statePermi[]" id="statePermi12" placeholder="statePermi12">
									@foreach($userStates as $state)
									    <option
									    @for($i=0;isset($subadmin['permissions']['statePermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['statePermi'][$i]==$state ? 'selected' : ''}} @endfor>{{ $state }}</option>
									@endforeach
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="cityPermi12">City</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="cityPermi12" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="cityPermi[]" id="cityPermi12" placeholder="cityPermi12">
									@foreach($userCities as $city)
									    <option
									    @for($i=0;isset($subadmin['permissions']['cityPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['cityPermi'][$i]==$city ? 'selected' : ''}} @endfor>{{ $city }}</option>
									@endforeach
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="areaPermi12">Area</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="areaPermi12" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="areaPermi[]" id="areaPermi12" placeholder="areaPermi12">
									{{-- @foreach($locations as $state => $s)
									@if(Clas::isPlace($state))

									@foreach($s as $district => $d)
									@if(Clas::isPlace($district))
									@foreach($d as $city => $c)

									@if(Clas::isPlace($city))
									<optgroup label="{{$city.' - '.$district}}">

										@foreach($c as $key => $area)
										@if(Clas::isPlace($key))
											<option value="{{ $area['area'] }}" @for($i=0;isset($subadmin['permissions']['areaPermi'][$i]);$i++)
	                                    		{{$subadmin['permissions']['areaPermi'][$i]==$area['area'] ? 'selected' : ''}} @endfor>
												{{ $area['area'] }}
											</option>
										@endif
										@endforeach

									</optgroup>
									@endif

									@endforeach
									@endif
									@endforeach

									@endif
									@endforeach --}}
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Permissions</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="userPermi">User</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="userPermi" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="userPermi[]" placeholder="userPermi">
										<option @for($i=0;isset($subadmin['permissions']['userPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['userPermi'][$i]=='List' ? 'selected' : ''}} @endfor>List</option>
										<option @for($i=0;isset($subadmin['permissions']['userPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['userPermi'][$i]=='Verification' ? 'selected' : ''}} @endfor>Verification</option>
										<option @for($i=0;isset($subadmin['permissions']['userPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['userPermi'][$i]=='Segmentation' ? 'selected' : ''}} @endfor>Segmentation</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="ppPermi">Printing Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="ppPermi" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="ppPermi[]" placeholder="ppPermi">
										<option @for($i=0;isset($subadmin['permissions']['ppPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['ppPermi'][$i]=='List' ? 'selected' : ''}} @endfor>List</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="dpPermi">Delivery Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="dpPermi" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="dpPermi[]" placeholder="dpPermi">
										<option @for($i=0;isset($subadmin['permissions']['dpPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['dpPermi'][$i]=='List' ? 'selected' : ''}} @endfor>List</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="uxPermi">UX</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="uxPermi" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="uxPermi[]" placeholder="uxPermi">
										<option @for($i=0;isset($subadmin['permissions']['uxPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['uxPermi'][$i]=='Badges' ? 'selected' : ''}} @endfor>Badges</option>
										<option @for($i=0;isset($subadmin['permissions']['uxPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['uxPermi'][$i]=='Engagement portals' ? 'selected' : ''}} @endfor>Engagement portals</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="operationPermi">Operations</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="operationPermi" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" name="operationPermi[]" placeholder="operationPermi">
										<option @for($i=0;isset($subadmin['permissions']['operationPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['operationPermi'][$i]=='Area' ? 'selected' : ''}} @endfor>Area</option>
										<option @for($i=0;isset($subadmin['permissions']['operationPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['operationPermi'][$i]=='Subadmin' ? 'selected' : ''}} @endfor>Subadmin</option>
										<option @for($i=0;isset($subadmin['permissions']['operationPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['operationPermi'][$i]=='Order' ? 'selected' : ''}} @endfor>Order</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="salesPermi">Sales</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="salesPermi" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true" name="salesPermi[]" placeholder="salesPermi">
										<option @for($i=0;isset($subadmin['permissions']['salesPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['salesPermi'][$i]=='Credits' ? 'selected' : ''}} @endfor>Credits</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="transactionPermi">Transactions</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="transactionPermi" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" name="transactionPermi[]" placeholder="transactionPermi">
										<option @for($i=0;isset($subadmin['permissions']['transactionPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['transactionPermi'][$i]=='User' ? 'selected' : ''}} @endfor>User</option>
										<option @for($i=0;isset($subadmin['permissions']['transactionPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['transactionPermi'][$i]=='Printing partner' ? 'selected' : ''}} @endfor>Printing partner</option>
										<option @for($i=0;isset($subadmin['permissions']['transactionPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['transactionPermi'][$i]=='Delivery partner' ? 'selected' : ''}} @endfor>Delivery partner</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="spPermi">Service & Product</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="spPermi" style="width: 100%;" data-select2-id="10" tabindex="-1" aria-hidden="true" name="spPermi[]" placeholder="spPermi">
										<option @for($i=0;isset($subadmin['permissions']['spPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['spPermi'][$i]=='Service' ? 'selected' : ''}} @endfor>Service</option>
										<option @for($i=0;isset($subadmin['permissions']['spPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['spPermi'][$i]=='Timeslot' ? 'selected' : ''}} @endfor>Timeslot</option>
										<option @for($i=0;isset($subadmin['permissions']['spPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['spPermi'][$i]=='Paper size & Quality' ? 'selected' : ''}} @endfor>Paper size & Quality</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="amPermi">App Management</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="amPermi" style="width: 100%;" data-select2-id="11" tabindex="-1" aria-hidden="true" name="amPermi[]" placeholder="amPermi">
                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Advocate - About' ? 'selected' : ''}} @endfor>Advocate - About</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Advocate - Privacy Policy' ? 'selected' : ''}} @endfor>Advocate - Privacy Policy</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Advocate - Terms & Policy' ? 'selected' : ''}} @endfor>Advocate - Terms & Policy</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=="Advocate - FAQ's" ? 'selected' : ''}} @endfor>Advocate - FAQ's</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Printing Partner - About' ? 'selected' : ''}} @endfor>Printing Partner - About</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Printing Partner - Privacy Policy' ? 'selected' : ''}} @endfor>Printing Partner - Privacy Policy</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=='Printing Partner - Terms & Policy' ? 'selected' : ''}} @endfor>Printing Partner - Terms & Policy</option>

                                    		<option @for($i=0;isset($subadmin['permissions']['amPermi'][$i]);$i++)
                                    		{{$subadmin['permissions']['amPermi'][$i]=="Printing Partner - FAQ's" ? 'selected' : ''}} @endfor>Printing Partner - FAQ's</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="p-4 d-flex justify-content-end">
						<button type="submit" name="btnAdd" class="btn btn-dark">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();

        $('form *').attr('disabled','disabled');
        $('#edit').click(function(argument) {
        	switch ($(this).attr("aria-pressed")) {
        		case 'false':
        			$('form *').removeAttr('disabled');
        			break;
        		case 'true':
        			$('form *').attr('disabled','disabled');
        			break;
        	}
        });
    });
</script>
@include('admin.layouts.assets.multiLocationAjax')
@endsection

@endsection