@extends('admin.layouts.app')
@section('link')
    <style>
        a > .pr-5 >h5{color: white;}
    </style>
@endsection
@section('title','Orders - Operations')
@section('content')
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Orders</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('o.orders.show','reports') }}" class="btn btn-block btn-sm btn-primary mt-2">Report</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                    </div>
                </div>
            </div>
            </div>
            <div class="mb-3">
            {{-- Passbook --}}
            @foreach($users as $key => $user)
            @if(isset($user['orders']))  @php $flag=1; @endphp
                @foreach($user['orders'] as $date => $t)
                @foreach($t as $time => $oid)
                @foreach($oid as $orderId => $order)
                    @include('admin.operation.order.component')
                @endforeach
                @endforeach
                @endforeach
            @endif
            @endforeach
            @if(empty($flag))
                <h2 class="text-center mt-3">No orders placed yet</h2>
            @endif
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-control-label" for="country">Country</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="country" id="country" disabled>
                        <option selected>India</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="state">State</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" id="state" name="state">
                        @foreach($userStates as $state)
                            <option>{{ $state }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="city">City</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" id="city" name="city" placeholder="City">
                    </select>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="area">Area name</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" id="area" name="area">
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="mode">Mode</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" id="mode" name="mode">
                        <option>Delivery</option>
                        <option>Pick from shop</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="status">Status</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" id="status" name="status">
                        <option>Pending</option>
                        <option>Delivered</option>
                    </select>
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">Apply</button>
      </div>
    </div>
  </div>
</div>

@section('jquery')
@include('admin.layouts.assets.allLocationsAjax')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection
