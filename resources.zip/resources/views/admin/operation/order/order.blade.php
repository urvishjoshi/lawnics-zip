@extends('admin.layouts.app')
@section('title','Order - Operations')
@section('content')
<style>h3{color: white;margin:0;}</style>
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card-header pt-3 pl-3 ">
				<div class="">
					<div class="row text-white">
						<div class="col-lg-2">
							<h6 class="heading-small text-muted mb-0">Order Id</h6>
							<h3>{{$id}}</h3>
						</div>
						<div class="col-lg-2">
							<h6 class="heading-small text-muted mb-0">Order type</h6>
							<h3>{{$order['order_type'] ??'N/A'}}</h3>
						</div>
						<div class="col-lg-8 d-flex justify-content-end align-items-end">
							<button class="btn btn-sm btn-primary">Complete</button>
							<button class="btn btn-sm btn-primary">Cancel</button>
						</div>
					</div>
						<hr class="mt-3 mb-3 text-white" style="border: 0.5px solid white;">
						<h3>Status</h3>
				</div>
			</div>
			@php $status=1;  //confirmed
				// if(strtolower($order['status']??'N/A')=='under process') $status=1;
				if(strtolower($order['status']??'N/A')=='pending') $status=2;
				// elseif(strtolower($order['status']??'N/A')=='printed') $status=3;
				elseif(strtolower($order['status']??'N/A')=='confirmed') $status=3;
				elseif(strtolower($order['status']??'N/A')=='rejected') $status=-1;
				$d = explode('_',$date); 
			@endphp
			<div class="card-body pt-4 pl-3">
				<div class="text-center">
					<div class="row">
						<div class="col">
							<img src="{{ asset('icons/confirmed.png') }}" alt="confirmed">
							<h4 class="mt-2">Order</h4>
							<h5>{{ $d[2].'/'.$d[1].'/'.$d[0] }}</h5>
							<h5>{{date('h:i A', strtotime( explode('_',$time)[0].':'.explode('_',$time)[1] ))}}</h5>
						</div>
						<div class="col">
							@if($status<2)
								@if ($status==-1)
									<img src="{{ asset('icons/'.($status==-1?'rejected':'under_process').'.png') }}" alt="">
								@else
									<img src="{{ asset('icons/'.($status==-1?'rejected':'under_process').'.png') }}" alt="">
									<h4 class="mt-2">Printing</h4>
									<h5>{{ $d[2].'/'.$d[1].'/'.$d[0] }}</h5>
									<h5>{{date('h:i A', strtotime( explode('_',$time)[0].':'.explode('_',$time)[1] ))}}</h5>
								@endif
							@else
								<img src="{{ asset('icons/'.($status>=3?'printed':'under_process').'.png') }}" alt="">
								<h4 class="mt-2">Printing</h4>
								<h5>{{ $d[2].'/'.$d[1].'/'.$d[0] }}</h5>
								<h5>{{date('h:i A', strtotime( explode('_',$time)[0].':'.explode('_',$time)[1] ))}}</h5>
							@endif
						</div>
						<div class="col">
							@if ($status<2)
								@if ($status==-1)
									<img src="{{ asset('icons/'.($status==-1?'delivered_0':'pending').'.png') }}" alt="">
								@else
									<img src="{{ asset('icons/'.($status==-1?'delivered_0':'pending').'.png') }}" alt="">
									<h4 class="mt-2">Printed</h4>
									<h5>Estimated time</h5>
									<h5>{{date('h:i A', strtotime( explode('_',$time)[0].':'.explode('_',$time)[1] ))}}</h5>
								@endif
							@else
								<img src="{{ asset('icons/'.($status>=3?'delivered':'delivered_0').'.png') }}" alt="">
								<h4 class="mt-2">Printed</h4>
								<h5>Estimated time</h5>
								<h5>{{date('h:i A', strtotime( explode('_',$time)[0].':'.explode('_',$time)[1] ))}}</h5>
							@endif
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Items</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Document ID</th>
		                    <th>Document name</th>
		                    <th>Quantity</th>
		                    <th>Paper type</th>
		                    <th>Total pages</th>
		                    <th>Credits</th>
	                    </tr>
	                </thead>
	                <tbody> @php $total=0; @endphp
	                @if(is_array($order))
		                @foreach($order as $doc)
		                @if(is_array($doc)) @php $total+=$doc['credits']??0; @endphp
		                	<tr>
			                    <th>{{$doc['filename']??'N/A'}}</th>
			                    <td>{{$doc['filename']??'N/A'}}</td>
			                    <td>{{$doc['copies']??'N/A'}}</td>
			                    <td>{{($doc['paper_color']??'N/A').' '.($doc['paper_size']??'N/A').' '.($doc['gsm']??'N/A')}}</td>
			                    <td>{{$doc['pages']??'N/A'}}</td>
			                    <td>{{$doc['credits']??'N/A'}}</td>
		                    </tr>
	                    @endif
		                @endforeach
		            @endif
	                    <tr>
	                    	<td colspan="6">
				            	<span class="btn btn-sm btn-dark" style="float: right;">{{$total}}</span>
	                    	</td>
	                    </tr>
	                </tbody>
	            </table>
	        </div>
	    </div>
	    <div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">User</h3>
					</div>
				</div>
			</div>
			<div class="card-body px-5">
				<div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Name</h6>
						<h4>{{($user['first_name']??'N/A').' '.($user['last_name']??'N/A')}}</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">ID</h6>
						<h4>{{$key}}</h4>
					</div>
		        </div>
		        <div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Mobile number</h6>
						<h4>{{$phone??'N/A'}}</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Rating by printing partner</h6>
						@for ($i = 0; $i < 5; ++$i)
						    <i class="font-20 fas fa-star"></i>
						@endfor
					</div>
		        </div>
		        <div class="row">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Reviews</h6>
						<h4 style="padding: 5px;border: 1px solid lightgrey;border-radius: 5px;width: fit-content;">Paper quality</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Comments</h6>
						<h4>Nice service</h4>
					</div>
		        </div>
	    	</div>
	    </div>
	    <div class="card mt-3 mb-0">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Printing Partner</h3>
					</div>
				</div>
			</div>
			<div class="card-body px-5">
				<div class="row mb-2">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Name</h6>
						<h4>{{$order['printing_partner_name']??'N/A'}}</h4>
					</div>
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">ID</h6>
						<h4>{{$order['printing_partner_name']??'N/A'}}</h4>
					</div>
		        </div>
		        <div class="row">
					<div class="col-md">
						<h6 class="heading-small text-muted mb-0">Shop address</h6>
						<h4>{{$order['printing_partner_location']??'N/A'}}</h4>
					</div>
					<div class="col-md-6">
						<h6 class="heading-small text-muted mb-0">Mobile number</h6>
						<h4>{{$phone['printing_partner_phone']??'N/A'}}</h4>
					</div>
		        </div>
		    </div>
	    </div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection