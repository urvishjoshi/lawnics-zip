<div class="card mb-0 mt-3">
	<div class="mx-3 pass-border-dark">{{-- single transaction [confirmed|under process|pending|printed|delivered|rejected]--}}
		<div class="">
			<a class="alert alert-{{ ($order['order_type'] ??'N/A')=='Pending'?'fail':'dark' }} d-flex mb-1 order-header" href="{{ route('o.orders.show','order?id='.$orderId) }}">
				<div class="pr-5">
					<h5>Order ID</h5>
					<h4 style="color: white">{{ $orderId }}</h4>
				</div>
				<div class="pr-5">
					<h5>Date</h5> @php $d = explode('_',$date); @endphp
					<h4 style="color: white">{{ $d[2].'/'.$d[1].'/'.$d[0] }}</h4>
				</div>
				<div class="pr-5">
					<h5>Timeslot</h5>
					<h4 style="color: white">{{ $order['order_type'] ??'N/A' }}</h4>
				</div>
				<div class="pr-5">
					<h5>Status</h5>
					<h4 style="color: white">{{ $order['status'] ??'N/A' }}</h4>
				</div>
				@php $status=1;  //confirmed
				// if(strtolower($order['status']??'N/A')=='under process') $status=1;
				if(strtolower($order['status']??'N/A')=='pending') $status=2;
				// elseif(strtolower($order['status']??'N/A')=='printed') $status=3;
				elseif(strtolower($order['status']??'N/A')=='confirmed') $status=3;
				elseif(strtolower($order['status']??'N/A')=='rejected') $status=-1;
				@endphp
				<icons class="flex-grow-1 text-right py-1 order-icons">
					<img src="{{ asset('icons/confirmed.png') }}" alt="confirmed">
					@if($status<2)
						<img src="{{ asset('icons/'.($status==-1?'rejected':'under_process').'.png') }}" alt="">
					@else
						<img src="{{ asset('icons/'.($status>=3?'printed':'under_process').'.png') }}" alt="">
					@endif
					@if ($status<2)
						<img src="{{ asset('icons/'.($status==-1?'delivered_0':'pending').'.png') }}" alt="">
					@else
						<img src="{{ asset('icons/'.($status>=3?'delivered':'delivered_0').'.png') }}" alt="">
					@endif
					{{-- <i class="fas fa-print {{$status>1?'text-success':''}}"></i>
					<i class="fas fa-hourglass-half {{$status>2?'text-success':''}}"></i>
					<i class="fas fa-truck {{$status>3?'text-success':''}}"></i>
					<i class="fas fa-check-circle {{$status>4?'text-success':''}}"></i> --}}
				</icons>
			</a>
			<div class="alert container mb-0">
				<div class="row mb-4 d-flex">
					<div class="col-md-4 pr-5">
						<h5>Mode</h5>
						<h4>Delivery</h4>
					</div>
					<div class="col-md-4 pr-5">
						<h5>User name</h5>
						<h4>Shubham Joshi</h4>
					</div>
					<div class="col-md-4 pr-5">
						<h5>Location</h5>
						<h4>India, Rajasthan, Jaipur</h4>
					</div>
				</div>
				<div class="row mb-4 d-flex">
					<div class="col-md-4 pr-5">
						<h5>Area</h5>
						<h4>Delivery</h4>
					</div>
					<div class="col-md-4 pr-5">
						<h5>Printing Partner</h5>
						<h4>Shubham Joshi</h4>
					</div>
					<div class="col-md-4 pr-5">
						<h5>Delivery Partner</h5>
						<h4>ABC DEF</h4>
					</div>
				</div>
				<div class="row d-flex">
					<div class="col-md-4 pr-5">
						<h5>Items</h5>
						<h4>4</h4>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>