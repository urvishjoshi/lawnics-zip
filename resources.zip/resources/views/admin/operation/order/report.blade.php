@extends('admin.layouts.app')
@section('title','Reports')
@section('content')
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card-body pt-3 pl-3">
				<form>
					<h4 class="heading-small text-muted">Range</h4>
					<div class="pl-lg-4">
						<h6 class="heading-small mb-0">Order ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Time</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">From</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">To</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<hr class="mt-0 mb-3" />
					<!-- Professional -->
					<h6 class="heading-small text-muted mb-2">Filter</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">Mode</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Delivery</option>
										<option>Pick from shop</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-last-name">Status</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Pending</option>
										<option>Delivered</option>
										<option>Cancelled</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<hr class="mt-0 mb-3" />
					<!-- Professional -->
					<h6 class="heading-small text-muted mb-2">Data points</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">Order</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Document ID</option>
										<option>Date</option>
										<option>Time</option>
										<option>Location</option>
										<option>Items</option>
										<option>Paper type</option>
										<option>Document name</option>
										<option>Quantity</option>
										<option>Total page</option>
										<option>Credits</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">User</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>User name</option>
										<option>User ID</option>
										<option>Mobile number</option>
										<option>Rating</option>
										<option>Reviews</option>
										<option>Comments</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">Priting Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Name</option>
										<option>Shop address</option>
										<option>Mobile number</option>
										<option>Rating</option>
										<option>Reviews</option>
										<option>Comments</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">Priting Partner</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Name</option>
										<option>Mobile number</option>
										<option>Rating</option>
										<option>Reviews</option>
										<option>Comments</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="d-flex justify-content-end">
						<button class="btn btn-success">Export</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection