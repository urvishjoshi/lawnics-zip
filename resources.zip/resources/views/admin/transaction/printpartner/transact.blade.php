@extends('admin.layouts.app')
@section('title','Transaction - Print Partners')
@section('content')
<style>h3,h4,h5{color: white;margin:0;}
.passBookBody h4{color: black;}
.bg-black{background-color: black;}
.h3,.h5{color: white!important;} .fa-angle-down{font-size: 12px;}
hr{border: 1px solid lightgrey!important;width: 100%;margin: 2% 0px 2% 0px;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
.collapseSwitch{cursor: pointer;}
</style>
<section>

    <div class="col p-3">
        <div class="card mb-0">
            <div class="card card-profile border-bottom bg-black mb-0 pb-3">
                <div class="card-img-top pt-7"></div>
                <div class="row justify-content-center">
                    <div class="col-sm-3 order-sm-2">
                        <div class="card-profile-image">
                            <a href="#">
                                <div class="overlay">
                                    <img src="{{asset('icons/0.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:{{isset($printpartner['profile'])?40:20}}px;margin-left: {{isset($printpartner['profile'])?40:20}}px;"> 
                                </div>
                                <img src="@if(isset($printpartner['profile'])) {{$printpartner['profile']}} @else {{asset('icons/'.ucfirst($printpartner['gender'] ?? 'N/A').'.png')}} @endif" alt="user_icon" width="{{isset($printpartner['profile'])?105:55}}" height="{{isset($printpartner['profile'])?105:55}}" class="rounded-circle">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
                    <div class="d-flex justify-content-end">
                    </div>
                </div>
                <div class="card-body pt-3 pb-1">
                    <div class="text-center" id="baner-name">
                        <h5 class="h3">
                            {{($printpartner['first_name'] ?? 'N/A').' '.($printpartner['last_name'] ?? 'N/A')}}
                        </h5>
                        <div class="h5 font-weight-300">
                            <i class="ni location_pin mr-2"></i>{{($printpartner['city'] ?? 'N/A').', '.($printpartner['state'] ?? 'N/A')}}
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-header pl-3 ">
                <div class="">
                    <div class="row text-white text-center">
                        <div class="col-lg">
                            <h6 class="heading-small text-muted mb-0">Total earned</h6>
                            <h3>15000</h3>
                        </div>
                        <div class="col-lg">
                            <h6 class="heading-small text-muted mb-0">Payment due</h6>
                            <h3>500</h3>
                        </div>
                    </div>
                </div>
                <HR>
                <div class="row align-items-center pl-1">
                    <div class="col">
                        <h6 class="heading-small text-muted mb-0">ID</h6>
                        <h3>4534747</h3>
                    </div>
                    <div class="col-6 d-flex justify-content-end align-self-end">
                        <a href="" class="btn btn-sm btn-primary mt-2">Pay / Receive</a>
                    </div>
                    <div class="col align-self-end">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-sm border" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="d-flex">
                            <button class="btn btn-block btn-sm btn-primary mt-2" data-toggle="modal" data-target="#datepicker">Sort</button>
                            <button class="btn btn-block btn-sm btn-primary" data-toggle="modal" data-target="#exampleModal">Filter</button>
                        </div>
                    </div>
                </div>
                <HR>
                <div class="row px-4">
                    <h3>Print</h3>
                </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Paper color</th>
                            <th>Paper size</th>
                            <th>Paper quality</th>
                            <th>Total pages</th>
                            <th>Pricing</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>White</td>
                            <td>A4 paper</td>
                            <td>80</td>
                            <td>50</td>
                            <td>250 / 1000 pages</td>
                            <td>100</td>
                        </tr>
                        <tr>
                            <td colspan="5"></td>
                            <td>
                                <span class="btn btn-danger">200</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card mb-3 mt-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Recharge (Credits)</h3>
                    </div>
                </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Packs</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Commission earned</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Basic pack</td>
                            <td>80</td>
                            <td>50</td>
                            <td>2</td>
                            <td>100</td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td>
                                <span class="btn btn-outline-success">200</span>
                            </td>
                            <td>
                                <span class="btn btn-outline-danger">200</span>
                            </td>
                            <td>
                                <span class="btn btn-success">200</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card mb-3 mt-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Passbook</h3>
                    </div>
                </div>
            </div>
            <div class="">
                {{-- Passbook --}}
                <div class="card mb-0 pt-3">
                    <div class="mx-3 pass-border-dark mb-3">{{-- single transaction --}}
                        <div class="">
                            <div class="alert alert-{{ ($order['order_type'] ??'N/A')=='Pending'?'fail':'dark' }} d-flex mb-1 order-header">
                                <div class="pr-5">
                                    <h5 class="heading-small text-muted">Transaction ID</h5>
                                    <h4>413654195</h4>
                                </div>
                                <div class="pr-5">
                                    <h5 class="heading-small text-muted">Date</h5>
                                    <h4>24/06/2020</h4>
                                </div>
                                <div class="pr-5">
                                    <h5 class="heading-small text-muted">Time</h5>
                                    <h4>10:00 PM</h4>
                                </div>
                                <div class="pr-5">
                                    <h5 class="heading-small text-muted">Status</h5>
                                    <h4>Pending</h4>
                                </div>
                                <div class="pr-5">
                                    <h5 class="heading-small text-muted">Recharge through</h5>
                                    <h4>Printing partner</h4>
                                </div>
                            </div>
                            <div class="alert container mb-0 passBookBody">
                                <div class="row mb-2 d-flex">
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Mode</h5>
                                        <h4>UPI</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Pack</h5>
                                        <h4>Popular pack</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Pack price</h5>
                                        <h4>250</h4>
                                    </div>
                                </div>
                                <div class="row d-flex">
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Credits</h5>
                                        <h4>500</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Available credits</h5>
                                        <h4>1000</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5 class="heading-small text-muted">Delivery Partner</h5>
                                        <h4>ABC DEF</h4>
                                    </div>
                                </div>
                                <div class="col-sm d-flex justify-content-end m-0 p-0">
                                    <span class="link collapseSwitch text-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Details <i class="fas fa-angle-down"></i></span>
                                </div>
                            </div>
                        </div>
                        {{-- Collapse --}}
                        <div class="collapse p-3" id="collapseExample">
                            <div class="card mb-0 mt-3 pass-border-dark">{{-- Print --}}
                                <div class="card-header border-0 p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h3 class="mb-0 mx-1">Print</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush text-center">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Paper color</th>
                                                <th>Paper size</th>
                                                <th>Paper quality</th>
                                                <th>Total pages</th>
                                                <th>Page per print</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>White</td>
                                                <td>A4 paper</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>2</td>
                                                <td>100</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card mb-0 mt-3 pass-border-dark">{{-- Recharge --}}
                                <div class="card-header border-0 p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h3 class="mb-0 mx-1">Recharge</h3>
                                        </div>
                                    </div>
                                </div>
                                <!-- Projects table -->
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush text-center">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Packs</th>
                                                <th>No. of pack recharge</th>
                                                <th>Price</th>
                                                <th>Commission earned</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Basic pack</td>
                                                <td>80</td>
                                                <td>50</td>
                                                <td>2</td>
                                                <td>100</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="designation">Area</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                                <option>Bani park</option>
                                <option>Bani park</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-dark">Apply</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="datepicker" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="text" class="form-control" name="daterange" value="01/01/2018 - 01/15/2018" />
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal" id="datepickerCancel">Cancel</button>
                <button type="button" class="btn btn-dark" id="datepickerApply">Apply</button>
            </div>
        </div>
    </div>
</div>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
    $('.collapseSwitch').click(function(event) {
        console.log('clicked')
        switch ($(this).attr('aria-expanded')) {
            case 'false':
                $(this).children('i').addClass('fa-angle-up').removeClass('fa-angle-down'); break;
            case 'true':
                $(this).children('i').addClass('fa-angle-down').removeClass('fa-angle-up'); break;
        }
    });
</script>
@endsection

@endsection