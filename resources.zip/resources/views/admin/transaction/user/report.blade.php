@extends('admin.layouts.app')
@section('title','Reports - User')
@section('content')
<style>.card-header{color:white!important;}</style>
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card-body p-0">
				<form action="{{ route('t.users.store') }}" method="POST"> @csrf @method('POST')
					<div class="card-header mb-3">Range</div>
					<div class="px-3">
						<h6 class="heading-small mb-0">User ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Number of packs</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Transaction ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Date</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">From</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">2020</option>
												<option value="">2021</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">To</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">2020</option>
												<option value="">2020</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Time</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">From</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">To</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Filter</div>
					<div class="px-3">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">City</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Mumbai</option>
										<option>Mumbai</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-last-name">Packs</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Basic pack</option>
										<option>Special pack</option>
										<option>Popular pack</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">Mode</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>UPI</option>
										<option>Cash</option>
										<option>Cheque</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-last-name">Status</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Pending</option>
										<option>Successful</option>
										<option>Failed</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- Data points -->
					<div class="card-header mb-3">Data points</div>
					<div class="px-3">
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">Data points</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Total packs used</option>
										<option>Total credits</option>
										<option>Total price</option>
										<option>Per pack cost</option>
										<option>Per pack credits</option>
										<option>Available credits</option>
										<option>Delivery partner</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="p-3 d-flex justify-content-end">
						<button type="submit" name="exportBtn" value="json" class="btn btn-dark">Export JSON</button>
						<button type="submit" name="exportBtn" value="pdf" class="btn btn-dark">Export PDF</button>
						<button type="submit" name="exportBtn" value="excel" class="btn btn-dark">Export EXCEL</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
	function format(input){
        if (input.value.length > 2) input.value = input.value.slice(0, 2)
        $(input).blur(function() {
           if(input.value.length == 1) input.value=0+input.value;
           if(input.value.length == 0) input.value='01';
        });
    }
</script>
@endsection

@endsection