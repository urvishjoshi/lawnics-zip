@extends('admin.layouts.app')
@section('title','Reports')
@section('content')
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card-body pt-3 pl-3">
				<form>
					<h4 class="heading-small text-muted">Range</h4>
					<div class="pl-lg-4">
						<h6 class="heading-small mb-0">User ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Total order</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Transaction ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="122020">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="262020">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Date</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">From</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">2020</option>
												<option value="">2021</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">To</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">2020</option>
												<option value="">2020</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Time slot</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">From</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">To</label>
									<div class="d-flex">
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">01</option>
											</select>
										</div>
										<div class="col-md-4">
											<select class="custom-select" name="" id="">
												<option value="">AM</option>
												<option value="">PM</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<hr class="mt-0 mb-3" />
					<!-- Professional -->
					<h6 class="heading-small text-muted mb-2">Filter</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">Area</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Mumbai</option>
										<option>Mumbai</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-last-name">Packs</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Basic pack</option>
										<option>Special pack</option>
										<option>Popular pack</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-first-name">Status</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>A4</option>
										<option>A3</option>
										<option>Letter</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<hr class="mt-0 mb-3" />
					<!-- Professional -->
					<h6 class="heading-small text-muted mb-2">Data points</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label class="form-control-label">Data points</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="designation" id="designation">
										<option>Total page</option>
										<option>Payment due</option>
										<option>Page amount</option>
										<option>Earning</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="d-flex justify-content-end">
						<button class="btn btn-success">Export</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection