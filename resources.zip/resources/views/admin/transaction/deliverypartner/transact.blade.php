@extends('admin.layouts.app')
@section('title','Transaction')
@section('content')
<style>h3{color: white;margin:0;}
.bg-black{background-color: black;}
.h3,.h5{color: white!important;} .fa-angle-down{font-size: 12px;}
hr{border: 1px solid lightgrey!important;width: 100%;margin: 2% 0px 2% 0px;}
</style>
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile mb-0 bg-black">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<img src="{{asset('assets/img/theme/team-4.jpg')}}" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				{{-- <div class="card-header text-center border-0 py-4 pb-md-2 mb-5">
				</div> --}}
				<div class="card-body pt-2 pb-1 border-bottom mt-6">
					<div class="text-center">
						<h5 class="h3">
							Jessica Jones
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>Printing partner, Jaipur
						</div>
					</div>
				</div>
			</div>
			<div class="card-header pl-3 ">
				<div class="">
					<div class="row text-white text-center">
						<div class="col-lg">
							<h6 class="heading-small text-muted mb-0">Total earned</h6>
							<h3>15000</h3>
						</div>
						<div class="col-lg">
							<h6 class="heading-small text-muted mb-0">Payment due</h6>
							<h3>500</h3>
						</div>
					</div>
				</div>
				<HR>
				<div class="row align-items-center pl-1">
                    <div class="col">
                      <h6 class="heading-small text-muted mb-0">ID</h6>
						<h3>4534747</h3>
                    </div>
                    <div class="col-6 d-flex justify-content-end align-self-end">
                        <a href="" class="btn btn-sm btn-primary mt-2">Pay / Receive</a>
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="" class="btn btn-block btn-sm btn-primary mt-2">Sort</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                      </div>
                    </div>
                  </div>
				<HR>
                <div class="row px-4">
                	<h3>Print</h3>
                </div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Paper color
		                    <th>Paper size
		                    <th>Paper quality
		                    <th>Total pages
		                    <th>Page per print
                            <th>Amount
	                    </tr>
	                </thead>
	                <tbody>
	                	<tr>
		                    <td>White
		                    <td>A4 paper
		                    <td>80
		                    <td>50
		                    <td>2
                            <td>100
	                    </tr><tr>
                            <td>White
                            <td>A4 paper
                            <td>80
                            <td>50
                            <td>2
                            <td>100
                        </tr><td>White
                            <td>A4 paper
                            <td>80
                            <td>50
                            <td>2
                            <td>100
                        </tr>
	                </tbody>
	            </table>
	            <div class="d-flex justify-content-end p-3">
	            	<button class="btn btn-danger">200</button>
	            </div>
	        </div>
	    </div>
        <div class="card mb-3 mt-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Recharge</h3>
                    </div>
                </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>Packs
                            <th>No. of pack recharge
                            <th>Price
                            <th>Commission earned
                            <th>Amount
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Basic pack
                            <td>80
                            <td>50
                            <td>2
                            <td>100
                        </tr><tr>
                            <td>Special pack
                            <td>80
                            <td>50
                            <td>2
                            <td>100
                        </tr>
                    </tbody>
                </table>
                <div class="d-flex p-3">
                    <div class="col-md-3"></div>
                    <div class="col-md-3"></div>
                    <div class="col-md-2 justify-content-center">
                        <button class="btn border-success">200</button>
                    </div>
                    <div class="col-md-2 justify-content-center">
                        <button class="btn border-danger">200</button>
                    </div>
                    <div class="d-flex justify-content-end col-md-2">
                        <button class="btn btn-success">200</button>
                    </div>
                    
                </div>
            </div>
        </div>
	    <div class="card mb-3 mt-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="mb-0 mx-1">Passbook</h3>
                    </div>
            	</div>
            </div>
            <div class="">
                {{-- Passbook --}}
                <div class="card mb-0 pt-3">
                    <div class="mx-3 pass-border-success mb-3">{{-- single transaction --}}
                        <div class="table-responsive">
                            <div class="alert alert-success d-flex mb-1">
                                <div class="pr-5">
                                    <h5>Transaction ID</h5>
                                    <h4>413654195</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Date</h5>
                                    <h4>24/06/2020</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Time</h5>
                                    <h4>10:00 PM</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Status</h5>
                                    <h4>Pending</h4>
                                </div>
                            </div>
                            <div class="alert container mb-0">
                                <div class="row mb-2 d-flex">
                                    <div class="col-md pr-5">
                                        <h5>Mode</h5>
                                        <h4>UPI</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Items</h5>
                                        <h4>2</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Total page</h5>
                                        <h4>100</h4>
                                    </div>
                                </div>
                                <div class="row d-flex">
                                    <div class="col-md pr-5">
                                        <h5>Amount paid</h5>
                                        <h4>500</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Total balance</h5>
                                        <h4>1000</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                    </div>
                                </div>
                                <div class="col-sm d-flex justify-content-end m-0 p-0">
                                    <a class="link" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Details <i class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                        {{-- Collapse --}}
                        <div class="collapse p-3" id="collapseExample">
                            <div class="card mb-0 mt-3">{{-- Print --}}
                                <div class="card-header border-0 p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h3 class="mb-0 mx-1">Print</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush text-center">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Paper color
                                                <th>Paper size
                                                <th>Paper quality
                                                <th>Total pages
                                                <th>Page per print
                                                <th>Amount
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>White
                                                <td>A4 paper
                                                <td>80
                                                <td>50
                                                <td>2
                                                <td>100
                                            </tr><tr>
                                                <td>White
                                                <td>A4 paper
                                                <td>80
                                                <td>50
                                                <td>2
                                                <td>100
                                            </tr><td>White
                                                <td>A4 paper
                                                <td>80
                                                <td>50
                                                <td>2
                                                <td>100
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card mb-0 mt-3">{{-- Recharge --}}
                                <div class="card-header border-0 p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h3 class="mb-0 mx-1">Recharge</h3>
                                        </div>
                                    </div>
                                </div>
                                <!-- Projects table -->
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush text-center">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Packs
                                                <th>No. of pack recharge
                                                <th>Price
                                                <th>Commission earned
                                                <th>Amount
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Basic pack
                                                <td>80
                                                <td>50
                                                <td>2
                                                <td>100
                                            </tr><tr>
                                                <td>Special pack
                                                <td>80
                                                <td>50
                                                <td>2
                                                <td>100
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="">
                {{-- Passbook --}}
                <div class="card mb-0 pt-0">
                    <div class="mx-3 pass-border-success mb-3">{{-- single transaction --}}
                        <div class="table-responsive">
                            <div class="alert alert-warning d-flex mb-1">
                                <div class="pr-5">
                                    <h5>Transaction ID</h5>
                                    <h4>413654195</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Date</h5>
                                    <h4>24/06/2020</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Time</h5>
                                    <h4>10:00 PM</h4>
                                </div>
                                <div class="pr-5">
                                    <h5>Status</h5>
                                    <h4>Pending</h4>
                                </div>
                            </div>
                            <div class="alert container mb-0">
                                <div class="row mb-2 d-flex">
                                    <div class="col-md pr-5">
                                        <h5>Mode</h5>
                                        <h4>UPI</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Pack</h5>
                                        <h4>Popular pack</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Pack price</h5>
                                        <h4>250</h4>
                                    </div>
                                </div>
                                <div class="row d-flex">
                                    <div class="col-md pr-5">
                                        <h5>Credits</h5>
                                        <h4>500</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                        <h5>Available credits</h5>
                                        <h4>1000</h4>
                                    </div>
                                    <div class="col-md pr-5">
                                    </div>
                                </div>
                                <div class="col-sm d-flex justify-content-end m-0 p-0">
                                    <a class="link" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Details <i class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
	
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-control-label" for="designation">Area</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                        <option>Bani park</option>
                        <option>Bani park</option>
                    </select>
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">Apply</button>
      </div>
    </div>
  </div>
</div>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection