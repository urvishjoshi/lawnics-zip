@extends('admin.layouts.app')
@section('title','Segmentation')
@section('content')
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card card-profile mb-3">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<img src="{{asset('assets/img/theme/team-1.jpg')}}" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				<div class="card-header text-center border-0 py-4 pb-md-2">
					<div class="d-flex justify-content-end">
						{{-- <a href="#" class="btn btn-sm btn-info  mr-4 ">Connect</a> --}}
						{{-- <a href="#" class="btn btn-default float-right"></a> --}}
					</div>
				</div>
				<div class="card-body pt-5 pb-1 border-bottom">
					<div class="text-center">
						<h5 class="h3">
							Jessica Jones<span class="font-weight-light">, 27</span>
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>Bucharest, Romania
						</div>
					</div>
				</div>
			</div>
			<div class="card-body pt-0 pl-3">
				<form>
					<h4 class="heading-small text-muted">Range</h4>
					<h6 class="pl-4 heading-small mb-0">Age</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-username">From</label>
									<input type="text" id="input-username" class="form-control" placeholder="24">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-email">To</label>
									<input type="email" id="input-email" class="form-control" placeholder="52">
								</div>
							</div>
						</div>
					</div>
					<hr class="mt-0 mb-3" />
					<!-- Professional -->
					<h6 class="heading-small text-muted mb-2">Data</h6>
					<div class="pl-lg-4">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="input-address">Gender</label>
									<input type="text" id="input-address" class="form-control" placeholder="Male">
								</div>
							</div>
						</div>
					</div>
					<div class="d-flex justify-content-end">
						<button class="btn btn-dark">Cancel</button>
						<button class="btn btn-dark">Apply</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@endsection