@extends('admin.layouts.app')
@section('title','Segmentation - User')
@section('content')
<section>
	
	<div class="col p-3">
		<div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">{{$nonlawyers['designation']}}</h3>
					</div>
					<div class="col-3 text-right">
						<button class="btn btn-primary mt-2" id="add" data-toggle="modal" data-target="#exampleModal">Add</button>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Icons</th>
		                    <th>Gender</th>
		                    <th>Age</th>
		                    <th>Action</th>
	                    </tr>
	                </thead>
	                <tbody>
	                @if(!isset($nonlawyers['Peoples']))
	                	<tr>
                            <td colspan="7"><h3>No peoples added yet</h3></td>
                        </tr>
	                @else
		                @foreach($nonlawyers['Peoples'] as $key => $value)
		                	<tr>
			                    <th><img src="{{$value['image']}}" width="75" height="75" class="mx-auto rounded-circle"></th>
			                    <td>{{$value['gender']??'N/A'}}</td>
			                    <td>{{$value['fromAge'].' - '.$value['toAge']}}</td>
			                    <td>
				                    <div class="d-flex justify-content-end">
				                    	<button class="btn btn-dark btn-sm" id="edit" value="{{$key}}" image="{{$value['imageName']}}" data-toggle="modal" data-target="#exampleModal">Edit</button>
					                    <form action="{{route('u.segments.destroy',$key)}}" method="POST">
					                        @csrf @method('DELETE')
					                        <input type="hidden" value="NonLawyers" name="category">
					                        <input type="hidden" value="{{$id}}" name="desg">
					                        <button type="button" onclick="deleteForm(this)" value="{{$value['imageName']}}" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
					                    </form>
			                    	</div>
			                    </td>
		                    </tr>
		                @endforeach
		            @endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
	
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="{{ route('u.segments.store') }}" class="modal-content" method="POST" name="submitForm">
            @csrf @method('POST')
            <div class="modal-header py-3">
                <h2 class="title m-0" id="exampleModalLabel">Add/Edit</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body py-0">
            	<div class="p-3 d-flex flex-column">
            		<input type="file" name="image" id="image" class="mx-auto">
            		<input type="hidden" value="" name="imageName" id="imageName"/>
            		<input type="hidden" value="" name="imagePath" id="imagePath"/>
            		<input type="hidden" value="" name="imageToBeDelete" id="imageToBeDelete"/>
            		<input type="hidden" value="nonlawyers" name="category" id="category"/>
            		<input type="hidden" value="{{$id}}" name="desg" id="desg"/>
            		<input type="hidden" value="" name="key" id="key"/>
            		{{-- <span class="mx-auto">Current image:</span>
            		<img src="{{asset('assets/img/theme/team-1.jpg')}}" width="100" class="mx-auto rounded-circle">
            		<a href="#" class="mx-auto">Change</a> --}}
            	</div>
                <h4 class="heading-small text-muted">Range</h4>
                <h6 class="heading-small mb-0">Age</h6>
            	<div class="row">
            		<div class="col-sm-6">
            			<div class="form-group">
            				<label class="form-control-label" for="fromAge">From</label>
            				<input type="number" id="fromAge" name="fromAge" min="1" value="" class="form-control" placeholder="24">
            			</div>
            		</div>
            		<div class="col-sm-6">
            			<div class="form-group">
            				<label class="form-control-label" for="toAge">To</label>
            				<input type="number" id="toAge" name="toAge" min="1" value="" class="form-control" placeholder="52">
            			</div>
            		</div>
            	</div>
                <!-- Professional -->
                <h6 class="heading-small text-muted mb-2">Data</h6>
            	<div class="row">
            		<div class="col-sm-6">
            			<div class="form-group">
            				<label class="form-control-label" for="input-address">Gender</label>
            				<select name="gender" id="gender" class="form-control">
								<option>Male</option>
								<option>Female</option>
								<option>Other</option>
							</select>
            			</div>
            		</div>
            	</div>
            </div>
            <div class="modal-footer py-2">
                <img src="{{asset('icons/load.gif')}}" alt="" width="40" class="mr-2" id="load" style="display: none;">
                <span id="errorSpan" class="text-danger mx-2 my-auto" style="display: none;"></span>
                <button type="button" class="btn btn-dark" onclick="upload()" id="submitBtn">Add</button>
                <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
            </div>
        </form>
    </div>
</div>
@section('jquery')
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-storage.js"></script>
<script src="{{ asset('assets/js/firebaseJs.js') }}"></script>
<script>

    function upload() {
    	document.getElementById("errorSpan").style.display = 'none';
        var image=document.getElementById("image").files[0];
        var deleteImage = document.getElementById("imageToBeDelete").value;

        if(validate()){

	        if (image){

	        	var imgExt = image.name.toLowerCase(),
		            regex = new RegExp("(.*?)\.(jpg|jpeg|png)$");
		        if (!(regex.test(imgExt))) {
		            alert('Please select .jpg/.jpeg or .png file format');
		            return false;
		        }

	          var imageN=image.name;
	          var s = new Date().getTime();
	          var imageName = s+'_'+imageN;
	          var storageRef=firebase.storage().ref('segmentationIcons/'+imageName);

	          document.getElementById("imageName").value = imageName;
	          var uploadTask=storageRef.put(image);

	          uploadTask.on('state_changed',function (snapshot) {
	              document.getElementById("load").style.display = 'block';
	          },function (error) {
	              //handle error here
	              console.log(error.message);
	          },function () {
	              uploadTask.snapshot.ref.getDownloadURL().then(function (downlaodURL) {
	                  document.getElementById("imagePath").value = downlaodURL;

	                  if(deleteImage!="") {
	                    storageRef = firebase.storage().ref('segmentationIcons/');
	                    var desertRef = storageRef.child(deleteImage);
	                    desertRef.delete().then(function() {
	                    }).catch(function(error) {
	                      console.log(error.message);
	                    });
	                  }
	                  $('form').submit();
	                  // document.getElementById('hiddenSubmit').click()
	              });
	          });
	        } else {
	        	if(!image) {
	        	document.getElementById("errorSpan").innerHTML = 'Please upload image';
	        	document.getElementById("errorSpan").style.display = 'block';
		        }
		    }
        }
    }
    function validate() {
    	if (!$('#fromAge').val()){ alert('from age is required'); return false; }
    	if ($('#fromAge').val()<0){ alert('from age value should be greater than 0'); return false; }

    	if (!$('#toAge').val()){ alert('to age is required'); return false; }
    	if ($('#toAge').val()<0){ alert('to age value should be greater than 0'); return false; }

    	return true;
    }
    $('#add').click(function () {
    	document.getElementById("errorSpan").style.display = 'none';
    	document.getElementById("load").style.display = 'none';
        $('#imageToBeDelete').val('');
        $('#key').val('');
        $('#submitBtn').text('Add');
    })
    $('#edit').click(function () {
    	var key = $(this).val();
        $('#submitBtn').text('Update');
        $('#imageToBeDelete').val($(this).attr('image'));
        $('#key').val(key);
        document.getElementById("load").style.display = 'block';
    	$.ajax({
            method:"GET",
            url: '{{ route('u.segments.edit','NonLawyers') }}',
            data: {
                'id':    '{{$id}}',
                'key':    key,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
                $('#fromAge').val(data.fromAge);
                $('#toAge').val(data.toAge);
                $('#gender').val(data.gender);
                document.getElementById("load").style.display = 'none';
            }
        });
    });
    function deleteForm(form) {
    	var deleteImage = $(form).val();
    	storageRef = firebase.storage().ref('segmentationIcons/');
    	var desertRef = storageRef.child(deleteImage);
    	desertRef.delete().then(function() {
    	}).catch(function(error) {
    	  console.log(error.message);
    	});
        $(form).parents('form').submit();
    }
</script>
@endsection
@endsection