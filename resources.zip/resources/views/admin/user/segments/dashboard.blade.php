@extends('admin.layouts.app')
@section('title','Segmentation - Users')
@section('content')
<section>
	
	<div class="m-3">
		<div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Lawyers</h3>
					</div>
					<div class="col text-right">
						<button class="btn btn-primary mt-2" id="addLawyers" data-toggle="modal" data-target="#exampleModal">Add</button>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Icon</th>
		                    <th>Designation</th>
		                    <th>Action</th>
	                    </tr>
	                </thead>
	                <tbody>
                	@if(!isset($segments['Lawyers']))
	                	<tr>
                            <td colspan="7"><h3>No Lawyers created yet</h3></td>
                        </tr>
	                @else
		                @foreach($segments['Lawyers'] as $key => $value)
		                	<tr>
			                    <th><img src="{{$value['image']}}" width="75" height="75" class="mx-auto rounded-circle"></th>
			                    <td><a href="{{ route('u.segments.show','lawyers') }}?id={{$key}}">{{$value['designation']??''}}</a></td>
			                    <td>
			                    	<div class="d-flex justify-content-end">
				                    	<button class="btn btn-sm btn-dark" id="editLawyers" image="{{$value['imageName']}}" value="{{$key}}" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-pen mr-1"></i> Edit</button>
				                    	@if (empty($value['Peoples']))
					                    <form action="{{route('u.segments.destroy',$key)}}" method="POST" id="lawyersDel">
					                        @csrf @method('DELETE')
					                        <input type="hidden" value="Lawyers" name="category">
					                        <button type="button" onclick="deleteForm(this)" value="{{$value['imageName']}}" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
					                    </form>
				                    	@endif
			                    	</div>
			                	</td>
		                    </tr>
		                @endforeach
                	@endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	    <div class="card">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Non-Lawyers</h3>
					</div>
					<div class="col text-right">
						<button class="btn btn-primary mt-2" id="addNonlawyers" data-toggle="modal" data-target="#exampleModal">Add</button>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Icon</th>
		                    <th>Designation</th>
		                    <th>Action</th>
	                    </tr>
	                </thead>
	                <tbody>
	                @if(!isset($segments['NonLawyers']))
	                	<tr>
                            <td colspan="7"><h3>No Non lawyers created yet</h3></td>
                        </tr>
	                @else
		                @foreach($segments['NonLawyers'] as $key => $value)
		                	<tr>
			                    <th><img src="{{$value['image']}}" width="75" height="75" class="mx-auto rounded-circle"></th>
			                    <td><a href="{{ route('u.segments.show','nonlawyers') }}?id={{$key}}">{{$value['designation']??''}}</a></td>
			                    <td>
			                    	<div class="d-flex justify-content-end">
				                    	<button class="btn btn-sm btn-dark" id="editNonlawyers" value="{{$key}}" image="{{$value['imageName']}}" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-pen mr-1"></i> Edit</button>
				                    	@if (empty($value['Peoples']))
					                    <form action="{{route('u.segments.destroy',$key)}}" method="POST" id="nonlawyersDel">
					                        @csrf @method('DELETE')
					                        <input type="hidden" value="NonLawyers" name="category">
					                        <button type="button" onclick="deleteForm(this)" value="{{$value['imageName']}}" class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i> Delete</button>
					                    </form>
				                    	@endif
			                    	</div>
			                	</td>
		                    </tr>
		                @endforeach
	               @endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
	
</section>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="{{ route('u.segments.store') }}" class="modal-content" method="POST" name="submitForm">
            @csrf @method('POST')
            <div class="modal-header py-3">
                <h2 class="title m-0" id="exampleModalLabel">Add/Edit</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body py-0">
            	<div class="p-3 d-flex flex-column">
            		<input type="file" name="image" id="image" class="mx-auto">
            		<input type="hidden" value="" name="imageName" id="imageName"/>
            		<input type="hidden" value="" name="imagePath" id="imagePath"/>
            		<input type="hidden" value="" name="imageToBeDelete" id="imageToBeDelete"/>
            		<input type="hidden" value="" name="category" id="category"/>
            		<input type="hidden" value="" name="key" id="key"/>
            		{{-- <span class="mx-auto">Current image:</span>
            		<img src="{{asset('assets/img/theme/team-1.jpg')}}" width="100" class="mx-auto rounded-circle">
            		<a href="#" class="mx-auto">Change</a> --}}
            	</div>
            	<div class="row">
            		<div class="col-sm">
            			<div class="form-group">
            				<label class="form-control-label" for="designation">Designation</label>
            				<input type="text" id="designation" name="designation" value="" class="form-control" placeholder="designation">
            			</div>
            		</div>
            	</div>
            </div>
            <div class="modal-footer py-2">
                <img src="{{asset('icons/load.gif')}}" alt="" width="40" class="mr-2" id="load" style="display: none;">
                <span id="errorSpan" class="text-danger mx-2 my-auto" style="display: none;"></span>
                <button type="button" class="btn btn-dark" onclick="upload()" id="submitBtn">Add</button>
                <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
            </div>
        </form>
    </div>
</div>

@section('jquery')
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.15.1/firebase-storage.js"></script>
<script src="{{ asset('assets/js/firebaseJs.js') }}"></script>
<script>

  	$('#addLawyers').click(function() {
  		$('#category').val('lawyers');
  		document.getElementById("errorSpan").style.display = 'none';
    	document.getElementById("load").style.display = 'none';
        $('#imageToBeDelete').val('');
        $('#submitBtn').text('Add');
        $('#key').val('');
  	});
  	$('#editLawyers').click(function() {
        document.getElementById("load").style.display = 'block';
  		var id = $(this).val();
  		$('#category').val('lawyers');
        $('#submitBtn').text('Update');
        $('#key').val(id);
        $('#imageToBeDelete').val($(this).attr('image'));
  		$.ajax({
            method:"GET",
            url: '{{ route('u.segments.edit','Lawyers') }}',
            data: {
                'id':    id,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
                $('#designation').val(data.designation);
                document.getElementById("load").style.display = 'none';
            }
        });
  	});

  	$('#addNonlawyers').click(function() {
  		$('#category').val('nonlawyers');
  		document.getElementById("errorSpan").style.display = 'none';
    	document.getElementById("load").style.display = 'none';
        $('#imageToBeDelete').val('');
        $('#submitBtn').text('Add');
        $('#key').val('');
  	});
  	$('#editNonlawyers').click(function() {
        document.getElementById("load").style.display = 'block';
  		var id = $(this).val();
  		$('#category').val('nonlawyers');
        $('#submitBtn').text('Update');
        $('#key').val(id);
        $('#imageToBeDelete').val($(this).attr('image'));
  		$.ajax({
            method:"GET",
            url: '{{ route('u.segments.edit','NonLawyers') }}',
            data: {
                'id':    id,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
                $('#designation').val(data.designation);
                document.getElementById("load").style.display = 'none';
            }
        });
  	});

    function upload() {
    	document.getElementById("errorSpan").style.display = 'none';
        var image=document.getElementById("image").files[0];
        var deleteImage = document.getElementById("imageToBeDelete").value;

        if(validate()){

	        if (image){

	        	var imgExt = image.name.toLowerCase(),
		            regex = new RegExp("(.*?)\.(jpg|jpeg|png)$");
		        if (!(regex.test(imgExt))) {
		            alert('Please select .jpg/.jpeg or .png file format');
		            return false;
		        }

	          var imageN=image.name;
	          var s = new Date().getTime();
	          var imageName = s+'_'+imageN;
	          var storageRef=firebase.storage().ref('segmentationIcons/'+imageName);

	          document.getElementById("imageName").value = imageName;
	          var uploadTask=storageRef.put(image);

	          uploadTask.on('state_changed',function (snapshot) {
	              document.getElementById("load").style.display = 'block';
	          },function (error) {
	              //handle error here
	              console.log(error.message);
	          },function () {
	              uploadTask.snapshot.ref.getDownloadURL().then(function (downlaodURL) {
	                  document.getElementById("imagePath").value = downlaodURL;

	                  if(deleteImage!="") {
	                    storageRef = firebase.storage().ref('segmentationIcons/');
	                    var desertRef = storageRef.child(deleteImage);
	                    desertRef.delete().then(function() {
	                    }).catch(function(error) {
	                      console.log(error.message);
	                    });
	                  }
	                  $('form').submit();
	                  // document.getElementById('hiddenSubmit').click()
	              });
	          });
	        } else {
	        	if(!image) {
	        	document.getElementById("errorSpan").innerHTML = 'Please upload image';
	        	document.getElementById("errorSpan").style.display = 'block';
		        }
		    }
        }
    }
    function deleteForm(form) {
    	var deleteImage = $(form).val();
    	storageRef = firebase.storage().ref('segmentationIcons/');
    	var desertRef = storageRef.child(deleteImage);
    	desertRef.delete().then(function() {
    	}).catch(function(error) {
    	  console.log(error.message);
    	});
        $(form).parents('form').submit();
    }
    function validate() {
    	if (!$('#designation').val()){ alert('designation is required'); return false; }

    	return true;
    }
</script>
@endsection
@endsection