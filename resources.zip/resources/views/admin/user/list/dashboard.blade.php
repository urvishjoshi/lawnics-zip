@extends('admin.layouts.app')
@section('link')
<style>
    .card .table th,td {
        padding-right: 0px!important; 
        padding-left: 0px!important; 
    }
</style>
@endsection
@section('title','Users List')
@section('content')
@php use \App\Http\Controllers\Admin\LocationPermiController as LPClas; $data = LPClas::data(); @endphp
<section>
    <!-- Reports Header -->
    <div class="m-3">
        <!-- Page content -->
        <div class="">
          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-header border-0 p-3">
                  <div class="row align-items-center">
                    <div class="col">
                      <h3 class="mb-0 mx-1">Users list</h3>
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('u.list.show','reports') }}" class="btn btn-block btn-sm btn-primary mt-2">Reports</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Projects table -->
                <div class="table-responsive">
                  <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Designation</th>
                        <th>Mobile No.</th>
                        <th>State</th>
                        <th>City</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @if($users<1)
                        <tr>
                            <td colspan="8"><h3>No Users registered yet</h3></td>
                        </tr>
                    @else  @php $flag=true; @endphp
                        @foreach($users as $key => $user)
                            @if(LPClas::userStatePermi($user['state'] ?? 'N/A', $data) || LPClas::userCityPermi($user['city'] ?? 'N/A', $data)) @php $flag=false; @endphp
                            <tr>
                                <th>{{ $user['Enrollment_Number'] ?? 'N/A' }}</th>
                                <th>
                                    <a href="{{ route('u.list.show','profile?id='.$key) }}" class="d-flex">
                                        <div class="overlay">
                                            <img src="{{asset('icons/0.png')}}" class="overicon" alt="badge"> 
                                        </div>
                                        <img src="@if(isset($user['profile'])) {{$user['profile']}} @else {{asset('icons/'.ucfirst($user['gender'] ?? 'N/A').'.png')}} @endif" height="32" width="32" alt="user_icon" class="mr-1 rounded-circle">
                                        <span class="my-auto mx-auto">{{ ($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A')  }}
                                        </span>
                                    </a>
                                </th>
                                <td>{{ $user['category'] ?? 'N/A' }}</td>
                                <td>{{ $user['designation'] ?? 'N/A' }}</td>
                                <td>{{ $phone[$key] ?? 'N/A'}}</td>
                                <td>{{ $user['state'] ?? 'N/A' }}</td>
                                <td>{{ ucfirst($user['city'] ?? 'N/A') }}</td>
                                <td><button data-toggle="button" aria-pressed="true" class="btn btn-sm btn-success"><i class="fas fa-ban"></i> Block</button></td>
                            </tr>
                            @endif
                        @endforeach
                        @if ($flag)
                            <tr>
                                <td colspan="8"><h3>No Users registered yet or You have don't have any preveliege</h3></td>
                            </tr>
                        @endif
                    @endif
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
        </div>
    </div>
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('button[data-toggle="button"]').click(function(e) {
            if(this.getAttribute('aria-pressed')=='true')
                $(this).html('<i class="far fa-check-circle"></i> Unblock');
            else
                $(this).html('<i class="fas fa-ban"></i> Block');
        });

        $('#cancel').click(function (event) {
            $('tbody tr*').show();
        });
        $('#apply').click(function (event) {
            $('tbody tr').each(function() {
                if ( desFilter($(this)) &&  catFilter($(this)) && stateFilter($(this)) && cityFilter($(this))) 
                    $(this).show();
                else $(this).hide();
            });
        });

        function catFilter(tr) {
            var category = $('#category').val(), flag=false; if (category=='') return true;
            for (var i = 0; i < category.length; i++) {
                switch (category[i]) {
                    case 'Lawyer':
                        if ( strcmp( tr.find("td").eq(0).text(), category[i] ) ) flag = true; break;
                    case 'Non Lawyer':
                        if ( !strcmp( tr.find("td").eq(0).text(), 'Lawyer' ) ) flag = true; break;
                }
            } return flag;
        }
        function desFilter(tr) {
            var designation = $('#designation').val(), flag=false; if (designation=='') return true;
            for (var i = 0; i < designation.length; i++) {
                if ( strcmp( tr.find("td").eq(1).text(), designation[i] ) ) flag = true;
            } return flag;
        }
        function stateFilter(tr) {
            var state = $('#state').val(), flag=false; if (state=='') return true;
            for (var i = 0; i < state.length; i++) {
                if ( strcmp( tr.find("td").eq(3).text(), state[i] ) ) flag = true;
            } return flag;
        }
        function cityFilter(tr) {
            var city = $('#city').val(), flag=false; if (city=='') return true;
            for (var i = 0; i < city.length; i++) {
                if ( strcmp( tr.find("td").eq(4).text(), city[i] ) ) flag = true;
            } return flag;
        }
        //__str compare__
        function strcmp(str1='', str2='') {
            if ( str1.toUpperCase() == str2.toUpperCase() ) return true;
            return false;
        }
    });
</script>
@endsection

@endsection