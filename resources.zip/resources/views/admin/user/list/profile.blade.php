@extends('admin.layouts.app')
@section('title','Profile - User')
@section('content')
<style>
.bg-black{background-color: black;}
#baner-name > *{color: white!important;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
</style>
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile border-bottom bg-black mb-0 pb-3">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<div class="overlay">
									<img src="{{asset('icons/0.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:{{isset($user['profile'])?40:20}}px;margin-left: {{isset($user['profile'])?40:20}}px;"> 
								</div>
								<img src="@if(isset($user['profile'])) {{$user['profile']}} @else {{asset('icons/'.ucfirst($user['gender'] ?? 'N/A').'.png')}} @endif" alt="user_icon" width="{{isset($user['profile'])?105:55}}" height="{{isset($user['profile'])?105:55}}" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				<div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
					<div class="d-flex justify-content-end">
						{{-- <a href="#" class="btn btn-sm btn-info  mr-4 ">Connect</a> --}}
						<button id="edit" class="btn btn-white float-right" data-toggle="button" aria-pressed="false">Edit</button>
					</div>
				</div>
				<div class="card-body pt-0 pb-1">
					<div class="text-center" id="baner-name">
						<h5 class="h3">
							{{($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A')}}
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>{{($user['city'] ?? 'N/A').', '.($user['state'] ?? 'N/A')}}
						</div>
					</div>
				</div>
			</div>
			<div class="card-body p-0">
				<form action="{{ route('u.list.update',$key) }}" method="POST"> @csrf @method('PUT')
					<div class="card-header mb-3">Personal Information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="name">Name</label>
									<input type="text" id="name" name="name" class="form-control" placeholder="Name" value="{{$user['first_name'] ?? 'N/A'}}" required>
								</div>
							</div>
							<div class="col-lg-3">
								<div class="form-group">
									<label class="form-control-label" for="userid">User ID</label>
									<input type="text" id="userid"  name="userid" class="form-control" placeholder="User ID" value="" required>
								</div>
							</div>
							<div class="col-lg-3">
								<div class="form-group">
									<label class="form-control-label" for="gender">Gender</label>
									<select name="gender" id="gender" class="form-control">
										<option {{ucfirst($user['gender'])=='Male'?'selected':''}}>Male</option>
										<option {{ucfirst($user['gender'])=='Female'?'selected':''}}>Female</option>
										<option {{ucfirst($user['gender'])=='Other'?'selected':''}}>Other</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="dob">Date of birth</label>
									<input type="date" id="dob" name="dob" class="form-control" placeholder="dd-mm-yyyy" required>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="city">City</label>
									<input type="text" id="city" name="city" class="form-control" placeholder="City" value="{{$user['city'] ?? 'N/A'}}" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="area">Area</label>
									<input type="text" id="area" name="area" class="form-control" placeholder="Area" value="{{$user['address'] ?? 'N/A'}}" required>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="email">Email</label>
									<input type="email" id="email" name="email" class="form-control" placeholder="a@b.com" value="{{$user['email'] ?? 'N/A'}}" required>
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Professional Information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="enrollno">Enrollment No.</label>
									<input type="text" id="enrollno" name="enrollno" class="form-control" placeholder="Enrollment number" value="{{$user['Enrollment_Number'] ?? 'N/A'}}" required>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="experience">Experience</label>
									<input type="number" id="experience" name="experience" class="form-control" placeholder="8" min="0" max="100" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-country">Identity Card</label>
									<div class="col-sm border p-0">
										<img src="{{ isset($user['id0'])?$user['id0']:'' }}" alt="No image uploaded" width="100%">
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="designation">Designation</label>
									<select name="designation" class="form-control" id="designation" required>
		                                <option {{strtolower($user['designation']??'N/A')=='senior advocate'?'selected':''}}>Senior Advocate</option>
		                                <option {{strtolower($user['designation']??'N/A')=='junior advocate'?'selected':''}}>Junior Advocate</option>
		                            </select>
								</div>
							</div>
						</div>
					</div>
					<div class="d-flex justify-content-end">
						<button type="submit" name="btn" value="1" class="btn btn-success m-3">Verify</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>
@section('jquery')
<script>
	$('form *').attr('disabled','disabled');
	$('#edit').click(function(argument) {
		switch ($(this).attr("aria-pressed")) {
			case 'false':
				$('form *').removeAttr('disabled');
				break;
			case 'true':
				$('form *').attr('disabled','disabled');
				break;
		}
	});
</script>
@endsection
@endsection