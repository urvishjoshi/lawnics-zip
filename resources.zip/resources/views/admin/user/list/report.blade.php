@extends('admin.layouts.app')
@section('title','Reports - User')
@section('content')
<style>.card-header{color:white!important;}</style>
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card-body p-0">
				<form action="{{ route('u.list.store') }}" method="POST"> @csrf @method('POST')
					<div class="card-header mb-3">Range</div>
					<div class="px-3">
						<h6 class="heading-small mb-0">User ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromUserId">From</label>
									<input type="text" id="fromUserId" name="fromUserId" class="form-control" placeholder="123456">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toUserId">To</label>
									<input type="text" id="toUserId" name="toUserId" class="form-control" placeholder="123456">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Date of birth</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromDob">From</label>
									<input type="date" id="fromDob" name="fromDob" class="form-control" placeholder="dd/mm/yyyy">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toDob">To</label>
									<input type="date" id="toDob" name="toDob" class="form-control" placeholder="dd/mm/yyyy">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Exerience</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromExp">From</label>
									<input type="text" id="fromExp" name="fromExp" class="form-control" placeholder="2">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toExp">To</label>
									<input type="text" id="toExp" name="toExp" class="form-control" placeholder="12">
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Filter</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="input-address">Caterogy</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="category[]" placeholder="City">
										<option>Lawyer</option>
										<option>Non lawyer</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-country">Designation</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="designation[]" placeholder="City">
										<option value="junior advocate">Junior Advocate</option>
										<option value="senior advocate">Senior Advocate</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-country">Area</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="area[]" placeholder="City">
										<option>Bani Park</option>
										<option>Vidhyanagar</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-city">Gender</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="gender[]" placeholder="City">
										<option>Male</option>
										<option>Female</option>
										<option>Others</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="input-city">City</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="city[]" placeholder="City">
										<option>Mumbai</option>
										<option>Pune</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- Data points -->
					<div class="card-header mb-3">Data points</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="input-address">Order</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="61" tabindex="-1" aria-hidden="true" name="order[]" placeholder="City">
										<option>User name</option>
										<option>Email ID</option>
										<option>Enrollment No.</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="p-3 d-flex justify-content-end">
						<button type="submit" name="exportBtn" value="json" class="btn btn-dark">Export JSON</button>
						<button type="submit" name="exportBtn" value="pdf" class="btn btn-dark">Export PDF</button>
						<button type="submit" name="exportBtn" value="excel" class="btn btn-dark">Export EXCEL</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
@endsection

@endsection