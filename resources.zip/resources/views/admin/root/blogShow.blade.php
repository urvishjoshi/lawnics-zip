<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Lawnics lawyers.">
	<meta name="author" content="Urvish Joshi">
	<title>Lawnics</title>
	<!-- Favicon -->
	<link rel="icon" href="{{ asset('Lawnics.png') }}" type="image/png">
	<!-- Fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
	<!-- Icons -->
	<link rel="stylesheet" href="{{ asset('/assets/vendor/nucleo/css/nucleo.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

	<link rel="stylesheet" href="{{ asset('/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
	<!-- Argon CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/argon.css') }}" type="text/css">
	<!-- Select tag CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/select2.min.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('/assets/css/swiper.min.css') }}" type="text/css">
	<style>
		/*@import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');*/
		body{
			font-family: 'Poppins', sans-serif;
			background-color: white!important;
			font-weight: bold
		}
		h1,h4,p{color: black}
		h12{
			font-size: 48px; color: black;
		}
		redtext{color: red}
		.redtext.active{color: red!important;border-bottom: 3px solid red;}
		.my-8{ margin-top: 8rem !important;}
		.py-8{ padding-top: 8rem !important;}
		.border-w-3{border-left: 3px solid red}
		.bg-black{background-color: black;}
		.newsletter-input{border-top-left-radius: .25rem;border-bottom-left-radius: .25rem; border: 0px;padding: 0.8rem 0.8rem;}
		.newsletter-shadow{box-shadow: 0 0px 20px 1px rgb(50 50 93 / 11%), 0 1px 3px rgb(0 0 0 / 8%);}
		footer{
			background-color: black!important;
			color: white;
		}
		footer > div  > div  > div > h6,#ligherFont {color: darkgrey!important;font-weight: lighter!important;}
		footer > div  > div  > div > div > h6 {color: darkgrey!important;font-weight: lighter!important;}
		.badge-danger{background-color: #f80031;color: #fdd1da;}
		.accordText {color: darkgrey!important;font-weight: lighter!important;}
		.tab-pane > div { 
			background-image: url('{{ asset('icons/svg/background_logo.svg') }}'); 
			background-repeat: no-repeat;
			background-position: 100%;
			background-size: 45%;
			padding-top: 5%
		}
		.w-400 { width: 400px; }
		.font-20-div > *{font-size: 30px; color: black;}

		@media (max-device-width:768px) {
			.mobile-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-position: 100% 0%;
				background-size: 350%!important;
			}
			.text-sm-center{text-align: center !important;}
			.my-sm-8{ margin-top: 8rem !important;}
			.navbar-nav{flex-direction: inherit!important;}
			.justify-content-sm-around{    justify-content: space-around !important;}
		}
		@media (min-device-width:768px) {
			.web-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-size: 100%!important;
			}
			.border-web-3{border-left: 3px solid red}
			.my-web-8{ margin-top: 8rem !important;}
		}
	</style>

</head>
<body>

	<nav class="navbar navbar-expand-lg navbar-light bg-black">
		<div class="container">
			<a class="navbar-brand" href="#"><img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""></a>
			{{-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button> --}}

			<div class="navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto justify-content-sm-around">
					<li class="nav-item active">
						<a class="nav-link text-light" href="#">Discover</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Vision</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="{{url('blog')}}">Blog</a>
					</li>
					<li class="nav-item d-none d-lg-block">
						<button type="button" class="mx-3 btn btn-sm btn-outline-light">Download</button>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	<section class="container">
		
		<div class="d-flex my-5">
			<img src="{{ asset('images/sunset.jpg') }}" alt="" width="100%">
		</div>
		<div class="d-flex">
			<div class="pl-0 col-2 d-flex">
				<div class="pl-0 col-5">
					<img src="{{ asset('images/1.jpg') }}" class="rounded-circle" alt="" width="100%">
				</div>
				<div class="col-auto">
					<h4 >March 15, 2021</h4>
					<h4 class="text-muted">March 15, 2021</h4>
				</div>
			</div>
			<div class="col-10 d-flex justify-content-end font-20-div">
				<i class="fab fa-whatsapp"></i><i class="fab fa-facebook-f mx-3"></i></i><i class="fab fa-twitter"></i><i class="fab fa-linkedin-in mx-3"></i>
			</div>
		</div>

		<div>
			<h12>
				Image processing algorithm allows indoor drones to fly autonomously
			</h12>
			<p class="text-muted">
				The team behind the project, led by Chinthaka Premachandra, an associate professor in the Department of Electronic Engineering at 

			Shibaura Institute of Technology in Tokyo, said the technology “opens the door to a new breed of functional, low-cost drones with

			potentially wide-ranging uses”. As GPS signals are too weak to penetrate most structures, indoor drones must rely on environmental 

			cues which are typically visual, Premachandra said. Also, a drone designed for indoor use is likely to be smaller and lighter than an 

			outdoor drone. “We considered different hardware options, including laser rangefinders,” he said, “but rangefinders are too heavy and 

			infrared and ultrasonic sensors suffer from low precision. That led us to use a camera as the robot’s visualsensor. If you think of the 

			camera in your cell phone, that gives you an idea of just how small and light they can be.”The research team designed the guidance 

			algorithm to be as simple as possible, allowing the use of a small and inexpensive microprocessor. The team chose the Raspberry Pi

			3, an open-source computing platform that weighs approximately 45g. The prototype the team developed had a single downward-facing

			camera with intentionally low resolution– only 80 by 80 pixels. “Our robot only needed to distinguish its direction of motion and identify

			corners. From there, our algorithm allows it to extrapolate its position in the room, helping it avoid contacting the walls,” Premachandra

			said.According to the team, the program worked by taking each 80 x 80 image through a series of simple processing steps which resulted

			 in a black and white grid. This made it easier to quickly identify motion along the X and Y planes.Premachandra stressed, however, that 

			this guidance method is limited because it relies on a room with a tile floor and predictable patterns. He added the next steps in research 

			into lightweight, autonomous-hovering indoor robots might include adapting the technology for infrared cameras so they could function in 

			the dark, as well as adding a second camera so the robot could visually determine both its X, Y position and its altitude in the room.“There

			are many potential applications,” Premachandra said. “Hovering indoor robots may be useful in warehouses, distribution centres and industrial 

			applications to remotely monitor safety.”

			</p>
		</div>

	</section>

	<section class="container mt-5">
		<h12>More from Lawnics</h12>
		<div class="d-none d-sm-none d-lg-block my-3">
			<div class="row d-flex justify-content-between px-3">
				<div class="col-lg-3 px-0 mx-1">
					<div class="d-flex justify-content-between flex-column">
						<img src="{{ asset('images/1.jpg') }}" alt="" width="100%">
						<div class="pt-2 d-flex justify-content-between">
							<small>Employment</small>
							<small>1hr ago</small>
						</div>
					</div>
					<h4 class="my-3">Work from Home Jobs that Pay Weekly</h4>
					<h5><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
				</div>
				<div class="col-lg-3 px-0 mx-1">
					<div class="d-flex justify-content-between flex-column">
						<img src="{{ asset('images/2.jpg') }}" alt="" width="100%">
						<div class="pt-2 d-flex justify-content-between">
							<small>Technology</small>
							<small>1hr ago</small>
						</div>
					</div>
					<h4 class="my-3">AI Being Applied to Improve Health,
						Better Predict Life of Batteries
					</h4>
					<h5><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
				</div>
				<div class="col-lg-3 px-0 mx-1">
					<div class="d-flex justify-content-between flex-column">
						<img src="{{ asset('images/3.jpg') }}" alt="" width="100%">
						<div class="pt-2 d-flex justify-content-between">
							<small>Technology</small>
							<small>1hr ago</small>
						</div>
					</div>
					<h4 class="my-3">Cool Little CSS Grid Tricks
						for Your Blog
					</h4>
					<h5><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
				</div>
			</div>

			<div class="text-center text-secondary my-5">
				<a href="#" class="mx-3 btn btn-sm btn-outline-danger">View all</a>
			</div>
		</div>
	</section>

	<footer>
		<div class="container px-0">
			<div class="row py-5 mx-0">
				<div class="col-lg-3">
					<img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""><br>
					<small class="d-flex my-5" style="color: #a9a9a9">Lawnics Technologies Private Limited</small>
				</div>

				<div class="accordion container-fluid d-lg-none d-sm-block" id="accordionExample">
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingTwo">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								Our Vision
							</h2>
						</div>
						<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Our Company</a><br></h4>
								<h4><a class="accordText" href="#">Privacy Policies</a><br></h4>
								<h4><a class="accordText" href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingThree">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Services
							</h2>
						</div>
						<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Print</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFour">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
								Customer support
							</h2>
						</div>
						<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">FAQ's</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFive">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								Resources
							</h2>
						</div>
						<div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Contact Us</a><br></h4>
								<h4><a class="accordText" href="#">Email Sign-Up</a><br></h4>
								<h4><a class="accordText" href="#">Support</a></h4>
								<h4><a class="accordText" href="#">Blog</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingSix">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
								Follow Us
							</h2>
						</div>
						<div id="collapseSix" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Instagram</a><br></h4>
								<h4><a class="accordText" href="#">Facebook</a><br></h4>
								<h4><a class="accordText" href="#">Twitter</a></h4>
							</div>
						</div>
					</div>
				</div>


				<div class="col d-lg-flex d-none  justify-content-between">
					
					<div class="col-lg-2 w-75  px-0 flex-column">
						<h6 class="font-weight-bold" style="color: white!important">Our Vision</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Our Company</a><br></h6>
						<h6><a href="#">Privacy Policies</a><br></h6>
						<h6><a href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Services</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Print</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Customer support</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">FAQ's</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Resources</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Contact Us</a><br></h6>
						<h6><a href="#">Email Sign-Up</a><br></h6>
						<h6><a href="#">Support</a><br></h6>
						<h6><a href="#">Blog</a><br></h6>
					</div>
					<div class="col-lg-2 w-75 px-0">
						<h6 class="font-weight-bold" style="color: white!important">Follow Us</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Instagram</a><br></h6>
						<h6><a href="#">Facebook</a><br></h6>
						<h6><a href="#">Twitter</a><br></h6>
					</div>
				</div>
			</div>

			<HR class="m-0 my-3" style="border: 1px solid grey;"></HR>

			<div class="col d-lg-flex flex-lg-row flex-sm-column justify-content-between py-3">
				<div>
					<h6>© Copyright Lawnics technologies Private Limited 2018-2020.</h6>
				</div>
				<div class="d-flex justify-content-around" id="ligherFont">
					<div class="mx-2"><h6><a href="#">Terms</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Privacy</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Contacts</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Location</a></h6></div>
				</div>
			</div>
		</div>
	</footer>

	<script src="{{ asset('/assets/vendor/jquery/dist/jquery.min.js') }}"></script>
	<script src="{{ asset('/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
	<script src="{{ asset('assets/js/swiper.min.js') }}"></script>
	<script src="{{ asset('assets/js/bodymovin_js.js') }}"></script>
	<script src="{{ asset('assets/js/lottie_js.js') }}"></script>

	<script>
		var swiper = new Swiper('.swiper-container', {
			pagination: {
				el: '.swiper-pagination',
				dynamicBullets: true,
			},
		});
	</script>
</body>
</html>
