<div class="d-md-none d-lg-none d-sm-block">
	<div class="swiper-container">
		<div class="swiper-wrapper">
			<div class="swiper-slide px-3">
				<div class="col mx-auto">
					<lottie-player src="{{ asset('lottie_files/document_scanner.json') }}" class="col-8 mx-auto" autoplay loop ></lottie-player>
					<center class="mt-3">
						<h2>Document Scanner</h2>
						<small>Lawnics intelligently measure, monitor, manage important legal information and allow users to</small>
						<br>
						<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
					</center>
				</div>
			</div>
			<div class="swiper-slide px-3">
				<div class="col mx-auto">
					<lottie-player src="{{ asset('lottie_files/document_manager.json') }}" class="col-8 mx-auto" autoplay loop ></lottie-player>
					<center class="mt-3">
						<h2>Document Scanner</h2>
						<small>Lawnics intelligently measure, monitor, manage important legal information and allow users to</small>
						<br>
						<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
					</center>
				</div>
			</div>
			<div class="swiper-slide px-3">
				<div class="col mx-auto">
					<lottie-player src="{{ asset('lottie_files/order_print_screen.json') }}" class="col-8 mx-auto" autoplay loop ></lottie-player>
					<center class="mt-3">
						<h2>Document Scanner</h2>
						<small>Lawnics intelligently measure, monitor, manage important legal information and allow users to</small>
						<br>
						<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
					</center>
				</div>
			</div>
			<div class="swiper-slide px-3">
				<div class="col mx-auto">
					<lottie-player src="{{ asset('lottie_files/share_export.json') }}" class="col-8 mx-auto" autoplay loop ></lottie-player>
					<center class="mt-3">
						<h2>Document Scanner</h2>
						<small>Lawnics intelligently measure, monitor, manage important legal information and allow users to</small>
						<br>
						<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
					</center>
				</div>
			</div>
			<div class="swiper-slide px-3">
				<div class="col mx-auto">
					<lottie-player src="{{ asset('lottie_files/wallet_screen.json') }}" class="col-8 mx-auto" autoplay loop ></lottie-player>
					<center class="mt-3">
						<h2>Document Scanner</h2>
						<small>Lawnics intelligently measure, monitor, manage important legal information and allow users to</small>
						<br>
						<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
					</center>
				</div>
			</div>
		</div>
		<!-- Add Pagination -->
		<div class="swiper-pagination pt-5"></div>
	</div>
</div>