<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Lawnics lawyers.">
	<meta name="author" content="Urvish Joshi">
	<title>Lawnics</title>
	<!-- Favicon -->
	<link rel="icon" href="{{ asset('Lawnics.png') }}" type="image/png">
	<!-- Fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
	<!-- Icons -->
	<link rel="stylesheet" href="{{ asset('/assets/vendor/nucleo/css/nucleo.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

	<link rel="stylesheet" href="{{ asset('/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
	<!-- Argon CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/argon.css') }}" type="text/css">
	<!-- Select tag CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/select2.min.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('/assets/css/swiper.min.css') }}" type="text/css">
	<style>
		/*@import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');*/
		body{
			font-family: 'Poppins', sans-serif;
			background-color: white!important;
			font-weight: bold
		}
		h1,h4,p{color: black}
		h12{
			font-size: 48px; color: black;
		}
		redtext{color: red}
		.redtext.active{color: red!important;border-bottom: 3px solid red;}
		.my-8{ margin-top: 8rem !important;}
		.py-8{ padding-top: 8rem !important;}
		.border-w-3{border-left: 3px solid red}
		.bg-black{background-color: black;}
		.newsletter-input{border-top-left-radius: .25rem;border-bottom-left-radius: .25rem; border: 0px;padding: 0.8rem 0.8rem;}
		.newsletter-shadow{box-shadow: 0 0px 20px 1px rgb(50 50 93 / 11%), 0 1px 3px rgb(0 0 0 / 8%);}
		footer{
			background-color: black!important;
			color: white;
		}
		footer > div  > div  > div > h6,#ligherFont {color: darkgrey!important;font-weight: lighter!important;}
		footer > div  > div  > div > div > h6 {color: darkgrey!important;font-weight: lighter!important;}
		.badge-danger{background-color: #f80031;color: #fdd1da;}
		.accordText {color: darkgrey!important;font-weight: lighter!important;}
		.tab-pane > div { 
			background-image: url('{{ asset('icons/svg/background_logo.svg') }}'); 
			background-repeat: no-repeat;
			background-position: 100%;
			background-size: 45%;
			padding-top: 5%
		}
		#email-subscribe { 
			background-image: url('{{ asset('icons/svg/background_logo.svg') }}'); 
			background-repeat: no-repeat;
			background-position: 50%;
			background-size: 40%;
		}
		.w-400 { width: 400px; }
		.nav-link{
			color: rgba(255, 255, 255, 0.514)!important;
		}
		.nav-link:hover{
			color: white!important;
		}

		@media (max-device-width:768px) {
			.mobile-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-position: 100% 0%;
				background-size: 350%!important;
			}
			.text-sm-center{text-align: center !important;}
			.my-sm-8{ margin-top: 8rem !important;}
			.navbar-nav{flex-direction: inherit!important;}
			.justify-content-sm-around{    justify-content: space-around !important;}
		}
		@media (min-device-width:768px) {
			.web-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-size: 100%!important;
			}
			.border-web-3{border-left: 3px solid red}
			.my-web-8{ margin-top: 8rem !important;}
		}
	</style>

</head>
<body class="_bg web-bg mobile-bg">

	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
			<a class="navbar-brand" href="{{url('/')}}"><img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""></a>

			<div class="navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto justify-content-sm-around">
					<li class="nav-item">
						<a class="nav-link" href="#">Discover</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Vision</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="{{url('blog')}}">Blog</a>
					</li>
					<li class="nav-item d-none d-lg-block">
						<button type="button" class="mx-3 btn btn-sm btn-outline-light">Download</button>
					</li>
				</ul>
			</div>
		</nav>
		<div class="row my-8 d-flex justify-content-center">
			<div class="col-lg-9">
				{{-- Web --}}
				<div class="col mx-0 px-0 d-none d-sm-none d-lg-block">
					<h12 class=" text-light">Easiest way to manage<br>and provide Legal<br>Services</h12>
				</div>
				{{-- Mobile --}}
				<div class="col mx-0 px-5 d-md-none d-lg-none d-sm-block">
					<h1 class="text-center text-light">Easiest way to manage and provide Legal Services</h1>
					<hr width="75" class="m-0 border-danger mt-3 text-danger mx-auto">
				</div>
				<div class="col-lg-7 pl-0">
					<p class="my-4 px-4 border-web-3 text-light text-sm-center">Lawnics helps you transform legal practices digitally, through modern-day tools and services that are easy to use and affordable.
					</p>
				</div>
				<div class="col d-lg-block d-flex justify-content-start justify-content-sm-center">
					<img class="p-4 mx-auto" src="{{ asset('icons/svg/gplay1.svg')}}" alt="">
				</div>
			</div>
			<div class="col-lg-3 mt-lg-0 mt-3 d-flex justify-content-center">
				{{-- <img src="{{ asset('icons/svg/demo.svg')}}" alt="" width="85%"> --}}
			</div>
		</div>
		{{-- Web --}}
		<div class="d-none d-sm-none d-lg-block">
			<div class="  row d-flex justify-content-center">
				<img src="{{ asset('icons/svg/discover.svg')}}" alt=""><br>
			</div>
			<div class="text-center">Discover</div>			
		</div>

		<div class="row my-lg-0 my-sm-8 d-flex justify-content-start mx-5">
			<div class="col-lg-8 my-sm-8 mb-0">
				<h1 class="text-left py-3">Modern tools for modern lawyers</h1>
				<p class="text-left">A value proposition is a statement that answers the ‘why’ someone should do business with you.
					It should convince a potential customer why your service or product will be of more value to them
					than similar offerings from your competition.
				</p>
			</div>
		</div>
		<div class="row d-flex justify-content-around mx-3">
			<div class="col-lg-3 p-3 mx-3 py-4 border rounded">
				<div class="d-flex justify-content-center mb-4 mt-3">
					<img src="{{ asset('icons/svg/user_centric.svg')}}" alt="" class="">
				</div>
				<h4 class="text-center">Easy to use</h4>
				<hr width="30" class="m-0 border-danger mb-1 text-danger mx-auto">
				<p class="text-center text-muted pt-2">Lawyer friendly designs to<br>help you get work done<br>3x faster.</p>
			</div>
			<div class="col-lg-3 p-3 mx-3 py-4 my-3 my-lg-0 border rounded">
				<div class="d-flex justify-content-center mb-4 mt-3">
					<img src="{{ asset('icons/svg/technology_driven.svg')}}" alt="">
				</div>
				<h4 class="text-center">Smart Tech</h4>
				<hr width="30" class="m-0 border-danger mb-1 text-danger mx-auto">
				<p class="text-center text-muted pt-2">Advance AI technology &<br>automation tools to<br>reduce legal work<br>by 60 percent</p>
			</div>
			<div class="col-lg-3 p-3 mx-3 py-4 border rounded">
				<div class="d-flex justify-content-center mb-4 mt-3">
					<img src="{{ asset('icons/svg/community.svg')}}" alt="">
				</div>
				<h4 class="text-center">Accessible</h4>
				<hr width="30" class="m-0 border-danger mb-1 text-danger mx-auto">
				<p class="text-center text-muted pt-2">Access your work from<br>anytime from<br>anywhere</p>
			</div>
		</div>
		<div class="row my-8 d-flex justify-content-start mx-5">
			<div class="col-8">
				<h1 class="text-left py-3">Remarkable and <br>effective features</h1>
				<p class="text-left">Streamline and automate day to day processes with our<br>remarkable and effective features</p>
			</div>
		</div>
	</div>

	<section class="container w-lg-75 p-0 px-lg-3">
		
		@include('admin.root.webComponent')

		@include('admin.root.mobileComponent')
		
	</section>

	

	<div class="bg-black">
		<div class="my-8 py-5 d-flex justify-content-center">
			<div class="col-lg-8 col-sm-auto">
				<h1 class="text-center text-white py-3">Try Lawnics App Today!</h1>
				<p class="text-center text-danger">Made Simple. Just for you</p>

				<div class="col-8 mx-auto">
					<div class="d-flex justify-content-around text-secondary flex-lg-row flex-column">
						<div class=" my-lg-0 my-3">
							<img src="{{ asset('icons/svg/grey_tick.svg') }}" class="mx-1" width="25" alt=""> Affordable
						</div>
						<div class="mx-lg-3 my-lg-0 my-3">
							<img src="{{ asset('icons/svg/grey_tick.svg') }}" class="mx-1" width="25" alt=""> Easy to Use
						</div>
						<div class=" my-lg-0 my-3">
							<img src="{{ asset('icons/svg/grey_tick.svg') }}" class="mx-1" width="25" alt=""> Anytime. Anywhere
						</div>
					</div>
				</div>

				<center class="mt-lg-4">
					<img src="{{ asset('icons/svg/gplay2.svg') }}" alt="">
				</center>
			</div>
		</div>
	</div>
	<section>
		
		<div class="container">
			{{-- Web --}}
			<div class="d-none d-sm-none d-lg-block">
				<h1 class="text-center">Stay updated with our blogs</h1>
				<div class="row d-flex justify-content-around px-3 mx-3">
					<div class="col-lg-3 px-0 mx-1">
						<div class="d-flex justify-content-between flex-column">
							<img src="{{ asset('images/1.jpg') }}" alt="" width="100%">
							<div class="pt-2 d-flex justify-content-between">
								<small>Employment</small>
								<small>1hr ago</small>
							</div>
						</div>
						<h4 class="my-3">Work from Home Jobs that Pay Weekly</h4>
						<h5><a href="{{url('/blog/1')}}" class="text-danger border-bottom border-danger">Read Story</a></h5>
					</div>
					<div class="col-lg-3 px-0 mx-1">
						<div class="d-flex justify-content-between flex-column">
							<img src="{{ asset('images/2.jpg') }}" alt="" width="100%">
							<div class="pt-2 d-flex justify-content-between">
								<small>Technology</small>
								<small>1hr ago</small>
							</div>
						</div>
						<h4 class="my-3">AI Being Applied to Improve Health,
							Better Predict Life of Batteries
						</h4>
						<h5><a href="{{url('/blog/1')}}" class="text-danger border-bottom border-danger">Read Story</a></h5>
					</div>
					<div class="col-lg-3 px-0 mx-1">
						<div class="d-flex justify-content-between flex-column">
							<img src="{{ asset('images/3.jpg') }}" alt="" width="100%">
							<div class="pt-2 d-flex justify-content-between">
								<small>Technology</small>
								<small>1hr ago</small>
							</div>
						</div>
						<h4 class="my-3">Cool Little CSS Grid Tricks
							for Your Blog
						</h4>
						<h5><a href="{{url('/blog/1')}}" class="text-danger border-bottom border-danger">Read Story</a></h5>
					</div>
				</div>

				<div class="text-center text-secondary my-5">
					<a href="{{url('/blog')}}" class="mx-3 btn btn-sm btn-outline-danger">View all</a>
				</div>
			</div>
			{{-- Mobile --}}
			<div class="d-md-none d-lg-none d-sm-block">
				<div class="swiper-container">
					<div class="swiper-wrapper">
						<div class="swiper-slide px-2">
							<div class="col-lg-3 px-0">
								<div class="d-flex justify-content-between flex-column">
									<img src="{{ asset('images/1.jpg') }}" alt="" width="100%">
									<div class="pt-2 d-flex justify-content-between">
										<small>Employment</small>
										<small>1hr ago</small>
									</div>
								</div>
								<h4 class="my-3 text-center">Work from Home Jobs that Pay Weekly</h4>
								<h5 class="text-center"><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
							</div>
						</div>
						<div class="swiper-slide px-2">
							<div class="col-lg-3 px-0">
								<div class="d-flex justify-content-between flex-column">
									<img src="{{ asset('images/2.jpg') }}" alt="" width="100%">
									<div class="pt-2 d-flex justify-content-between">
										<small>Technology</small>
										<small>1hr ago</small>
									</div>
								</div>
								<h4 class="my-3 text-center">AI Being Applied to Improve Health,
									Better Predict Life of Batteries
								</h4>
								<h5 class="text-center"><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
							</div>						
						</div>
						<div class="swiper-slide px-2">
							<div class="col-lg-3 px-0">
								<div class="d-flex justify-content-between flex-column">
									<img src="{{ asset('images/3.jpg') }}" alt="" width="100%">
									<div class="pt-2 d-flex justify-content-between">
										<small>Technology</small>
										<small>1hr ago</small>
									</div>
								</div>
								<h4 class="my-3 text-center">Cool Little CSS Grid Tricks
									for Your Blog
								</h4>
								<h5 class="text-center"><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
							</div>
						</div>
					</div>
					<!-- Add Pagination -->
					<div class="swiper-pagination"></div>
				</div>
			</div>

		</div>
	</section>

	<div class="container py-8" id="email-subscribe">
		<h1 class="text-center">Subscribe To Our Newsletter.</h1>
		<div class=" d-none d-sm-none d-lg-block">
			<h5 class="text-center mx-auto">Follow our journey and stay updated with all our activities, research<br>
			work, release date, behind the scenes and Newsletters.</h5>
		</div>
		<div class=" d-md-none d-lg-none d-sm-block">
			<h5 class="text-center mx-auto">Follow our journey and stay updated with all our activities, research
		work, release date, behind the scenes and Newsletters.</h5>
		</div>

		<div class="col-lg-6 col-sm-auto mx-auto d-flex justify-content-center my-5">
			<form class="newsletter-shadow p-1 d-flex w-100" style="border-radius: .25rem">
				<img src="{{ asset('icons/svg/mail.svg')}}" alt="" class="ml-3" width="20">
				<input type="email" class="newsletter-input w-100" placeholder="Enter your email address" required>
				<button type="submit" class="btn btn-danger vh-75 my-auto font-weight-light mr-1" style="background-color: #e00000"> Submit </button>
			</form>
		</div>
	</div>

	<footer>
		<div class="container px-0">
			<div class="row py-5 mx-0">
				<div class="col-lg-3">
					<img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""><br>
					<small class="d-flex my-5" style="color: #a9a9a9">Lawnics Technologies Private Limited</small>
				</div>

				<div class="accordion container-fluid d-lg-none d-sm-block" id="accordionExample">
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingTwo">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								Our Vision
							</h2>
						</div>
						<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Our Company</a><br></h4>
								<h4><a class="accordText" href="#">Privacy Policies</a><br></h4>
								<h4><a class="accordText" href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingThree">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Services
							</h2>
						</div>
						<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Print</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFour">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
								Customer support
							</h2>
						</div>
						<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">FAQ's</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFive">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								Resources
							</h2>
						</div>
						<div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Contact Us</a><br></h4>
								<h4><a class="accordText" href="#">Email Sign-Up</a><br></h4>
								<h4><a class="accordText" href="#">Support</a></h4>
								<h4><a class="accordText" href="#">Blog</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingSix">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
								Follow Us
							</h2>
						</div>
						<div id="collapseSix" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Instagram</a><br></h4>
								<h4><a class="accordText" href="#">Facebook</a><br></h4>
								<h4><a class="accordText" href="#">Twitter</a></h4>
							</div>
						</div>
					</div>
				</div>


				<div class="col d-lg-flex d-none  justify-content-between">
					
					<div class="col-lg-2 w-75  px-0 flex-column">
						<h6 class="font-weight-bold" style="color: white!important">Our Vision</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Our Company</a><br></h6>
						<h6><a href="#">Privacy Policies</a><br></h6>
						<h6><a href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Services</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Print</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Customer support</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">FAQ's</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Resources</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Contact Us</a><br></h6>
						<h6><a href="#">Email Sign-Up</a><br></h6>
						<h6><a href="#">Support</a><br></h6>
						<h6><a href="#">Blog</a><br></h6>
					</div>
					<div class="col-lg-2 w-75 px-0">
						<h6 class="font-weight-bold" style="color: white!important">Follow Us</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Instagram</a><br></h6>
						<h6><a href="#">Facebook</a><br></h6>
						<h6><a href="#">Twitter</a><br></h6>
					</div>
				</div>
			</div>

			<HR class="m-0 my-3" style="border: 1px solid grey;"></HR>

			<div class="col d-lg-flex flex-lg-row flex-sm-column justify-content-between py-3">
				<div>
					<h6>© Copyright Lawnics technologies Private Limited 2018-2020.</h6>
				</div>
				<div class="d-flex justify-content-around" id="ligherFont">
					<div class="mx-4"><h6><a href="#">Terms</a></h6></div>
					<div class="mx-4"><h6><a href="#">Privacy</a></h6></div>
					<div class="mx-4"><h6><a href="#">Contacts</a></h6></div>
					<div class="mx-4"><h6><a href="#">Location</a></h6></div>
				</div>
			</div>
		</div>
	</footer>

	<script src="{{ asset('/assets/vendor/jquery/dist/jquery.min.js') }}"></script>
	<script src="{{ asset('/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
	<script src="{{ asset('assets/js/swiper.min.js') }}"></script>
	<script src="{{ asset('assets/js/bodymovin_js.js') }}"></script>
	<script src="{{ asset('assets/js/lottie_js.js') }}"></script>

	<script>
		var swiper = new Swiper('.swiper-container', {
			pagination: {
				el: '.swiper-pagination',
				dynamicBullets: true,
			},
		});
	</script>
</body>
</html>
