<div class="d-none d-sm-none d-lg-block">
	<ul class="nav nav-pills pb-3 justify-content-around border-bottom" id="pills-tab" role="tablist">
		<li class="" role="presentation">
			<a class="redtext pb-3 active" style="color: black;" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Document scanner</a>
		</li>
		<li class="" role="presentation">
			<a class="redtext pb-3" style="color: black;" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Document manager</a>
		</li>
		<li class="" role="presentation">
			<a class="redtext pb-3" style="color: black;" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Order print</a>
		</li>
		<li class="" role="presentation">
			<a class="redtext pb-3" style="color: black;" id="pills-export-tab" data-toggle="pill" href="#pills-export" role="tab" aria-controls="pills-export" aria-selected="false">Export & Share</a>
		</li>
		<li class="" role="presentation">
			<a class="redtext pb-3" style="color: black;" id="pills-wallet-tab" data-toggle="pill" href="#pills-wallet" role="tab" aria-controls="pills-wallet" aria-selected="false">Wallet</a>
		</li>
	</ul>
	<div class="tab-content" id="pills-tabContent">
		<div class="tab-pane fade show active justify-content-center" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
			<div class="container d-flex justify-content-center">
				<div class="row w-100">
					<div class="col-lg-6 d-none d-sm-none d-lg-block">
						<div class=" p-3">
							<h12>Scan your <br>Important document</h12><br>
							<small>Go paperless by scanning all your important documents, use them whenever and wherever you need them.</small>
							<br>
							<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
						</div>
					</div>
					<div class="col-lg-1"></div>
					<div class="col-lg-3 p-0 px-lg-3">
						<lottie-player src="{{ asset('lottie_files/document_scanner.json') }}" autoplay loop ></lottie-player>
					</div>
				</div>
			</div>
		</div>
		<div class="tab-pane fade justify-content-center" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
			<div class="container d-flex justify-content-center">
				<div class="row w-100">
					<div class="col-lg-6 d-none d-sm-none d-lg-block">
						<div class=" p-3">
							<h12>Manage your<br>work documents</h12><br>
							<small>Work efficiently by editing, organising and storing all documents in your mobile and cloud. Access then in one tap from anywhere.</small>
							<br>
							<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
						</div>
					</div>
					<div class="col-lg-1"></div>
					<div class="col-lg-3 p-0 px-lg-3">
						<lottie-player src="{{ asset('lottie_files/document_manager.json') }}" autoplay loop ></lottie-player>
					</div>
				</div>
			</div>
		</div>
		<div class="tab-pane fade justify-content-center" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
			<div class="container d-flex justify-content-center">
				<div class="row w-100">
					<div class="col-lg-6 d-none d-sm-none d-lg-block">
						<div class=" p-3">
							<h12>Get your documents<br>Printed from local shop</h12><br>
							<small>Save time and money by using our print services. Whether you need few pages or bulk Printing, we handle all your requirement with easy to order process from local vendor.</small>
							<br>
							<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
						</div>
					</div>
					<div class="col-lg-1"></div>
					<div class="col-lg-3 p-0 px-lg-3">
						<lottie-player src="{{ asset('lottie_files/order_print_screen.json') }}" autoplay loop ></lottie-player>
					</div>
				</div>
			</div>
		</div>
		<div class="tab-pane fade justify-content-center" id="pills-export" role="tabpanel" aria-labelledby="pills-export-tab">
			<div class="container d-flex justify-content-center">
				<div class="row w-100">
					<div class="col-lg-6 d-none d-sm-none d-lg-block">
						<div class=" p-3">
							<h12>Find relevant statutes<br>and cases, instantly.</h12><br>
							<small>No more going through bare acts, case journals or costly online legal database. Save 6x amount of time to search the relevant laws easily from mobile.</small>
							<br>
							<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
						</div>
					</div>
					<div class="col-lg-1"></div>
					<div class="col-lg-3 p-0 px-lg-3">
						<lottie-player src="{{ asset('lottie_files/share_export_2.json') }}" autoplay loop ></lottie-player>
					</div>
				</div>
			</div>
		</div>
		<div class="tab-pane fade justify-content-center" id="pills-wallet" role="tabpanel" aria-labelledby="pills-wallet-tab">
			<div class="container d-flex justify-content-center">
				<div class="row w-100">
					<div class="col-lg-6 d-none d-sm-none d-lg-block">
						<div class=" p-3">
							<h12>Draft required documents in no time.</h12><br>
							<small>Experience the most advance AI driven drafting tool that helps you bring speed, efficiency, less risk and lower costs. Generate documents, edit them on the go and create value for clients</small>
							<br>
							<button type="button" class="my-4 btn btn-sm btn-outline-danger">Know more</button>
						</div>
					</div>
					<div class="col-lg-1"></div>
					<div class="col-lg-3 p-0 px-lg-3">
						<lottie-player src="{{ asset('lottie_files/wallet_screen.json') }}" autoplay loop ></lottie-player>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>