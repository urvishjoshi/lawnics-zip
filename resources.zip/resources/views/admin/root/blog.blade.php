<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Lawnics lawyers.">
	<meta name="author" content="Urvish Joshi">
	<title>Lawnics</title>
	<!-- Favicon -->
	<link rel="icon" href="{{ asset('Lawnics.png') }}" type="image/png">
	<!-- Fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
	<!-- Icons -->
	<link rel="stylesheet" href="{{ asset('/assets/vendor/nucleo/css/nucleo.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

	<link rel="stylesheet" href="{{ asset('/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
	<!-- Argon CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/argon.css') }}" type="text/css">
	<!-- Select tag CSS -->
	<link rel="stylesheet" href="{{ asset('/assets/css/select2.min.css') }}" type="text/css">
	<link rel="stylesheet" href="{{ asset('/assets/css/swiper.min.css') }}" type="text/css">
	<style>
		/*@import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');*/
		body{
			font-family: 'Poppins', sans-serif;
			background-color: white!important;
			font-weight: bold
		}
		h1,h4,p{color: black}
		h12{
			font-size: 48px; color: black;
		}
		redtext{color: red}
		.redtext.active{color: red!important;border-bottom: 3px solid red;}
		.my-8{ margin-top: 8rem !important;}
		.py-8{ padding-top: 8rem !important;}
		.border-w-3{border-left: 3px solid red}
		.bg-black{background-color: black;}
		.newsletter-input{border-top-left-radius: .25rem;border-bottom-left-radius: .25rem; border: 0px;padding: 0.8rem 0.8rem;}
		.newsletter-shadow{box-shadow: 0 0px 20px 1px rgb(50 50 93 / 11%), 0 1px 3px rgb(0 0 0 / 8%);}
		footer{
			background-color: black!important;
			color: white;
		}
		footer > div  > div  > div > h6,#ligherFont {color: darkgrey!important;font-weight: lighter!important;}
		footer > div  > div  > div > div > h6 {color: darkgrey!important;font-weight: lighter!important;}
		.badge-danger{background-color: #f80031;color: #fdd1da;}
		.accordText {color: darkgrey!important;font-weight: lighter!important;}
		.tab-pane > div { 
			background-image: url('{{ asset('icons/svg/background_logo.svg') }}'); 
			background-repeat: no-repeat;
			background-position: 100%;
			background-size: 45%;
			padding-top: 5%
		}
		.w-400 { width: 400px; }

		@media (max-device-width:768px) {
			.mobile-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-position: 100% 0%;
				background-size: 350%!important;
			}
			.text-sm-center{text-align: center !important;}
			.my-sm-8{ margin-top: 8rem !important;}
			.navbar-nav{flex-direction: inherit!important;}
			.justify-content-sm-around{    justify-content: space-around !important;}
		}
		@media (min-device-width:768px) {
			.web-bg{
				background-image: url('{{ asset('icons/svg/homepage.svg') }}');background-repeat: no-repeat;
				background-size: 100%!important;
			}
			.border-web-3{border-left: 3px solid red}
			.my-web-8{ margin-top: 8rem !important;}
		}
	</style>

</head>
<body class="_bg web-bg mobile-bg">

	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
			<a class="navbar-brand" href="#"><img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""></a>
			{{-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button> --}}

			<div class="navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto justify-content-sm-around">
					<li class="nav-item active">
						<a class="nav-link text-light" href="#">Discover</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Vision</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="#">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link text-light" href="{{url('blog')}}">Blog</a>
					</li>
					<li class="nav-item d-none d-lg-block">
						<button type="button" class="mx-3 btn btn-sm btn-outline-light">Download</button>
					</li>
				</ul>
			</div>
		</nav>
	</div>

	<section class="container" style="height: 600px"></section>
	<section class="container my-8">
		
		<div class="row my-8">
			<div class="col-4">
				<div class="col">
					<img src="{{ asset('images/1.jpg') }}" alt="" width="100%">
					{{-- <div class="pt-2 d-flex justify-content-between">
						<small>Employment</small>
						<small>1hr ago</small>
					</div> --}}
				</div>
			</div>
			<div class="col-8 pl-5">
				<div class="px-5">
					<h12 class=" text-center">Work from Home Jobs that Pay Weekly</h12>
					<h3 class="my-5 text-muted font-weight-lighter">The team behind the project, led by Chinthaka Premachandra</h3>
					<h5><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
				</div>
			</div>
		</div>		
		<div class="row my-8 flex-row-reverse">
			<div class="col-4">
				<div class="col">
					<img src="{{ asset('images/1.jpg') }}" alt="" width="100%">
					{{-- <div class="pt-2 d-flex justify-content-between">
						<small>Employment</small>
						<small>1hr ago</small>
					</div> --}}
				</div>
			</div>
			<div class="col-8 pl-5">
				<div class="px-5">
					<h12 class=" text-center">Work from Home Jobs that Pay Weekly</h12>
					<h3 class="my-5 text-muted font-weight-lighter">The team behind the project, led by Chinthaka Premachandra</h3>
					<h5><a href="#" class="text-danger border-bottom border-danger">Read Story</a></h5>
				</div>
			</div>
		</div>	

	</section>

	<footer>
		<div class="container px-0">
			<div class="row py-5 mx-0">
				<div class="col-lg-3">
					<img src="{{ asset('icons/svg/logo_bottom.svg')}}" alt=""><br>
					<small class="d-flex my-5" style="color: #a9a9a9">Lawnics Technologies Private Limited</small>
				</div>

				<div class="accordion container-fluid d-lg-none d-sm-block" id="accordionExample">
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingTwo">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								Our Vision
							</h2>
						</div>
						<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Our Company</a><br></h4>
								<h4><a class="accordText" href="#">Privacy Policies</a><br></h4>
								<h4><a class="accordText" href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingThree">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Services
							</h2>
						</div>
						<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Print</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFour">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
								Customer support
							</h2>
						</div>
						<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">FAQ's</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0 border-bottom border-top">
						<div class="card-header bg-transparent" id="headingFive">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								Resources
							</h2>
						</div>
						<div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Contact Us</a><br></h4>
								<h4><a class="accordText" href="#">Email Sign-Up</a><br></h4>
								<h4><a class="accordText" href="#">Support</a></h4>
								<h4><a class="accordText" href="#">Blog</a><br></h4>
							</div>
						</div>
					</div>
					<div class="card bg-transparent m-0">
						<div class="card-header bg-transparent" id="headingSix">
							<h2 class="mb-0 accordText collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
								Follow Us
							</h2>
						</div>
						<div id="collapseSix" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
							<div class="card-body bg-transparent">
								<h4><a class="accordText" href="#">Instagram</a><br></h4>
								<h4><a class="accordText" href="#">Facebook</a><br></h4>
								<h4><a class="accordText" href="#">Twitter</a></h4>
							</div>
						</div>
					</div>
				</div>


				<div class="col d-lg-flex d-none  justify-content-between">
					
					<div class="col-lg-2 w-75  px-0 flex-column">
						<h6 class="font-weight-bold" style="color: white!important">Our Vision</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Our Company</a><br></h6>
						<h6><a href="#">Privacy Policies</a><br></h6>
						<h6><a href="#">Join Lawnics <span class="badge badge-pill badge-danger ml-2">We are hiring</span></a></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Services</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Print</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Customer support</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">FAQ's</a><br></h6>
					</div>
					<div class="col-lg-2 w-75  px-0">
						<h6 class="font-weight-bold" style="color: white!important">Resources</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Contact Us</a><br></h6>
						<h6><a href="#">Email Sign-Up</a><br></h6>
						<h6><a href="#">Support</a><br></h6>
						<h6><a href="#">Blog</a><br></h6>
					</div>
					<div class="col-lg-2 w-75 px-0">
						<h6 class="font-weight-bold" style="color: white!important">Follow Us</h6>
						<hr width="20" class="m-0 my-3" style="border: 1px solid white;">
						<h6><a href="#">Instagram</a><br></h6>
						<h6><a href="#">Facebook</a><br></h6>
						<h6><a href="#">Twitter</a><br></h6>
					</div>
				</div>
			</div>

			<HR class="m-0 my-3" style="border: 1px solid grey;"></HR>

			<div class="col d-lg-flex flex-lg-row flex-sm-column justify-content-between py-3">
				<div>
					<h6>© Copyright Lawnics technologies Private Limited 2018-2020.</h6>
				</div>
				<div class="d-flex justify-content-around" id="ligherFont">
					<div class="mx-2"><h6><a href="#">Terms</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Privacy</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Contacts</a></h6></div> | 
					<div class="mx-2"><h6><a href="#">Location</a></h6></div>
				</div>
			</div>
		</div>
	</footer>

	<script src="{{ asset('/assets/vendor/jquery/dist/jquery.min.js') }}"></script>
	<script src="{{ asset('/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
	<script src="{{ asset('assets/js/swiper.min.js') }}"></script>
	<script src="{{ asset('assets/js/bodymovin_js.js') }}"></script>
	<script src="{{ asset('assets/js/lottie_js.js') }}"></script>

	<script>
		var swiper = new Swiper('.swiper-container', {
			pagination: {
				el: '.swiper-pagination',
				dynamicBullets: true,
			},
		});
	</script>
</body>
</html>
