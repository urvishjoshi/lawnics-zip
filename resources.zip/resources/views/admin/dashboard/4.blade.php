@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')

<section>
    <div class="p-4">
        @include('admin.dashboard.layout')
        <!-- BAR CHART -->
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="totord"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="mypages"></canvas>
                        </div>
                        <div class="col-sm text-center">
                            <table class="table table-borderless table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Package</th>
                                        <th>Credits</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #141715"></i></td>
                                        <td>Basic Package</td>  
                                        <td>50</td>
                                        <td>100</td>
                                        <td>5000</td>
                                    </tr> 
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #555657"></i></td>
                                        <td>Popular Package</td>  
                                        <td>50</td>
                                        <td>100</td>
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #b9bbbd"></i></td>
                                        <td>Special Package</td>  
                                        <td>50</td>
                                        <td>100</td>
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <th>Total</th>  
                                        <th>150</th>
                                        <th></th>
                                        <th>15000</th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Payment mode</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="mypendorder"></canvas>
                        </div>
                        <div class="col-sm text-center">
                            <table class="table table-borderless table-responsive-sm">
                                <tbody>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #141715"></i></td>
                                        <td>Cash</td>  
                                        <td>10000</td>
                                    </tr> 
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #555657"></i></td>
                                        <td>UPI</td>  
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #b9bbbd"></i></td>
                                        <td>Paytm</td>  
                                        <td>2000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Credits</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="mypackages"></canvas>
                        </div>
                        <div class="col-sm text-center">
                            <table class="table table-borderless table-responsive-sm">
                                <tbody>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #141715"></i></td>
                                        <td>Credits through purchase</td>  
                                        <td>10000</td>
                                    </tr> 
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #555657"></i></td>
                                        <td>Credits through verification</td>  
                                        <td>5000</td>
                                    </tr>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #b9bbbd"></i></td>
                                        <td>Credits through gamification</td>  
                                        <td>2000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="totsum"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        @include('admin.dashboard.component')

        <div class="card">
            <div class="card-header bg-transparent">
                <canvas id="myprodsale"></canvas>
            </div>
        </div>
    </div>
</section>

@endsection
@section('jquery')
    <script type="text/javascript">
        let myTotOrd=document.getElementById('totord').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massTotOrd=new Chart(myTotOrd,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Succesfull",
                    stack:"Stack 0",
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#26b802",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Unsuccesfull",
                    stack:"Stack 0",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#b81102',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Total Orders",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myPages=document.getElementById('mypages').getContext('2d');

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massPage=new Chart(myPages,{
            type:'doughnut',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['A3 Paper','Legal Paper','A4 Paper','Letter'],
                datasets:[{
                    label:'Pages',
                    data:[13,23,18,29],
                    backgroundColor:['#ebb607','#62eb07','#eb2807','#4d4746'],
                    borderColor:'#34eb80',
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Pages',
                    fontSize:'30'
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myPendOrder=document.getElementById('mypendorder').getContext('2d');

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massPend=new Chart(myPendOrder,{
            type:'doughnut',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Order','Printing','Printed','Delivery'],
                datasets:[{
                    label:'Pending Order',
                    data:[13,23,18,29],
                    backgroundColor:['#ebb607','#62eb07','#eb2807','#4d4746'],
                    borderColor:'#34eb80',
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Pending Order',
                    fontSize:'30'
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        //buttton of sales

        //sales part chart manager
        let myPackage=document.getElementById('mypackages').getContext('2d');

        var basic_pack = 10;
        var popular_pack = 20;
        var special_pack = 25;

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massPack=new Chart(myPackage,{
            type:'doughnut',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Basic Package','Popular Package','Special Package'],
                datasets:[{
                    label:'Packages',
                    data:[basic_pack,popular_pack,special_pack],
                    backgroundColor:['#141715','#555657','#b9bbbd'],
                    borderColor:'#34eb80',
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Packages',
                    fontSize:'30'
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let mySum=document.getElementById('totsum').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massSum=new Chart(mySum,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Printing Partner",
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#072deb",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Basic Pack",
                    stack:"Stack 0",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#050505',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Popular Pack",
                    stack:"Stack 0",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#eb0e0e',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Special Pack",
                    stack:"Stack 0",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#706b6b',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Delivery Partner",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#f7c200',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Total Orders",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myProdSale=document.getElementById('myprodsale').getContext('2d');

        var pur = 10;
        var verification = 20;

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massProds=new Chart(myProdSale,{
            type:'line',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Moday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                datasets:[{
                    label:'Product Sale',
                    data:[5,8,15,20,28,21,25,36],
                    backgroundColor:['#141715','#555657','#555657','#555657','#555657','#555657','#555657'],
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Product Sale',
                    fontSize:'30'
                },
            }
        }); 
    </script>
@endsection