<div class="card card-dark mb-3 rounded">
    <div class="card-header border-0 p-3 rounded-top">
        <div class="row align-items-center">
            <div class="col-lg-3 col-6">
                <div class="small-box p-3">
                    <img src="{{ asset('icons/user.png') }}"></span>
                    <h1>400</h1>
                    <h5>Total orders</h5>
                </div>
            </div>
            <div class="col-lg col-3 d-flex justify-content-end mb-auto">
                <button class="btn btn-sm btn-primary"  data-toggle="modal" data-target="#datepicker">Sort</button>
                <button class="btn btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box p-3">
                    <img src="{{ asset('icons/user.png') }}"></span>
                    <h1>150</h1>
                    <h5>Pending orders</h5>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box p-3">
                    <img src="{{ asset('icons/user.png') }}"></span>
                    <h1>150</h1>
                    <h5>Cancelled orders</h5>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box p-3">
                    <img src="{{ asset('icons/user.png') }}"></span>
                    <h1>150</h1>
                    <h5>Successfull orders</h5>
                </div>
            </div>
        </div>
        <div class="row px-3">
            <div class="col-lg d-flex small-box p-3 m-0 mb-2">
                <div class="col-lg">
                    <b class="align-text-top">1.</b>
                    <div class="d-flex align-items-center">
                        <div class="mx-auto">
                            <h1>22</h1>
                            <h5>Order</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-circle align-text-bottom"></i>
                        <img src="{{ asset('icons/user.png') }}" class="align-self-end">
                    </div>
                </div>
                <div class="col-lg border-left border-right">
                    <b class="align-text-top">2.</b>
                    <div class="d-flex align-items-center">
                        <div class="mx-auto">
                            <h1>22</h1>
                            <h5>Printing</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-circle align-text-bottom"></i>
                        <img src="{{ asset('icons/user.png') }}" class="align-self-end">
                    </div>
                </div>
                <div class="col-lg">
                    <b class="align-text-top">3.</b>
                    <div class="d-flex align-items-center">
                        <div class="mx-auto">
                            <h1>22</h1>
                            <h5>Printed</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-circle align-text-bottom"></i>
                        <img src="{{ asset('icons/user.png') }}" class="align-self-end">
                    </div>
                </div>
                <div class="col-lg border-left border-right">
                    <b class="align-text-top">4.</b>
                    <div class="d-flex align-items-center">
                        <div class="mx-auto">
                            <h1>22</h1>
                            <h5>Delivery</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-circle align-text-bottom"></i>
                        <img src="{{ asset('icons/user.png') }}" class="align-self-end">
                    </div>
                </div>
                <div class="col-lg">
                    <b class="align-text-top">5.</b>
                    <div class="d-flex align-items-center">
                        <div class="mx-auto">
                            <h1>22</h1>
                            <h5>Delivered</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <i class="fas fa-circle align-text-bottom"></i>
                        <img src="{{ asset('icons/user.png') }}" class="align-self-end">
                    </div>
                </div>
            </div>
        </div>
        <div class="progress my-3 h-100">
            <div class="progress-bar bg-red" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
            <div class="progress-bar" role="progressbar" style="width: 20%;background-color: #6f6f6f;" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
            <div class="progress-bar bg-dark" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
            <div class="progress-bar bg-yellow" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
            <div class="progress-bar bg-blue" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">20%</div>
        </div>
    </div>
    <!-- Projects table -->
    <div class="table-responsive">
        <table class="table align-items-center table-flush text-center">
            <thead class="thead-light">
                <tr>
                    <th>#
                    <th>Customer name
                    <th>Product ID
                    <th>Date & time
                    <th>Quantity
                    <th>Credits
                    <th>Status
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>1
                    <td>ABC
                    <td>123645
                    <td>05/02/2020 & 10:28 PM
                    <td>3
                    <td>+50
                    <td><i class="fas fa-circle"></i> Pending
                </tr><tr>
                    <th>1
                    <td>ABC
                    <td>123645
                    <td>05/02/2020 & 10:28 PM
                    <td>3
                    <td>+50
                    <td><i class="fas fa-circle"></i> Pending
                </tr><tr>
                    <th>1
                    <td>ABC
                    <td>123645
                    <td>05/02/2020 & 10:28 PM
                    <td>3
                    <td>+50
                    <td><i class="fas fa-circle"></i> Pending
                </tr>
            </tbody>
        </table>
    </div>
</div>