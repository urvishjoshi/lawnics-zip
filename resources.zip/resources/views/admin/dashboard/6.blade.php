@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')

<section>
    <div class="p-4">
        @include('admin.dashboard.layout')
        <!-- DONUT CHART -->
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0">
                <h2>Services and Products</h2>
                </div>
                <div id="serviceproducts">
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="myservices"></canvas>
                        </div>
                        <div class="col-sm text-center">
                            <table class="table table-borderless table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th width="1%"></th>
                                        <th width="49%">Storage</th>
                                        <th width="49%">No. of User</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #141715"></i></td>
                                        <td>200MB</td>  
                                        <td>50</td>
                                    </tr> 
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #555657"></i></td>
                                        <td>300MB</td>  
                                        <td>50</td>
                                    </tr>
                                    <tr>
                                        <td><i class="fas fa-circle" style="color: #b9bbbd"></i></td>
                                        <td>400MB</td>  
                                        <td>50</td>
                                    </tr>  
                                    <tr>
                                        <td></td>
                                        <th>Total</th>  
                                        <th>150</th>
                                    </tr>    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        @include('admin.dashboard.component')

        <div class="card rounded">
            <div class="card-header bg-transparent">
                <canvas id="myprodsale"></canvas>
            </div>
        </div>
    </div>
</section>

@endsection
@section('jquery')
<script type="text/javascript">
        //buttton of sales

        //sales part chart manager
        let myAvg=document.getElementById('myservices').getContext('2d');

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massMark=new Chart(myAvg,{
            type:'doughnut',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                datasets:[{
                    label:'Packages',
                    data:[50,50,50],
                    backgroundColor:['#141715','#555657','#b9bbbd'],
                }]
            },
            options:{
                responsive: true,
            }
        }); 
    </script>
    <script type="text/javascript">
        let myProdSale=document.getElementById('myprodsale').getContext('2d');

        var pur = 10;
        var verification = 20;

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massProds=new Chart(myProdSale,{
            type:'line',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Moday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                datasets:[{
                    label:'Product Sale',
                    data:[5,8,15,20,28,21,25,36],
                    backgroundColor:['#141715','#555657','#555657','#555657','#555657','#555657','#555657'],
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Product Sale',
                    fontSize:'30'
                },
            }
        }); 
    </script>
@endsection