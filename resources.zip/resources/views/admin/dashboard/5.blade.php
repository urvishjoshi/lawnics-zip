@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')

<section>
    <div class="p-4">
        @include('admin.dashboard.layout')
        <!-- BAR CHART -->
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="transusers"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="transprint"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="transdeliver"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        @include('admin.dashboard.component')

        <div class="card">
            <div class="card-header bg-transparent">
                <canvas id="myprodsale"></canvas>
            </div>
        </div>
    </div>
</section>

@endsection
@section('jquery')
    <script type="text/javascript">
        let myTransUser=document.getElementById('transusers').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massTransUser=new Chart(myTransUser,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Recharge by delivery partner",
                    stack:'Stack 0',
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#26b802",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  } ,
                  {
                    label : "Recharge by printing partner",
                    stack:'Stack 0',
                    data : [10, 12, 11, 16, 12],
                    backgroundColor :"#e32c0b",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Printing partner amount",
                    stack:'Stack 1',
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#e3d50b',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Delivery partner amount",
                    stack:'Stack 1',
                    data : [10, 12, 11, 16, 12],
                    backgroundColor :"#4287f5",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Transaction Users",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myDeliver=document.getElementById('transdeliver').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massDeliver=new Chart(myDeliver,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Total Amount Paid",
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#26b802",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Total Amount Due",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#b81102',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Print per page",
                    data : [30, 12, 15, 56, 42],
                    backgroundColor :"#e3bc0e",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Transaction Printing Partner",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myPrint=document.getElementById('transprint').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massPrint=new Chart(myPrint,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Total Amount Paid",
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#26b802",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Total Amount Due",
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#b81102',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Transaction Delivery Partner",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myProdSale=document.getElementById('myprodsale').getContext('2d');

        var pur = 10;
        var verification = 20;

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massProds=new Chart(myProdSale,{
            type:'line',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Moday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                datasets:[{
                    label:'Product Sale',
                    data:[5,8,15,20,28,21,25,36],
                    backgroundColor:['#141715','#555657','#555657','#555657','#555657','#555657','#555657'],
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Product Sale',
                    fontSize:'30'
                },
            }
        }); 
    </script>
@endsection