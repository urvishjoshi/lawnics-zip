@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')

<section>
    <div class="p-4">
        @include('admin.dashboard.layout')
        <!-- BAR CHART -->
        <div class="card p-3 mb-3 rounded">
            <div class="card-body p-0">
                <div class="card-header p-2 bg-transparent border-0"><h2>Packages</h2></div>
                <div>
                    <div class="row">
                        <div class="col-sm">
                            <canvas id="myusers"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @include('admin.dashboard.component')

        <div class="card">
            <div class="card-header bg-transparent">
                <canvas id="myprodsale"></canvas>
            </div>
        </div>
    </div>
</section>

@endsection
@section('jquery')
    <script type="text/javascript">
        let myUser=document.getElementById('myusers').getContext('2d');


        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massUser=new Chart(myUser,{
            type:'bar',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels : ["Monday", "Tudesday", "Wednesday", "Thursday", "Friday"],
                datasets : [
                  {
                    label : "Advocate",
                    stack:'Stack 0',
                    data : [10, 50, 25, 70, 40],
                    backgroundColor :"#f04718",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  } ,
                  {
                    label : "Verified",
                    stack:'Stack 0',
                    data : [10, 12, 11, 16, 12],
                    backgroundColor :"#42454a",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Senior Advocate",
                    stack:'Stack 1',
                    data : [20, 35, 40, 60, 50],
                    backgroundColor :'#96f018',
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Verified",
                    stack:'Stack 1',
                    data : [10, 12, 11, 16, 12],
                    backgroundColor :"#42454a",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Clerk",
                    stack:'Stack 2',
                    data : [30, 12, 15, 56, 42],
                    backgroundColor :"#18f0af",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  },
                  {
                    label : "Verified",
                    stack:'Stack 2',
                    data : [10, 12, 11, 16, 12],
                    backgroundColor :"#42454a",
                    borderColor : [
                      "#111", "#111", "#111", "#111", "#111"
                    ],
                    borderWidth : 1
                  }
                ]
            },
            options:{
                title : {
                  display : true,
                  position : "top",
                  text : "Users",
                  fontSize : 18,
                  fontColor : "#111"
                },
                legend : {
                  display : true
                },
                scales : {
                  yAxes : [{
                    ticks : {
                      min : 0
                    }
                  }]
                },
            }
        }); 
    </script>
    <script type="text/javascript">
        let myProdSale=document.getElementById('myprodsale').getContext('2d');

        var pur = 10;
        var verification = 20;

        //Global Options
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = '#101112';

        let massProds=new Chart(myProdSale,{
            type:'line',//type of chart we want eg: bar,horizontal,pie,line,doughnut,radar
            data:{
                labels:['Moday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                datasets:[{
                    label:'Product Sale',
                    data:[5,8,15,20,28,21,25,36],
                    backgroundColor:['#141715','#555657','#555657','#555657','#555657','#555657','#555657'],
                }]
            },
            options:{
                responsive: true,
                title:{
                    display:true,
                    text:'Product Sale',
                    fontSize:'30'
                },
            }
        }); 
    </script>
@endsection