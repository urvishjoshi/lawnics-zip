    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Lawnics lawyers.">
    <meta name="author" content="Urvish Joshi">
    <title>@yield('title') | Lawnics</title>
    <!-- Favicon -->
    <link rel="icon" href="{{ asset('Lawnics.png') }}" type="image/png">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Icons -->
    <link rel="stylesheet" href="{{ asset('/assets/vendor/nucleo/css/nucleo.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

    <link rel="stylesheet" href="{{ asset('/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
    <!-- Argon CSS -->
    <link rel="stylesheet" href="{{ asset('/assets/css/argon.css') }}" type="text/css">
    <!-- Select tag CSS -->
    <link rel="stylesheet" href="{{ asset('/assets/css/select2.min.css') }}" type="text/css">
    <style>
        .note-editable{height: 400px;}
        .fas{font-size: inherit!important;}
        .overlay{position: relative;}
        .overicon{position: absolute;margin-top: 21px;margin-left: 23px;width: 12px;}
        #toast-body{position:fixed;top:80%;z-index: 9999;opacity: 0.9}
        .card-profile>.card-header{background-color: white;}
        .card-header{background-color: black;}
        .card-header h3{color: white!important;}
        .bg-white{background-color: black!important;}
        .nav-link,.navbar-brand{color: white!important;}
        ul>li>a{margin-left: 20px!important;}
        ul>li>a.active{background-color: #6f6f6f!important;font-weight: bold!important;padding-left: 24px!important;}
        .pass-border-dark{border: solid darkgrey 1px!important;border-radius: 7px;}   /*used in passbook in segmentation*/
        .pass-border-fail{border: solid #dc3545 1px!important;border-radius: 7px;}   /*used in passbook in segmentation*/
        .fas{font-size: 20px}
        .fa-search{font-size: 12px}
        td>button.btn-primary{background-color: black!important;color: white!important}
        /*ul>li>a.nav-link{padding-top: 0px; padding-bottom: 0px; }*/
        td>button.active{background-color: #f5365c!important;border-color: #f5365c!important;} /*for toggling time slots in printpartners profle*/
        icons>.fas{padding-left: 10px;padding-right: 10px;font-size: 225%!important; height: inherit; line-height: inherit;}

        /* width */
        ::-webkit-scrollbar { width: 0.5rem; height:0.5rem; }
        /* Track */
        ::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.15); }
        /* Handle */
        ::-webkit-scrollbar-thumb { background: black; padding-left: 0.5rem; border-radius: 4px; }
        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover { background: #555; }
        /*footer*/
        /*footer {
            clear: both;
            position: relative;
            height: auto;
            margin-bottom: auto;
        }*/
    </style>
