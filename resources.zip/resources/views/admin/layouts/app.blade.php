<!DOCTYPE html>
<html lang="en">
<head>

	@include('admin.layouts.head')

	@yield('link')

	@if(request()->is('admin/dashboard*') || Request::is('admin/transactions*'))
		<link rel="stylesheet" href="{{asset('assets/css/dashboard.css')}}">
		<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
		<style>.applyBtn{background-color: black; color: white;}</style>
	@endif

</head>
<body oncontextmenu="return false;">

	@include('admin.layouts.sidebar')

  	<div class="main-content" id="panel">

		@include('admin.layouts.header')

		<div class="min-vh-100">
			@yield('content')
		</div>

		@include('admin.layouts.assets.toast')
			
		@include('admin.layouts.footer')

	</div>

	@include('admin.layouts.assets.tableSearch')
		
	@if(Request::is('admin/dashboard*') || Request::is('admin/users/list*') || Request::is('admin/sales/credits*'))
		@include('admin.layouts.assets.usersModal')
		<script src="{{asset('assets/css/Chart.js')}}"></script> @include('admin.layouts.assets.allLocationsAjax')
	@endif
	
	@yield('jquery')
	<script>$('.select2').select2();</script>
	
	@if(Request::is('admin/dashboard*') || Request::is('admin/transactions*'))
		@include('admin.layouts.assets.dateRangePicker')
	@endif
	
</body>
</html>