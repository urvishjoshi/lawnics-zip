@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-control-label" for="country">Country</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="country" id="country" disabled>
                        <option selected>India</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="SAstate">State</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" id="SAstate" name="SAstate">
                        @foreach($locations as $state => $s)
                            @if(Clas::isPlace($state)) <option>{{$state}}</option> @endif
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="SAdistrict">District</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true" id="SAdistrict" name="SAdistrict">
                    </select>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="form-control-label" for="SAcity">City</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" id="SAcity" name="SAcity" placeholder="City">
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg">
                <div class="form-group">
                    <label class="form-control-label" for="SAarea">Area name</label>
                    <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" id="SAarea" name="SAarea">
                    </select>
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-dark" data-dismiss="modal" id="cancel">Cancel</button>
          <button type="button" class="btn btn-dark" data-dismiss="modal" id="apply">Apply</button>
      </div>
    </div>
  </div>
</div>