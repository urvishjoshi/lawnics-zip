@if(session('a.toast'))
	<div id="toast" class="mx-auto container row justify-content-center">
		<div class="alert bg-dark text-white" id="toast-body">
			{{ session('a.toast') }}
		</div>
	</div>
	<script>setTimeout(function() { $('#toast').fadeOut('slow'); }, {{ session('time')}});</script>
@endif