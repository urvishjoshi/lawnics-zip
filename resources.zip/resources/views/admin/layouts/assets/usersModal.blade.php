<?php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; ?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="category">Category</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="10" tabindex="-1" aria-hidden="true" name="category" id="category">
                                <option>Lawyer</option>
                                <option>Non Lawyer</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="designation">Designation</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                                <option>Senior Advocate</option>
                                <option>Junior Advocate</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="state">State</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" id="state" name="state">
                                @foreach($userStates as $state)
                                    <option>{{ $state }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="form-control-label" for="city">City</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="City" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true" id="city" name="city" placeholder="City">
                            </select>
                        </div>
                    </div>
                </div>
                {{-- <div class="row">
                    <div class="col-sm">
                        <div class="form-group">
                            <label class="form-control-label" for="area">Area</label>
                            <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="11" tabindex="-1" aria-hidden="true" id="area" name="area">
                            </select>
                        </div>
                    </div>
                </div> --}}
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal" id="cancel">Cancel</button>
                <button type="button" class="btn btn-dark" data-dismiss="modal" id="apply">Apply</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="datepicker" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <input type="text" class="form-control" name="daterange" value="01/01/2018 - 01/15/2018" />
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal" id="datepickerCancel">Cancel</button>
                <button type="button" class="btn btn-dark" id="datepickerApply">Apply</button>
            </div>
        </div>
    </div>
</div>