<script>
    $('#statePermi').on('change',function(){
        $("#cityPermi").html('');
        $("#areaPermi").html('');
        $.ajax({
            method:"GET",
            url:"{{ route('o.subadmin.show',1) }}",
            data: {
               'state': $(this).val(),
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#cityPermi").html('<option value="">-No City found-</option>');
                }
                else {
                    $("#cityPermi").html(data);
                }
            }
        });
    });
    $('#statePermi12').on('change',function(){
        $("#district").html('');
        $("#cityPermi12").html('');
        $.ajax({
            method:"GET",
            url:"{{ route('allLocations.show',1.2) }}",
            data: {
               'state': $(this).val(),
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#cityPermi12").html('<option value="">-No cityPermi12 found-</option>');
                }
                else {
                    $("#cityPermi12").html(data);
                }
            }
        });
    });

    $('#cityPermi').on('change',function(){
        $("#areaPermi").html('');
        var state = [];
        var district = [];
        var city = [];
        $(this).find("option:selected").each(function(){
            if (!state.includes( $(this).parent().attr("label") ))
            state.push($(this).parent().attr("label"));

            if (!district.includes( $(this).text().split(' - ')[1] ))
            district.push(($(this).text().split(' - '))[1]);

            if (!city.includes( $(this).text().split(' - ')[0] ))
            city.push(($(this).text().split(' - '))[0]);
        });
            // console.log(state,district)
        $.ajax({
            method:"GET",
            url:"{{ route('o.subadmin.show',2) }}",
            data: {
               'state': state,
               'district': district,
               'city': city,
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#areaPermi").html('<option value="">-No City found-</option>');
                }
                else {
                    $("#areaPermi").html(data);
                }
            }
        });
    });
</script>