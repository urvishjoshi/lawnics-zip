<script>
    $('#state').on('change',function(){
        $("#district").html('');
        $("#city").html('');
        $.ajax({
            method:"GET",
            url:"{{ route('allLocations.show',1) }}",
            data: {
               'state': $(this).val(),
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#city").html('<option value="">-No city found-</option>');
                }
                else {
                    $("#city").html(data);
                }
            }
        });
    });
    
    // subadmin ajax
    $('#SAstate').on('change',function(){
        $("#SAdistrict").html('');
        $("#SAcity").html('');
        $("#SAarea").html('');
        $.ajax({
            method:"GET",
            url:"{{ route('allLocations.show',1.5) }}",
            data: {
               'state': $(this).val(),
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#SAdistrict").html('<option value="">-No district found-</option>');
                }
                else {
                    $("#SAdistrict").html(data);
                }
            }
        });
    });
    $('#SAdistrict').on('change',function(){
        $("#SAcity").html('');
        $("#SAarea").html('');
        var state = [];
        var district = [];
        $(this).find("option:selected").each(function(){
            if (!state.includes( $(this).parent().attr("label") ))
            state.push($(this).parent().attr("label"));

            if (!district.includes( $(this).text() ))
            district.push(($(this).text()));
        });
        $.ajax({
            method:"GET",
            url:"{{ route('allLocations.show',2) }}",
            data: {
               'state': state,
               'district': district,
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#SAcity").html('<option value="">-No City found-</option>');
                }
                else {
                    $("#SAcity").html(data);
                }
            }
        });
    });
    $('#SAcity').on('change',function(){
        $("#SAarea").html('');
        var state = [];
        var district = [];
        var city = [];
        $(this).find("option:selected").each(function(){
            if (!state.includes( $(this).parent().attr("label").split(' - ')[1] ))
            state.push($(this).parent().attr("label").split(' - ')[1]);

            if (!district.includes( $(this).text().split(' - ')[0] ))
            district.push($(this).parent().attr("label").split(' - ')[0]);

            if (!city.includes( $(this).text() ))
            city.push($(this).text());
        });
        $.ajax({
            method:"GET",
            url:"{{ route('allLocations.show',3) }}",
            data: {
               'state': state,
               'district': district,
               'city': city,
               '_token': '@csrf',
               '_method': '@method('GET')',
            },
            dataType:'html',
            success:function(data){
                if(data==0) {
                    $("#SAarea").html('<option value="">-No City found-</option>');
                }
                else {
                    $("#SAarea").html(data);
                }
            }
        });
    });
</script>