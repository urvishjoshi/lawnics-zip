@php 
use \App\Http\Controllers\Admin\PermiController as PC; $data = PC::data(); @endphp
<!-- Sidenav -->
<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
  <div class="scrollbar-inner">
    <!-- Brand -->
    <div class="sidenav-header  align-items-center">
      <a class="navbar-brand" href="javascript:void(0)">
        <img src="{{ asset('Lawnics.png') }}" class="navbar-brand-img" alt="..."> Lawnics
      </a>
    </div>
    <div class="navbar-inner">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/dashboard*')) ? 'active' : '' }}" href="{{ route('dashboard.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/dashboardicon.png') }}" width="15"></span>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
      </ul>

      <!-- Nav items -->
      @if(PC::userLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/user.png') }}"></span>
        <span class="docs-normal">User</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        @if(PC::userLink('List', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/users/list*')) ? 'active' : '' }}" href="{{ route('u.list.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/user_list.png') }}"></span>
            <span class="nav-link-text">List</span>
          </a>
        </li>
        @endif
        @if(PC::userLink('Segmentation', $data))
        <li class="nav-item pb-2">
          <a class="nav-link py-1 {{ (Request::is('admin/users/segments*')) ? 'active' : '' }}" href="{{ route('u.segments.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/user_segmentation.png') }}"></span>
            <span class="nav-link-text">Segmentation</span>
          </a>
        </li>
        @endif
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::ppLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/printing_partner.png') }}"></span>
        <span class="docs-normal">Printing partner</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav pb-2">
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/printpartners/list*')) ? 'active' : '' }}" href="{{ route('p.list.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/printing_partner_list.png') }}"></span>
            <span class="nav-link-text">List</span>
          </a>
        </li>
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::operationLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/operations.png') }}"></span>
        <span class="docs-normal">Operations</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        @if(PC::operationLink('Area', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/operations/areas*')) ? 'active' : '' }}" href="{{ route('o.areas.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/area.png') }}">
            </span>
            <span class="nav-link-text">Area</span>
          </a>
        </li>
        @endif
        @if(PC::operationLink('Subadmin', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/operations/subadmin*')) ? 'active' : '' }}" href="{{ route('o.subadmin.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/sub_admin.png') }}">
            </span>
            <span class="nav-link-text">Sub Admin</span>
          </a>
        </li>
        @endif
        @if(PC::operationLink('Order', $data))
        <li class="nav-item pb-2">
          <a class="nav-link py-1 {{ (Request::is('admin/operations/orders*')) ? 'active' : '' }}" href="{{ route('o.orders.index') }}">
            <span class="w-20">
              <img src="{{ asset('icons/order.png') }}">
            </span>
              <span class="nav-link-text">Order</span>
          </a>
        </li>
        @endif
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::salesLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/sales.png') }}"></span>
        <span class="docs-normal">Sales</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/sales/credits*')) ? 'active' : '' }}" href="{{ route('s.credits.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/credits.png') }}">
            </span>
            <span class="nav-link-text">Credits</span>
          </a>
        </li>
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::transactionLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/transaction.png') }}"></span>
        <span class="docs-normal">Transactions</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        @if(PC::transactionLink('User', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/transactions/users*')) ? 'active' : '' }}" href="{{ route('t.users.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/user_transaction.png') }}">
            </span>
            <span class="nav-link-text">User</span>
          </a>
        </li>
        @endif
        @if(PC::transactionLink('Printing partner', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/transactions/printpartners*')) ? 'active' : '' }}" href="{{ route('t.printpartners.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/printing_partner_transaction.png') }}">
            </span>
            <span class="nav-link-text">Printing Partner</span>
          </a>
        </li>
        @endif
        @if(PC::transactionLink('Delivery partner', $data))
        <li class="nav-item pb-2">
          <a class="nav-link py-1 {{ (Request::is('admin/transactions/deliverypartners*')) ? 'active' : '' }}" href="{{ route('t.deliverypartners.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/delivery_partner_transaction.png') }}">
            </span>
            <span class="nav-link-text">Delivery Partner</span>
          </a>
        </li>
        @endif
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::spLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/service_and_product_white.png') }}"></span>
        <span class="docs-normal">Service & Product</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        @if(PC::spLink('Service', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/sp/services*')) ? 'active' : '' }}" href="{{ route('sp.services.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/services_white.png') }}">
            </span>
            <span class="nav-link-text">Service</span>
          </a>
        </li>
        @endif
        @if(PC::spLink('Timeslot', $data))
        <li class="nav-item">
          <a class="nav-link py-1 {{ (Request::is('admin/sp/timeslots*')) ? 'active' : '' }}" href="{{ route('sp.timeslots.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/timeslot.png') }}">
            </span>
            <span class="nav-link-text">Timeslot</span>
          </a>
        </li>
        @endif
        @if(PC::spLink('Paper size & Quality', $data))
        <li class="nav-item pb-2">
          <a class="nav-link py-1 {{ (Request::is('admin/sp/papers*')) ? 'active' : '' }}" href="{{ route('sp.papers.index') }}">
            <span class="w-20">
              <img src="{{ asset('icons/paper_size_and_quality.png') }}">
            </span>
              <span class="nav-link-text">Paper size & Quality</span>
          </a>
        </li>
        @endif
      </ul>
      @endif

      <!-- Heading -->
      @if(PC::amLink('', $data))
      <h6 class="navbar-heading p-0 text-muted pt-2">
        <span class="w-20">
        <img src="{{ asset('icons/app_managment.png') }}"></span>
        <span class="docs-normal">App Management</span>
      </h6>
      <!-- Navigation -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <li class="nav-link py-1">
            <span class="w-20 ml-2">
            <img src="{{ asset('icons/sub_admin.png') }}" class="">
            </span>
            <span class="nav-link-text">Advocate</span>
          </li>
        </li>
        <li class="nav-item">
          @if(PC::amLink('Advocate - About', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/advocateapp/about*')) ? 'active' : '' }}" href="{{ route('aa.about.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/about.png') }}">
            </span>
            <span class="nav-link-text">About</span>
          </a>
          @endif
          @if(PC::amLink('Advocate - Privacy Policy', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/advocateapp/privacypolicy*')) ? 'active' : '' }}" href="{{ route('aa.privacypolicy.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/privacypolicy.png') }}">
            </span>
            <span class="nav-link-text">Privacy Policy</span>
          </a>
          @endif
          @if(PC::amLink('Advocate - Terms & Policy', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/advocateapp/terms&policy*')) ? 'active' : '' }}" href="{{ route('aa.terms&policy.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/termandservices.png') }}">
            </span>
            <span class="nav-link-text">Terms & Policy</span>
          </a>
          @endif
          @if(PC::amLink("Advocate - FAQ's", $data))
          <a class="nav-link py-1 {{ (Request::is('admin/advocateapp/faqs*')) ? 'active' : '' }}" href="{{ route('aa.faqs.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/faq.png') }}">
            </span>
            <span class="nav-link-text">FAQ's</span>
          </a>
          @endif
        </li>
      </ul>
      @endif

      @if(PC::amLink('', $data))
      <!-- Navigation -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <li class="nav-link py-1">
            <span class="w-20 ml-2">
            <img src="{{ asset('icons/printing_partner.png') }}" class="">
            </span>
            <span class="nav-link-text">Printing Partner</span>
          </li>
        </li>
        <li class="nav-item">
          @if(PC::amLink('Printing Partner - About', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/printpartnerapp/about*')) ? 'active' : '' }}" href="{{ route('ppa.about.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/about.png') }}">
            </span>
            <span class="nav-link-text">About</span>
          </a>
          @endif
          @if(PC::amLink('Printing Partner - Privacy Policy', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/printpartnerapp/privacypolicy*')) ? 'active' : '' }}" href="{{ route('ppa.privacypolicy.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/privacypolicy.png') }}">
            </span>
            <span class="nav-link-text">Privacy Policy</span>
          </a>
          @endif
          @if(PC::amLink('Printing Partner - Terms & Policy', $data))
          <a class="nav-link py-1 {{ (Request::is('admin/printpartnerapp/terms&policy*')) ? 'active' : '' }}" href="{{ route('ppa.terms&policy.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/termandservices.png') }}">
            </span>
            <span class="nav-link-text">Terms & Policy</span>
          </a>
          @endif
          @if(PC::amLink("Printing Partner - FAQ's", $data))
          <a class="nav-link py-1 {{ (Request::is('admin/printpartnerapp/faqs*')) ? 'active' : '' }}" href="{{ route('ppa.faqs.index') }}">
            <span class="w-20">
            <img src="{{ asset('icons/faq.png') }}">
            </span>
            <span class="nav-link-text">FAQ's</span>
          </a>
          @endif
        </li>
      </ul>
      @endif

    </div>
  </div>
</div>
</nav>