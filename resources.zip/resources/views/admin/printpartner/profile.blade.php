@extends('admin.layouts.app')
@section('title','Profile - Print Partner')
@section('content')
<style>
.bg-black{background-color: black;}
#baner-name > *{color: white!important;}
.card-header{color:white!important;}
.card-profile-image img{border:none!important;}
.overlay{z-index: 99}
</style>
@php use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas; @endphp
<section>
	
	<div class="col p-3">
		<div class="card mb-0">
			<div class="card card-profile border-bottom bg-black mb-0 pb-3">
				<div class="card-img-top pt-7"></div>
				<div class="row justify-content-center">
					<div class="col-lg-3 order-lg-2">
						<div class="card-profile-image">
							<a href="#">
								<div class="overlay">
									<img src="{{asset('icons/1.png')}}" class="overicon" alt="badge" style="width: 18px;margin-top:{{isset($printpartner['profile'])?40:20}}px;margin-left: {{isset($printpartner['profile'])?40:20}}px;"> 
								</div>
								<img src="@if(isset($printpartner['profile'])) {{$printpartner['profile']}} @else {{asset('icons/'.ucfirst($printpartner['gender'] ?? 'N/A').'.png')}} @endif" alt="printpartner_icon" width="{{isset($printpartner['profile'])?105:55}}" height="{{isset($printpartner['profile'])?105:55}}" class="rounded-circle">
							</a>
						</div>
					</div>
				</div>
				<div class="card-header text-center border-0 py-4 pb-md-2 bg-transparent">
					<div class="d-flex justify-content-end">
						{{-- <a href="#" class="btn btn-sm btn-info  mr-4 ">Connect</a> --}}
						<button id="edit" class="btn btn-white float-right" data-toggle="button" aria-pressed="false">Edit</button>
					</div>
				</div>
				<div class="card-body pt-0 pb-1">
					<div class="text-center" id="baner-name">
						<h5 class="h3">
							{{($printpartner['first_name'] ?? 'N/A').' '.($printpartner['last_name'] ?? 'N/A')}}
						</h5>
						<div class="h5 font-weight-300">
							<i class="ni location_pin mr-2"></i>Printing partner, {{($printpartner['city'] ?? 'N/A')}}
						</div>
					</div>
				</div>
			</div>
			<div class="card-body p-0">
				<form action="{{ route('p.list.update',$PPKey) }}" method="POST"> @method('PUT') @csrf
					<div class="card-header mb-3">Personal Information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="firstname">First name</label>
									<input type="text" id="firstname" name="firstname" class="form-control" placeholder="First name" value="{{($printpartner['first_name'] ?? 'N/A')}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="lastname">Last name</label>
									<input type="text" id="lastname" name="lastname" class="form-control" placeholder="Last name" value="{{($printpartner['last_name'] ?? 'N/A')}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="gender">Gender</label>
									<select name="gender" id="gender" class="form-control">
										<option {{ucfirst($printpartner['gender'])=='Male'?'selected':''}}>Male</option>
										<option {{ucfirst($printpartner['gender'])=='Female'?'selected':''}}>Female</option>
										<option {{ucfirst($printpartner['gender'])=='Other'?'selected':''}}>Other</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="designation">Designation</label>
									<select name="designation" id="designation" class="form-control">
										<option {{ucfirst($printpartner['designation'])=='Junior Advocate'?'selected':''}}>Junior Advocate</option>
										<option {{ucfirst($printpartner['designation'])=='Senior Advocate'?'selected':''}}>Senior Advocate</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="dob">Date of birth</label>
									<input type="date" id="dob" name="dob" class="form-control" placeholder="dd/mm/yyyy" value="{{date('Y-m-d', strtotime($printpartner['DOB']))}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="state">State</label>
									<input type="text" id="state" name="state" class="form-control" placeholder="City" value="{{$printpartner['state']}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="city">City</label>
									<input type="text" id="city" name="city" class="form-control" placeholder="City" value="{{$printpartner['city']}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="area">Area</label>
									<input type="text" id="area" name="area" class="form-control" placeholder="Area" value="">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="email">Email</label>
									<input type="email" id="email" name="email" class="form-control" placeholder="Email" value="{{$printpartner['email']}}">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="address">Shop address</label>
									<input type="text" id="address" name="address" class="form-control" placeholder="Address" value="{{$printpartner['address']}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="printpartnerId">Printing Partner ID</label>
									<input type="text" id="printpartnerId" name="printpartnerId" class="form-control" placeholder="ID" value="{{$printpartner['Enrollment_Number']}}">
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Professional Information</div>
					<div class="px-3">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="idType">ID type</label>
									<input type="text" id="idType" name="idType" class="form-control" placeholder="Idnetity Type" value="{{$printpartner['idProof_type'] ?? 'N/A'}}">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="idNumber">ID number</label>
									<input type="text" id="idNumber" name="idNumber" class="form-control" placeholder="ID card number" value="">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="idCard">Identity Card</label>
									<div class="col-sm border p-0">
										<img src="{{$printpartner['idProof_image'] ?? 'N/A'}}" alt="No image uploaded" width="100%">
									</div>
								</div>
							</div>
							<div class="col-lg-6 row align-items-end justify-content-end mb-4">
								<button type="submit" name="btn" value="1" class="btn btn-success">Verify</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

	{{-- Inventory management --}}
	<div class="mx-3">
		<div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Service management</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="p-4">
				<div class="d-flex justify-content-between">
					<div class="col-10 col-sm-10">
						<span class="pl-3"><b>Quick Print</b></span>
					</div>
					<div class="col-2 col-sm-2">
						<div class="custom-control custom-switch">
						    <input type="checkbox" class="custom-control-input" id="quick" value="quick" {{$printpartner['type']['quick']=='available'?'checked':''}}>
						    <label class="custom-control-label" for="quick">{{$printpartner['type']['quick']=='available'?'Active':'Not active'}}</label>
						</div>
					</div>
		        </div>
				<div class="d-flex justify-content-between mt-3">
					<div class="col-10 col-sm-10">
						<span class="pl-3"><b>Standard Print</b></span>
					</div>
					<div class="col-2 col-sm-2">
						<div class="custom-control custom-switch">
						    <input type="checkbox" class="custom-control-input" id="standard" value="standard" {{$printpartner['type']['standard']=='available'?'checked':''}}>
						    <label class="custom-control-label" for="standard">{{$printpartner['type']['standard']=='available'?'Active':'Not active'}}</label>
						</div>
					</div>
		        </div>
			</div>
	    </div>
	</div>
	{{-- Inventory management --}}
	<div class="mx-3">
		<div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Inventory management</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Paper color</th>
		                    <th>Paper size</th>
		                    <th>Paper quality</th>
		                    <th>Pricing</th>
		                    <th>Action</th>
	                    </tr>
	                </thead>
	                <tbody>
	                @if($locations<1)
                        <tr>
                            <td colspan="7"><h3>No Areas created yet</h3></td>
                        </tr>
                    @else
                        @foreach($locations as $state => $s) @if(!Clas::isPlace($state)) @php continue; @endphp @endif
                        @foreach($s as $district => $d) @if(!Clas::isPlace($district)) @php continue; @endphp @endif
                        @foreach($d as $city => $c) @if(!Clas::isPlace($city)) @php continue; @endphp @endif
                        @foreach($c as $key => $area) @if(!Clas::isPlace($key)) @php continue; @endphp @endif
                        @if (isset($area['Management']))
                            @foreach ($area['Management'] as $ppKey => $managements)
            	                @if( ($ppKey==$PPKey) && isset($managements['PaperManagement']) )
            	                @foreach($managements['PaperManagement'] as $color => $size)
            	                @foreach($size as $quality => $status)
            	                @foreach($status as $s => $value)
            	                	<tr>
            		                    <td>{{ $color }}</td>
            		                    <td>{{ $quality }}</td>
            		                    <td>{{ $s }}</td>
            		                    <td></td>
            		                    <td><button data-toggle="button" aria-pressed="{{$value=='unavailable'?'true':'false'}}" class="btn btn-sm btn-primary paperAction" value="{{$state.'/'.$district.'/'.$city.'/'.$key.'/Management/'.$PPKey.'/PaperManagement'}}">{{ucfirst($value)}}</button></td>
            	                    </tr>
            	                @endforeach
            	                @endforeach
            	                @endforeach
            	                @endif
                            @endforeach
                        @endif
                        @endforeach
                        @endforeach
                        @endforeach
                        @endforeach
                    @endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	    {{-- Time slot --}}
	    <div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Time slots (Standard Print)</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Days</th>
		                    <th>Date</th>
		                    <th>Timeslot</th>
	                    </tr>
	                </thead>
	                <tbody>
                	@if($locations<1)
                        <tr>
                            <td colspan="3"><h3>No Areas created yet</h3></td>
                        </tr>
                    @else
                        @foreach($locations as $state => $s) @if(!Clas::isPlace($state)) @php continue; @endphp @endif
                        @foreach($s as $district => $d) @if(!Clas::isPlace($district)) @php continue; @endphp @endif
                        @foreach($d as $city => $c) @if(!Clas::isPlace($city)) @php continue; @endphp @endif
                        @foreach($c as $key => $area) @if(!Clas::isPlace($key)) @php continue; @endphp @endif
                        @if (isset($area['Management']))
                            @foreach ($area['Management'] as $ppKey => $managements)
            	                @if( ($ppKey==$PPKey) && isset($managements['TimeManagement']) )
            	                @foreach($managements['TimeManagement'] as $type => $days)
            	                @if ($type=='Standard') <?php $count=1; ?>
            	                @while ($count<8)
		        	                @foreach($days as $day => $slots)
		        	                @if (\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek==$day)
			    	                    <tr>
			    		                    <th id="{{\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek}}" scope="row">{{\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek}}</th>
			    		                    <td name="date{{$count}}"></td>
		        		                    <td>
				            	                @foreach($slots as $time => $value)
			        		                    	<button data-toggle="button" aria-pressed="{{$value=='unavailable'?'true':'false'}}" class="btn btn-sm btn-primary tsStandard" value="{{$state.'/'.$district.'/'.$city.'/'.$key.'/Management/'.$PPKey.'/TimeManagement/Standard'}}">{{$time}}</button>
				            	                @endforeach <?php $count=$count+1; ?>
		        		                    </td>
			    	                    </tr>
		        	                @endif
		        	                @endforeach
            	                @endwhile
            	                @endif
            	                @endforeach
            	                @endif
                            @endforeach
                        @endif
                        @endforeach
                        @endforeach
                        @endforeach
                        @endforeach
                    @endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	    {{-- Time slot --}}
	    <div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Timings (Quick Print)</h3>
					</div>
				</div>
			</div>
			<!-- Projects table -->
			<div class="table-responsive">
				<table class="table align-items-center table-flush text-center">
					<thead class="thead-light">
	                    <tr>
		                    <th>Days</th>
		                    <th>Date</th>
		                    <th>Timeslot</th>
	                    </tr>
	                </thead>
	                <tbody>
	                @if($locations<1)
                        <tr>
                            <td colspan="3"><h3>No Areas created yet</h3></td>
                        </tr>
                    @else
                        @foreach($locations as $state => $s) @if(!Clas::isPlace($state)) @php continue; @endphp @endif
                        @foreach($s as $district => $d) @if(!Clas::isPlace($district)) @php continue; @endphp @endif
                        @foreach($d as $city => $c) @if(!Clas::isPlace($city)) @php continue; @endphp @endif
                        @foreach($c as $key => $area) @if(!Clas::isPlace($key)) @php continue; @endphp @endif
                        @if (isset($area['Management']))
                            @foreach ($area['Management'] as $ppKey => $managements)
            	                @if( ($ppKey==$PPKey) && isset($managements['TimeManagement']) )
            	                @foreach($managements['TimeManagement'] as $type => $days)
            	                @if ($type=='Quick') <?php $count=1; ?>
            	                @while ($count<8)
		        	                @foreach($days as $day => $slots)
		        	                @if (\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek==$day)
	                                    <tr>
	                	                    <th id="{{\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek}}" scope="row">{{\Carbon\Carbon::now()->addDays($count)->englishDayOfWeek}}</th>
	                	                    <td name="date{{$count}}"></td>
	                                    	<td>
	                                    		<div class="row">
	                                    			<div class="col-lg-6">
	                                    				<div class="form-group m-0">
	                                    					<label class="form-control-label" for="input-first-name">From</label>
	                                    					<div class="d-flex">
	                                    						<input type="number" name="fromHour" id="fromHour" class="form-control" step="01" min="01" max="12" value="{{ explode(':',$slots['from'])[0] }}" oninput="format(this)">
	                                    						<input type="number" name="fromMinute" id="fromMinute" class="form-control" step="01" min="00" max="59" value="{{ explode(' ',explode(':',$slots['from'])[1])[0] }}" oninput="format(this)">
	                                    						<select class="custom-select" name="fromTime" id="fromTime" style="width:34%">
	                                    							<option {{ explode(' ',explode(':',$slots['from'])[1])[1]=='AM' ? 'selected':'' }}>AM</option>
	                                    							<option {{ explode(' ',explode(':',$slots['from'])[1])[1]=='PM' ? 'selected':'' }}>PM</option>
	                                    						</select>
	                                    					</div>
	                                    				</div>
	                                    			</div>
	                                    			<div class="col-lg-6">
	                                    				<div class="form-group m-0">
	                                    					<label class="form-control-label" for="input-first-name">To</label>
	                                    					<div class="d-flex">
	                                    						<input type="number" name="toHour" id="toHour" class="form-control" step="01" min="01" max="12" value="{{ explode(':',$slots['to'])[0] }}" oninput="format(this)">
	                                    						<input type="number" name="toMinute" id="toMinute" class="form-control" step="01" min="{{ explode(' ',explode(':',$slots['to'])[1])[0] }}" max="59" value="00" oninput="format(this)">
	                                    						<select class="custom-select" name="toTime" id="toTime" style="width:34%">
	                                    							<option {{ explode(' ',explode(':',$slots['to'])[1])[1]=='AM' ? 'selected':'' }}>AM</option>
	                                    							<option {{ explode(' ',explode(':',$slots['to'])[1])[1]=='PM' ? 'selected':'' }}>PM</option>
	                                    						</select>
	                                    					</div>
	                                    				</div>
	                                    			</div>
	                                    		</div>
	                                    	</td>
	                                    </tr>
	                                    <?php $count=$count+1; ?>
		        	                @endif
		        	                @endforeach
            	                @endwhile
            	                @endif
            	                @endforeach
            	                @endif
                            @endforeach
                        @endif
                        @endforeach
                        @endforeach
                        @endforeach
                        @endforeach
                    @endif
	                </tbody>
	            </table>
	        </div>
	    </div>
	    {{-- Passbook --}}
	    <div class="card mb-3">
			<div class="card-header border-0 p-3">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0 mx-1">Passbook</h3>
					</div>
					<div class="col text-right">
						<button class="btn btn-primary btn-sm">Filter</button>
					</div>
				</div>
			</div>
			<div class="px-2 pb-2 pt-0">
			{{-- @if(isset($printpartner['passbook']))
			@foreach($printpartner['passbook'] as $transact) --}}
				<div class="mt-2 pass-border-$transact['status']=='Successful' ? 'success' : 'fail'}}">{{-- single transaction --}}
					<div class="table-responsive">
						<div class="alert alert-$transact['status']=='Successful' ? 'success' : 'danger'}} d-flex">
							<div class="pr-5">
								<h5>Package type</h5>
								<h4> $transact['subscription'] }}</h4>
							</div>
							<div class="pr-5">
								<h5>Transaction ID</h5>
								<h4> $transact['transactionId'] }}</h4>
							</div>
							<div class="pr-5">
								<h5>Date</h5>
								<h4> $transact['date'] }}</h4>
							</div>
							<div class="pr-5">
								<h5>Time</h5>
								<h4> $transact['time'] }}</h4>
							</div>
							<div class="pr-5">
								<h5>Status</h5>
								<h4> $transact['status'] }}</h4>
							</div>
				        </div>
				        <div class="alert d-flex mx-2 mb-0">
				        	<div class=" d-flex">
								<div class="pr-5">
									<h5>User number</h5>
									<h4> $transact['number'] }}</h4>
								</div>
								<div class="pr-5">
									<h5>Pack</h5>
									<h4> $transact['pack'] }}</h4>
								</div>
								<div class="pr-5">
									<h5>Total price</h5>
									<h4> $transact['totalPrice'] }}</h4>
								</div>
				        	</div>
				        	<div class=" d-flex">
								<div class="pr-5">
									<h5>Amount paid</h5>
									<h4> $transact['amountPaid'] }}</h4>
								</div>
				        	</div>
				        </div>
					</div>
				</div>
			{{-- @endforeach
			@endif --}}
			</div>
	    </div>
	</div>
	
</section>
@section('jquery')
<script>
	$(document).ready(function() {
		
		var today = new Date();
		var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
		var nextDay = new Date(today);
		week(nextDay,today,days);

		function week(nextDay,day) {
			for(i=1;i<=7;i++){
				nextDay.setDate(today.getDate()+i);

				if(today.getDay()+i > 7)
					var day = days[ (today.getDay()+i-1)%7 ];
				else
					var day = days[ (today.getDay()+i-1) ];
				// $('[name=day'+i+']').html(day);

				var d=today.getDate()+i-1;
				var m=today.getMonth()+1;
				var y=today.getFullYear();

				$('[name=date'+i+']').html(d+'/'+m+'/'+y);
			}
		}
	});

	function format(input){
	    if (input.value.length > 2) input.value = input.value.slice(0, 2)
	    $(input).blur(function() {
	       if(input.value.length == 1) input.value=0+input.value;
	       if(input.value.length == 0) input.value='01';
	    });
	}

	$('input[type=checkbox]').change(function() {
        if(this.checked) {
        	$(this).attr('checked','checked');
        	$(this).siblings().text('Active');
		    sendService($(this).val(),'available');
        }
        else {
            $(this).removeAttr('checked');
        	$(this).siblings().text('Not active');
		    sendService($(this).val(),'unavailable');
        }
    });
    function sendService(key,value) {
    	$.ajax({
            method:"GET",
            url: "{{ route('p.list.index') }}/"+value+"/edit",
            data: {
                'serviceRef': '{{$PPKey}}',
                'key':    key,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
            }
        });
    }

	$('.tsStandard*').click(function(e) { var path='/';
		if(this.getAttribute('aria-pressed')=='false'){
			path += $(this).parent().siblings().eq(0).text()+'/';
			sendtsStandard($(this).val()+path,$(this).text(),'unavailable');
		}
		else{
			path += $(this).parent().siblings().eq(0).text()+'/';
			sendtsStandard($(this).val()+path,$(this).text(),'available');
		}
	});
	function sendtsStandard(ref,key,value) {
		$.ajax({
            method:"GET",
            url: "{{ route('p.list.index') }}/"+value+"/edit",
            data: {
                'tsStandardRef':    ref,
                'key':    key,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
            }
        });
	}

	$('.paperAction*').click(function(e) { var path='/';
		if(this.getAttribute('aria-pressed')=='false'){
			$(this).text('Unavailable');
			for (var i = 0; i < 2; i++)
				path += $(this).parent().siblings().eq(i).text()+'/';
			sendPaper($(this).val()+path,$(this).parent().siblings().eq(2).text(),'unavailable');
		}
		else{
			$(this).text('Available');
			for (var i = 0; i < 2; i++)
				path += $(this).parent().siblings().eq(i).text()+'/';
			sendPaper($(this).val()+path,$(this).parent().siblings().eq(2).text(),'available');
		}
	});
	function sendPaper(ref,key,value) {
		$.ajax({
            method:"GET",
            url: "{{ route('p.list.index') }}/"+value+"/edit",
            data: {
                'papersRef':    ref,
                'key':    key,
                '_token':   '{{csrf_field()}}',
                '_method':  '{{method_field('PUT')}}',
            },
            dataType:'JSON',
            success:function(data){
            }
        });
	}

	$('form *').attr('disabled','disabled');
	$('#edit').click(function(argument) {
		switch ($(this).attr("aria-pressed")) {
			case 'false':
				$('form *').removeAttr('disabled');
				break;
			case 'true':
				$('form *').attr('disabled','disabled');
				break;
		}
	});
	$('#edit').click(function(argument) {
		switch ($(this).attr("aria-pressed")) {
			case 'false':
				$('form *').removeAttr('disabled');
				break;
			case 'true':
				$('form *').attr('disabled','disabled');
				break;
		}
	});
</script>
@endsection
@endsection