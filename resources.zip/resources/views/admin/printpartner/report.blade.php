@extends('admin.layouts.app')
@section('title','Reports - Printing Partner')
@section('content')
<style>.card-header{color: white;}</style>
<section>
	
	<div class="col p-3">
		<div class="card">
			<div class="card-body p-0">
				<form action="{{ route('p.list.store') }}" method="POST"> @csrf @method('POST')
					<div class="card-header mb-3">Range</div>
					<div class="px-4">
						<h6 class="heading-small mb-0">Print Partner ID</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromPPId">From</label>
									<input type="text" id="fromPPId" name="fromPPId" class="form-control" placeholder="123456">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toUserId">To</label>
									<input type="text" id="toPPId" name="toUserId" class="form-control" placeholder="123456">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Date of birth</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromDob">From</label>
									<input type="date" id="fromDob" name="fromDob" class="form-control" placeholder="dd/mm/yyyy">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toDob">To</label>
									<input type="date" id="toDob" name="toDob" class="form-control" placeholder="dd/mm/yyyy">
								</div>
							</div>
						</div>
						<h6 class="heading-small mb-0">Credits</h6>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="fromCredits">From</label>
									<input type="number" min="0" id="fromCredits" name="fromCredits" class="form-control" placeholder="2">
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="toCredits">To</label>
									<input type="number" min="0" id="toCredits" name="toCredits" class="form-control" placeholder="12">
								</div>
							</div>
						</div>
					</div>
					<!-- Professional -->
					<div class="card-header mb-3">Filter</div>
					<div class="px-4">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="area">Area</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" name="area" id="area">
										<option>Bani Park</option>
										<option>Mansarowar</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="gender">Gender</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="2" tabindex="-1" aria-hidden="true" name="gender" id="gender">
										<option>Male</option>
										<option>Female</option>
										<option>Other</option>
									</select>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label class="form-control-label" for="city">City</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="3" tabindex="-1" aria-hidden="true" name="city" id="city">
										<option>Jaipur</option>
										<option>Mumbai</option>
										<option>Pune</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="paperSize">Paper size</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="4" tabindex="-1" aria-hidden="true" name="paperSize" id="paperSize">
										<option>A4 Paper</option>
										<option>A3 Paper</option>
										<option>Letter pad</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="paperColor">Paper color</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="5" tabindex="-1" aria-hidden="true" name="paperColor" id="paperColor">
										<option>White Paper</option>
										<option>Green Paper</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="paperQuality">Paper quality</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="6" tabindex="-1" aria-hidden="true" name="paperQuality" id="paperQuality">
										<option>60 GSM</option>
										<option>70 GSM</option>
										<option>80 GSM</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label class="form-control-label" for="timeslot">Timeslot</label>
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="7" tabindex="-1" aria-hidden="true" name="timeslot" id="timeslot">
										<option>10:00 to 10:30</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<!-- Data points -->
					<div class="card-header mb-3">Data points</div>
					<div class="px-4">
						<div class="row">
							<div class="col-md">
								<div class="form-group">
									<select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true" name="dataPoints" id="dataPoints">
										<option>Name</option>
										<option>Email ID</option>
										<option>Shop Address</option>
										<option>Days</option>
										<option>Date</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="p-3 d-flex justify-content-end">
						<button type="submit" name="exportBtn" value="json" class="btn btn-dark">Export JSON</button>
						<button type="submit" name="exportBtn" value="pdf" class="btn btn-dark">Export PDF</button>
						<button type="submit" name="exportBtn" value="excel" class="btn btn-dark">Export EXCEL</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
</section>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
</script>
@endsection

@endsection