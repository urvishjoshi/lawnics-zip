@extends('admin.layouts.app')
@section('title','Print Partners')
@section('content')
@php use \App\Http\Controllers\Admin\LocationPermiController as LPClas; $data = LPClas::data(); @endphp
<section>
    <div class="col p-3">
        <div class="card mb-3">
            <div class="card-header border-0 p-3">
                <div class="row align-items-center">
                    <div class="col">
                        
                    </div>
                    <div class="col-6">
                    </div>
                    <div class="col align-self-end">
                      <div class="input-group input-group-sm">
                        <input class="form-control form-control-navbar" id="search" placeholder="Search" aria-label="Search">
                        <div class="input-group-append">
                          <button class="btn btn-sm border" type="submit">
                            <i class="fas fa-search"></i>
                          </button>
                        </div>
                      </div>
                      <div class="d-flex">
                        <a href="{{ route('p.list.show','reports') }}" class="btn btn-block btn-sm btn-primary mt-2">Reports</a>
                        <button class="btn btn-block btn-sm btn-primary"  data-toggle="modal" data-target="#exampleModal">Filter</button>
                    </div>
                </div>
            </div>
            </div>
            <!-- Projects table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush text-center">
                    <thead class="thead-light">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Mobile No.</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if($printpartners<1)
                        <tr>
                            <td colspan="8"><h3>No Users registered yet</h3></td>
                        </tr>
                    @else  @php $flag=true; @endphp
                        @foreach($printpartners as $key => $value)
                            @if(LPClas::userStatePermi($value['state'] ?? 'N/A', $data) || LPClas::userCityPermi($value['city'] ?? 'N/A', $data)) @php $flag=false; @endphp
                            <tr>
                                <th>{{$value['Enrollment_Number'] ?? 'N/A'}}</th>
                                <th><a href="{{ route('p.list.show','profile?id='.$key) }}" class="d-flex">
                                        <div class="overlay">
                                            <img src="{{asset('icons/'.($value['status'] ?? 'N/A') .'.png')}}" class="overicon" alt="badge"> 
                                        </div>
                                        <img src="{{asset('icons/'.(ucfirst($value['gender']) ?? 'N/A') .'.png')}}" width="32" alt="user_icon" class="mr-1">
                                        <span class="my-auto mx-auto">{{ ($value['first_name'] ?? 'N/A').' '.($value['last_name'] ?? 'N/A') }}
                                        </span>
                                    </a>
                                </th>
                                <td>{{$phone[$key]?? 'N/A'}}</td>
                                <td>{{$value['state']?? 'N/A'}}</td>
                                <td>{{$value['city']?? 'N/A'}}</td>
                                <td><button data-toggle="button" aria-pressed="true" class="btn btn-sm btn-success"><i class="fas fa-ban"></i> Block</button></td>
                            </tr>
                            @endif
                        @endforeach
                        @if ($flag)
                            <tr>
                                <td colspan="8"><h3>No Users registered yet or You have don't have any preveliege</h3></td>
                            </tr>
                        @endif
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div class="table-responsive">
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="title m-0" id="exampleModalLabel">Filter</h2>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Status</label>
                        <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="11" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                            <option>Successful</option>
                            <option>Pending</option>
                            <option>Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label>Pack</label>
                        <select class="select2 select2-hidden-accessible" multiple="" data-placeholder="Select a State" style="width: 100%;" data-select2-id="12" tabindex="-1" aria-hidden="true" name="designation" id="designation">
                            <option>Basic</option>
                            <option>Popular</option>
                            <option>Special</option>
                        </select>
                    </div>
                </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-dark" data-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-dark">Apply</button>
          </div>
        </div>
      </div>
    </div>
</div>

@section('jquery')
<script>
    $(document).ready(function() {
        $('.select2').select2();
        $('.select2').on('change',function(){
            var values = $(this).val();
            console.log(values)
        });
    });
    $('button[data-toggle="button"]').click(function(e) {
        if(this.getAttribute('aria-pressed')=='true')
            $(this).html('<i class="far fa-check-circle"></i> Unblock');
        else
            $(this).html('<i class="fas fa-ban"></i> Block');
    });
</script>
@endsection

@endsection
