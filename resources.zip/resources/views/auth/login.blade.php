<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Lawnics Admin Login page">
        <meta name="author" content="Urvish Joshi">
        <title>Login | Lawnics</title>
        <!-- Favicon -->
        <link rel="icon" href="{{ asset('Lawnics.png') }}" type="image/png">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
        <!-- Icons -->
        {{-- <link rel="stylesheet" href="{{ asset('assets/vendor/nucleo/css/nucleo.css') }}" type="text/css"> --}}
        <link rel="stylesheet" href="{{ asset('assets/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
        <!-- Argon CSS -->
        {{-- <link rel="stylesheet" href="{{ asset('assets/css/argon.css') }}" type="text/css"> --}}
        @include('admin.layouts.head')
        <style>
            .btn{color: white; background-color: black;}
            body{background-color: white!important;min-height: initial!important;}
            .card{box-shadow: none!important;}
        </style>
    </head>

    <body>
        <!-- Main content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header mt-5">
                <div class="container">
                    <div class="header-body text-center">
                        <img src="{{ asset('Lawnics.png') }}" width="15%">
                    </div>
                </div>
            </div>
            <!-- Page content -->
            <div class="container mt-4">
                <div class="row justify-content-center">
                    <div class="col-lg-5 col-md-7">
                        <div class="card bg-transparent border-0 mb-0">
                            <div class="card-body px-lg-5 pt-lg-3 py-sm-5">
                                <form action="{{ route('doLogin') }}" method="POST" role="form" >
                                    @method('POST') {{ csrf_field() }}
                                    <div class="form-group mb-3">
                                        <label class="form-control-label m-0" for="password">Username</label>
                                        <input class="form-control @error('email') is-invalid @enderror" name="email" placeholder="username@lawnics.com" type="email" value="{{old('email')}}">
                                        @error('email')
                                        <span class="invalid-feedback pl-1" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="form-control-label m-0" for="password">Password</label>
                                        <input class="form-control @error('password') is-invalid @enderror" name="password" placeholder="Password" id="password" type="password">
                                        @error('password')
                                        <span class="invalid-feedback pl-1" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary mt-3">Log in</button>
                                    </div>
                                </form>
                            </div>
                            <div class="row flex-column">
                                <div class="col-lg-auto col-sm-auto text-center">
                                    <a href="#"><small>Forgot my password</small></a>
                                </div>
                                <div class="col-lg-auto col-sm-auto text-center mt-2">
                                    <small>Don't have an account? <a href="#" class="text-primary link">Sign Up</a></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Argon Scripts -->
        <!-- Core -->
        <script src="{{ asset('assets/vendor/jquery/dist/jquery.min.js') }}"></script>
        <script src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('assets/vendor/js-cookie/js.cookie.js') }}"></script>
        <script src="{{ asset('assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js') }}"></script>
        <script src="{{ asset('assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js') }}"></script>
        <!-- Argon JS -->
        <script src="{{ asset('assets/js/argon.js?v=1.2.0') }}"></script>
    </body>

</html>