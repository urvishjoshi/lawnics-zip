<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Export data in {{$exportType}}</title>
	@include('admin.layouts.head')
</head>
<body class="bg-transparent">
	<div class="container">
		<div class="row my-3 w-100">
			
		<div class="col-2 text-left">
			
			<a href="{{ url()->previous() }}" class="fas fa-arrow-left" style="font-size: 30px!important;text-decoration:none; "></a>
		</div>
		<div class="col d-flex justify-content-center">
			
			<button align="center" id="{{$exportType}}" class="btn btn-success mx-auto ">Export to {{$exportType}}</button>
		</div>
		<div class="col-2">
		</div>
		</div>
		<table id="exportTable" class="table table-striped table-bordered text-center">
			<thead>
				<tr>
					@for($i=0 ; $i<count($heads) ; $i++)
					<th>{{ $heads[$i] }}</th>
					@endfor
				</tr>
			</thead>
			<tbody>
				@if($Users=='')
					<tr>
						<td colspan="7">No records found</td>
					</tr>
				@else
					@foreach($Users as $key => $user)
					<tr>
						<td>{{ $user['Enrollment_Number']??'N/A' }}&nbsp;</td>
						<td>{{ ($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A') }}</td>
						<td>{{ $user['email']??'N/A' }}</td>
						<td>{{ $phone[$key]??'N/A' }}&nbsp;</td>
						<td>{{ $user['category']??'N/A' }}</td>
						<td>{{ $user['designation']??'N/A' }}</td>
						<td>{{ $user['gender']??'N/A' }}</td>
					</tr>
					@endforeach
				@endif
			</tbody>
		</table>
	</div>
	<script src="{{ asset('/assets/vendor/jquery/dist/jquery.min.js') }}"></script>
	{{-- excel --}}
	<script src="{{ asset('/assets/js/jquery.table2excel.js') }}"></script>
	{{-- pdf --}}
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
	<script src="{{ asset('/assets/js/autotable.js') }}"></script>
	<script src="{{ asset('/assets/js/tableHTMLExport.js') }}"></script>
	
	<script>
		$(function() {
			$("#Excel").click(function(e){
				var table = $('#exportTable');  //table tag id
				if(table && table.length){
					$(table).table2excel({
						name: "Users reports",
						filename: "Reports.xls",
						fileext: ".xls",
						exclude_img: true,
						exclude_links: true,
						exclude_inputs: true,
					});
				}
			});
			
			$('#Pdf').on('click',function(){
				$("#exportTable").tableHTMLExport({type:'pdf',orientation:'l',filename:'Reports.pdf'});
			});
		});
	</script>
</body>
</html>