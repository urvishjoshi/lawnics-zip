<?php

use Illuminate\Support\Facades\Route;
Route::resource('/', 'Admin\Root\RootController');
Route::get('/blog', 'Admin\Root\RootController@blog');
Route::get('/blog/{id}', 'Admin\Root\RootController@blogShow');
Route::get('admin',  function () { return redirect('admin/login'); });
// Route::get('register', function () { return view('auth.register'); });

Route::resource('allLocations', 'Admin\AllLocationsController');

Route::group(['prefix'=>'admin','namespace'=>'Admin'], function(){
	Route::get('login',   'AuthController@showLoginForm')->name('login');
	Route::post('login',  'AuthController@login')->name('doLogin');
	Route::post('logout', 'AuthController@logout');

	Route::group(['middleware'=>'role'], function(){
		Route::resource('dashboard', 'DashboardController');
		
		Route::group(['prefix'=>'users','namespace'=>'User','as'=>'u.'], function(){
			Route::resource('list',     'ListController');
			Route::resource('segments', 'SegmentController');
		});
		Route::group(['prefix'=>'printpartners','namespace'=>'PrintPartner','as'=>'p.'], function(){
			Route::resource('list',  'ListController');
		});
		Route::group(['prefix'=>'operations','namespace'=>'Operation','as'=>'o.'], function(){
			Route::resource('areas',    'AreaController');
			Route::resource('subadmin', 'SubAdminController');
			Route::resource('orders',   'OrderController');
		});
		Route::group(['prefix'=>'sp','namespace'=>'ServiceProduct','as'=>'sp.'], function(){
			Route::resource('services',  'ServiceController');
			Route::resource('timeslots', 'TimeslotController');
			Route::resource('papers',    'PaperSnQController');
		});
		Route::group(['prefix'=>'sales','namespace'=>'Sales','as'=>'s.'], function(){
			Route::resource('credits',   'CreditController');
			Route::resource('packages',  'PackageController');
		});
		Route::group(['prefix'=>'transactions','namespace'=>'Transaction','as'=>'t.'], function(){
			Route::resource('users',            'UserController');
			Route::resource('deliverypartners', 'DeliveryPartnerController');
			Route::resource('printpartners',    'PrintPartnerController');
		});
		Route::group(['prefix'=>'advocateapp','namespace'=>'AdvocateApp','as'=>'aa.'], function(){
			Route::resource('about',         'AboutController');
			Route::resource('privacypolicy', 'PrivacyPolicyController');
			Route::resource('terms&policy',  'TermsAndPolicyController');
			Route::resource('faqs', 'FaqController');
		});
		Route::group(['prefix'=>'printpartnerapp','namespace'=>'PrintPartnerApp','as'=>'ppa.'], function(){
			Route::resource('about',         'AboutController');
			Route::resource('privacypolicy', 'PrivacyPolicyController');
			Route::resource('terms&policy',  'TermsAndPolicyController');
			Route::resource('faqs', 'FaqController');
		});
	});
});
