<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model\Admin;
// use Faker\Generator as Faker;

$factory->define(Admin::class, function () {
    return [
        'name' => 'Urvish Joshi',
        'email' => 'a@b.c',
        'password' => '$2y$10$mZR9Jo7H9mEqCP1Jq8OJlu8k.3nQa3LT8I545Kda5Qp43rGYEtrZC', // password
    ];
});
