<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Support\Facades\Auth;
use Session;

class RedirectIfAuthenticated
{
    public function handle($request, Closure $next, $guard = null)
    {
        // if ($guard == "admin" && Auth::guard($guard)->check()) {
            // return redirect('admin/dashboard/1');
        // }
        
        // if (Auth::guard($guard)->check()) {
        //     return redirect(RouteServiceProvider::HOME);
        // }
        if (Session::has('admin_session')) {
            return redirect('admin/dashboard/1');
        }
        return $next($request);
    }
}
