<?php

namespace App\Http\Controllers\Admin\PrintPartner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use DateTime;

class ListController extends Controller
{
    private $url = 'admin.printpartner.';
    private $firebase;

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
        $this->pp = $this->database->getReference('Printing_partner')->getValue();
    }

    public function index()
    {
        $ref = 'Printing_partner';
        $printpartners = $this->database->getReference($ref)->getValue();
        $phone = $this->getPhoneNumbers();
        return view('admin.printpartner.dashboard',compact('printpartners','phone'));
    }

    public function show($id)
    {
        $ref = 'Printing_partner';
        switch ($id) {
            case 'profile':
                $PPKey = request()->input('id');
                if(empty($PPKey)) return view('404');
                $printpartner = $this->database->getReference($ref)->getChild($PPKey)->getValue();
                $locations = $this->database->getReference('Locations/')->getValue();
                if(!$printpartner) return view('404');
                return view($this->url.'profile',compact('printpartner','PPKey','locations')); break;

            case 'reports':
                return view($this->url.'report'); break;

            default: return view('404');
        }
    }

    public function store(Request $request)
    {
        // return$request;
        foreach($this->pp as $key => $pp) {
            if( ($this->ppId($request,$pp)) && ($this->gender($request->gender??'',$pp)) && ($this->dob($request,$pp)) && ($this->category($request->category??'',$pp)) && ($this->designation($request,$pp)) ) {
                $Users[$key] = $pp;
            }
        }
        if (empty($Users)) $Users='';

        $exportType = ucfirst($request->exportBtn);
        switch ($request->exportBtn) {
            case 'json':
                header('Content-disposition: attachment; filename=Reports.json');
                header('Content-type: application/json'); echo json_encode($Users);
                return back();
                
            case 'pdf':
                $heads = ['Enrollment Number','Name','Email','Contact Number','Designation','Gender'];
                $bodys = ['Enrollment_Number','Name','email','Contact Number','designation','gender'];
                $phone = $this->getPhoneNumbers();
                return view('exportDynamic',compact('exportType','heads','Users','phone','bodys'));

            case 'excel':
                $heads = ['Enrollment Number','Name','Email','Contact Number','Designation','Gender'];
                $phone = $this->getPhoneNumbers();
                return view('exportDynamic',compact('exportType','heads','Users','phone'));
                break;

            default: return view('404');
        }
    }

    public function update(Request $r, $id)
    {
        // return$r;
        $data = [
            'firstname' => $r->first_name,
            'lastname' => $r->last_name,
            'Enrollment_Number' => $r->printpartnerId,
            'gender' => $r->gender,
            'designation' => $r->designation,
            'DOB' => $r->dob,
            'state' => $r->state,
            'city' => $r->city,
            'area' => $r->area,
            'address' => $r->address,
            'email' => $r->email,
            'idProof_type' => $r->idType,
        ];

        $user = $this->database->getReference('Printing_partner/'.$id)->update($data);
        return redirect('admin/printpartners/list')->with(['a.toast'=>'Printing partner updated successfully', 'time'=>3500]);
    }

    public function edit($value)
    {
        if (request('papersRef')) {
            $query = $this->database->getReference('Locations/'.request('papersRef'))->getValue();
            if ($query) {
                $this->database->getReference('Locations/'.request('papersRef'))->update([request('key')=>$value]);
                return 'successful';
            }
            return null;
        }
        if (request('tsStandardRef')) {
            $query = $this->database->getReference('Locations/'.request('tsStandardRef'))->getValue();
            if ($query) {
                $this->database->getReference('Locations/'.request('tsStandardRef'))->update([request('key')=>$value]);
                return 'successful';
            }
            return null;
        }
        if (request('serviceRef')) {
            $query = $this->database->getReference('Printing_partner/'.request('serviceRef').'/type')->getValue();
            if ($query) {
                $this->database->getReference('Printing_partner/'.request('serviceRef').'/type')->update([request('key')=>$value]);
                return 'successful';
            }
            return null;
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getPhoneNumbers()
    {
        $auth = $this->firebase->getAuth();
        $users=$auth->listUsers();
        foreach ($users as $user => $value) {
            $phone[$value->uid]=$value->phoneNumber;
        }
        return $phone;
    }

    public function ppId($r,$pp)
    {   
        if(empty($r->fromPPId && $r->toPPId)) return true;

        if(($pp['Enrollment_Number']??'')>=$r->fromPPId && ($pp['Enrollment_Number']??'')<=$r->toPPId) {
            return true;
        }
        return false;
    }

    public function gender($gender,$pp)
    {
        if(empty($gender)) return true;

        if(isset($pp['gender'])) {
            if( (ucfirst($pp['gender'])==($gender[0]??'')) || (ucfirst($pp['gender'])==($gender[1]??'')) || (ucfirst($pp['gender'])==($gender[2]??'')) )
                return true;
        }
        return false;
    }

    public function dob($r,$pp)
    {
        if(empty($r->fromDob && $r->toDob)) return true;

        if (isset($pp['DOB'])) {
            $from = new DateTime( date("d-m-Y", strtotime($r->fromDob)) );
            $to = new DateTime( date("d-m-Y", strtotime($r->toDob)) );
            $dob = new DateTime( str_replace('/','-',$pp['DOB']) );

            if( $from <= $dob && $dob <= $to) return true;
        }
        return false;
    }

    public function credits($r,$pp)
    {
        if(empty($r->fromCredits && $r->toCredits)) return true;

        if (isset($pp['DOB'])) {
            $from = new DateTime( date("d-m-Y", strtotime($r->fromDob)) );
            $to = new DateTime( date("d-m-Y", strtotime($r->toDob)) );
            $dob = new DateTime( str_replace('/','-',$pp['DOB']) );

            if( $from <= $dob && $dob <= $to) return true;
        }
        return false;
    }

    public function category($category,$user)
    {
        if(empty($category)) return true;

        if(isset($user['category'])) {
            if($category[0]=='Non lawyer') {
                if (ucfirst($user['category'])!='Lawyer')
                    return true;
            }
            elseif( isset($category[0]) && empty($category[1]) ) {
                if( ucfirst($user['category'])=='Lawyer' )
                    return true;
            }
            else {
                if( (ucfirst($user['category'])==($category[0]??'')) || (ucfirst($user['category'])!=($category[1]??'')) )
                    return true;
            }
        }
        return false;
    }

    public function designation($request,$user)
    {
        $des = $request->designation;
        if (empty($des)) return true;
        
        if (isset($user['designation'])) {
            $udesg = strtolower($user['designation']);
            if ( $udesg==($des[0]??'') || $udesg==($des[1]??'') )
                return true;
        }
        return false;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
