<?php

namespace App\Http\Controllers\Admin\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;

class SegmentController extends Controller
{
    private $url = 'admin.user.segments.';

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $firebase->getDatabase();
    }

    public function index()
    {
        $segments = $this->database->getReference('Segmentations/')->getValue();
        return view($this->url.'dashboard',compact('segments'));
    }

    public function show($segment)
    {
        if(empty($id = request('id')) || empty($segment)) return view('404');
        switch ($segment) {
            case 'lawyers':
                $lawyers = $this->database->getReference('Segmentations/Lawyers/'.$id)->getValue();
                if(!$lawyers) return view('404');
                return view($this->url.'lawyers',compact('lawyers','id')); break;
            case 'nonlawyers':
                $nonlawyers = $this->database->getReference('Segmentations/NonLawyers/'.$id)->getValue();
                if(!$nonlawyers) return view('404');
                return view($this->url.'nonlawyers',compact('nonlawyers','id')); break;

            default : return view('404');
        }
    }
    public function store(Request $r)
    {
        // return$r;
        switch ($r->category) {
            case 'lawyers':
                if ($r->designation) {
                    $data = $this->setDesg($r);
                    if ($r->key) {
                        $query = $this->database->getReference('Segmentations/Lawyers/'.$r->key)->update($data);
                        return redirect('admin/users/segments/')->with(['a.toast'=>'Designation edited successfully', 'time'=>3500]);
                    }
                    else {
                        $query = $this->database->getReference('Segmentations/Lawyers/')->push($data);
                        return redirect('admin/users/segments/')->with(['a.toast'=>'Designation created successfully', 'time'=>3500]);
                    }
                }
                else {
                    $data = $this->setData($r);
                    if ($r->key) {
                        $query = $this->database->getReference('Segmentations/Lawyers/'.$r->desg.'/Peoples/'.$r->key)->update($data);
                        return redirect('admin/users/segments/'.$r->category.'?id='.$r->desg)->with(['a.toast'=>'People edited successfully', 'time'=>3500]);
                    }
                    else
                        $query = $this->database->getReference('Segmentations/Lawyers/'.$r->desg.'/Peoples/')->push($data);
                }
                break;
            
            case 'nonlawyers':
                if ($r->designation) {
                    $data = $this->setDesg($r);
                    if ($r->key) {
                        $query = $this->database->getReference('Segmentations/NonLawyers/')->update([$r->designation=>$data]);
                        return redirect('admin/users/segments/')->with(['a.toast'=>'Designation edited successfully', 'time'=>3500]);
                    }
                    else {
                        $query = $this->database->getReference('Segmentations/NonLawyers/')->push($data);
                        return redirect('admin/users/segments/')->with(['a.toast'=>'Designation created successfully', 'time'=>3500]);
                    }
                }
                else {
                    $data = $this->setData($r);
                    if ($r->key) {
                        $query = $this->database->getReference('Segmentations/NonLawyers/'.$r->desg.'/Peoples/'.$r->key)->update($data);
                        return redirect('admin/users/segments/'.$r->category.'?id='.$r->desg)->with(['a.toast'=>'People edited successfully', 'time'=>3500]);
                    }
                    else
                        $query = $this->database->getReference('Segmentations/NonLawyers/'.$r->desg.'/Peoples/')->push($data);
                }
                break;
        }
        return redirect('admin/users/segments/'.$r->category.'?id='.$r->desg)->with(['a.toast'=>'People created successfully', 'time'=>3500]);

    }

    
    public function edit($segment)
    {
        if(request('key'))
            return $this->database->getReference('Segmentations/'.$segment.'/'.request('id').'/Peoples/'.request('key'))->getValue();
        else
            return $this->database->getReference('Segmentations/'.$segment.'/'.request('id'))->getValue();
    }

    public function setData($r)
    {
        return $data = [
            'imageName' => $r->imageName,
            'image' => $r->imagePath,
            'toAge' => (int)$r->toAge,
            'fromAge' => (int)$r->fromAge,
            'gender' => $r->gender,
        ];
    }
    public function setDesg($r)
    {
        return $data = [
            'designation' => $r->designation,
            'imageName' => $r->imageName,
            'image' => $r->imagePath,
        ];
    }

    public function destroy($id)
    {
        switch (request('category')) {
            case 'Lawyers':
                if (request('desg')) {
                    $data = $this->database->getReference('Segmentations/Lawyers/'.request('desg').'/Peoples/'.$id)->remove();
                    return back()->with(['a.toast'=>'People deleted successfully', 'time'=>3500]);
                }
                else {
                    $data = $this->database->getReference('Segmentations/Lawyers/'.$id)->remove();
                    return back()->with(['a.toast'=>'Lawyer deleted successfully', 'time'=>3500]);
                }
                break;
            case 'NonLawyers':
                if (request('desg')) {
                    $data = $this->database->getReference('Segmentations/NonLawyers/'.request('desg').'/Peoples/'.$id)->remove();
                    return back()->with(['a.toast'=>'People deleted successfully', 'time'=>3500]);
                }
                else {
                    $data = $this->database->getReference('Segmentations/NonLawyers/'.$id)->remove();
                    return back()->with(['a.toast'=>'Non lawyer deleted successfully', 'time'=>3500]);
                }
                break;
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
}
