<?php

namespace App\Http\Controllers\Admin\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;
use DateTime;

class ListController extends Controller
{
    private $url = 'admin.user.list.';
    private $firebase;

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
        $this->users = $this->database->getReference('Users')->getValue();
    }

    public function index($userStates=[])
    {
        $phone = $this->getPhoneNumbers();
        $users = $this->database->getReference('Users')->getValue();
        $userStates = $this->userStates($users);
        
        $locations = $this->database->getReference('Locations')->getValue();

        return view($this->url.'dashboard',compact('users','phone','locations','userStates'));
    }

    public function show($id)
    {
        $locations = $this->database->getReference('Locations')->getValue();
        $users = $this->database->getReference('Users')->getValue();
        $userStates = $this->userStates($users);
        $ref = 'Users';

        switch ($id) {
            case 'profile':
                $key = request()->input('id');

                if(empty($key)) return view('404');
                $user = $this->database->getReference($ref)->getChild($key)->getValue();
                if(!$user) return view('404');
                return view($this->url.'profile',compact('user','key','locations','userStates')); break;

            case 'reports':
                return view($this->url.'report',compact('locations','userStates')); break;

            default: return view('404'); break;
        }
    }

    public function update(Request $r, $id)
    {
        // return$r;
        $data = [
            'Enrollment_Number' => $r->enrollno,
            'gender' => $r->gender,
            'DOB' => $r->dob,
            'city' => $r->city,
            'address' => $r->area,
            'designation' => $r->designation,
            'email' => $r->email,
        ];

        $user = $this->database->getReference('Users/'.$id)->update($data);
        return redirect('admin/users/list')->with(['a.toast'=>'User updated successfully', 'time'=>3500]);

    }

    public function store(Request $request)
    {
        // return$request;
        foreach($this->users as $key => $user) {
            if( ($this->userId($request,$user)) && ($this->gender($request->gender??'',$user)) && ($this->dob($request,$user)) && ($this->category($request->category??'',$user)) && ($this->designation($request,$user)) ) {
                $Users[$key] = $user;
            }
        }
        if (empty($Users)) $Users='';

        $exportType = ucfirst($request->exportBtn);
        switch ($request->exportBtn) {
            case 'json':
                header('Content-disposition: attachment; filename=Reports.json');
                header('Content-type: application/json');
                echo json_encode($Users);
                return back();
            case 'pdf':
                $heads = ['Enrollment Number','Name','Email','Contact Number','Category','Designation','Gender'];
                $phone = $this->getPhoneNumbers();
                return view('export',compact('exportType','heads','Users','phone'));
                break;
            case 'excel':
                // return Excel::download(new UsersExport, 'reports.xlsx');

                $heads = ['Enrollment Number','Name','Email','Contact Number','Category','Designation','Gender'];
                $phone = $this->getPhoneNumbers();
                // $heads[] = array('Enroll No.','Name','Email','Contact No.','Category','Designation','Gender');
                // foreach ($Users as $Key => $User) {
                //     $heads[] = array(
                //         'Enroll No.' => $User['Enrollment_Number']??'N/A',
                //         'Name' => ($User['first_name'] ?? 'N/A').' '.($User['last_name'] ?? 'N/A'),
                //         'Email' => $User['email']??'N/A',
                //         'Contact No.' => $phone[$Key]??'N/A',
                //         'Category' => $User['category']??'N/A',
                //         'Designation' => $User['designation']??'N/A',
                //         'Gender' => $User['gender']??'N/A',
                //     );
                // }
                // Excel::create('User Reports', function ($excel) use ($heads) {
                //     $excel->setTitle('User Reports');
                //     $excel->sheet('User Reports', function ($sheet) use ($heads){
                //         $sheet->fromArray($heads,null,'A1',false,false);
                //     });
                // })->download('xlsx');
                return view('export',compact('exportType','heads','Users','phone'));
                // return $this->tableExcel($Users);
                break;

            default: return view('404');
        }
    }

    public static function userStates($users, $userStates=[])
    {
        foreach ($users as $key => $user) {
            if( isset($user['state']) ) {
                if ( !in_array( ucfirst($user['state']), $userStates )) {
                    $userStates[] = ucfirst($user['state']);
                }
            }
        }
        return$userStates??null;
    }

    public function tableExcel($users)
    {
        header("Content-Type: application/excel");
        header("Content-Disposition: attachment; filename=
            download.xls");
        if ($users!='') 
        {
            $table='
            <table class"table" border="1">
                <tr>
                    <th>Enroll No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact No.</th>
                    <th>Category</th>
                    <th>Designation</th>
                    <th>Gender</th>
                </tr>';
            foreach ($users as $key => $user) {
                $table.='
                    <tr>
                        <td>'.$user['Enrollment_Number'].'</td>
                        <td>'.($user['first_name'] ?? 'N/A').' '.($user['last_name'] ?? 'N/A').'</td>
                        <td>'.$user['email'].'</td>
                        <td>'.$this->getPhoneNumbers($key)??'N/A'.'</td>
                        <td>'.$user['category']??'N/A'.'</td>
                        <td>'.$user['designation']??'N/A'.'</td>
                        <td>'.$user['gender']??'N/A'.'</td>
                    </tr>
                ';
            }
            $table.='</table>';
        }
        echo $table;
        // exit();
    }

    public function getPhoneNumbers($id=null)
    {
        $auth = $this->firebase->getAuth();
        $users=$auth->listUsers();
        foreach ($users as $user => $value) {
            $phone[$value->uid]=$value->phoneNumber;
        }
        if($id==null)
        return $phone;
        else return $phone[$id]??'N/A';
    }

    public function userId($r,$user)
    {   
        if(empty($r->fromUserId && $r->toUserId)) return true;

        if(($user['Enrollment_Number']??'')>=$r->fromUserId && ($user['Enrollment_Number']??'')<=$r->toUserId) {
            return true;
        }
        return false;
    }

    public function gender($gender,$user)
    {
        if(empty($gender)) return true;

        if(isset($user['gender'])) {
            if( (ucfirst($user['gender'])==($gender[0]??'')) || (ucfirst($user['gender'])==($gender[1]??'')) || (ucfirst($user['gender'])==($gender[2]??'')) )
                return true;
        }
        return false;
    }

    public function dob($r,$user)
    {
        if(empty($r->fromDob && $r->toDob)) return true;

        if (isset($user['DOB'])) {
            $from = new DateTime( date("d-m-Y", strtotime($r->fromDob)) );
            $to = new DateTime( date("d-m-Y", strtotime($r->toDob)) );
            $dob = new DateTime( str_replace('/','-',$user['DOB']) );

            if( $from <= $dob && $dob <= $to) return true;
        }
        return false;
    }

    public function category($category,$user)
    {
        if(empty($category)) return true;

        if(isset($user['category'])) {
            if($category[0]=='Non lawyer') {
                if (ucfirst($user['category'])!='Lawyer')
                    return true;
            }
            elseif( isset($category[0]) && empty($category[1]) ) {
                if( ucfirst($user['category'])=='Lawyer' )
                    return true;
            }
            else {
                if( (ucfirst($user['category'])==($category[0]??'')) || (ucfirst($user['category'])!=($category[1]??'')) )
                    return true;
            }
        }
        return false;
    }

    public function designation($request,$user)
    {
        $des = $request->designation;
        if (empty($des)) return true;
        
        if (isset($user['designation'])) {
            $udesg = strtolower($user['designation']);
            if ( $udesg==($des[0]??'') || $udesg==($des[1]??'') )
                return true;
        }
        return false;
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
