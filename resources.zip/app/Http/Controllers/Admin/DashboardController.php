<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Database;
use Kreait\Firebase\Storage;
use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas;
use \App\Http\Controllers\Admin\User\ListController as UClas;

class DashboardController extends Controller
{
    private $url = 'admin.dashboard.';
    protected $database;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
    }

    public function index()
    {
        return redirect(route('dashboard.show',1));
    }

    public function show($id)
    {
        $locations = $this->database->getReference('Locations')->getValue();
        $users = $this->database->getReference('Users')->getValue();
        $userStates = UClas::userStates($users);
        $all = $this->database->getReference('/')->getValue();
        switch ($id) {
            case 1: return view($this->url.'1',compact('all','locations','userStates'));

            case 4: return view($this->url.'4',compact('all','locations','userStates'));

            case 5: return view($this->url.'5',compact('all','locations','userStates'));

            case 6: return view($this->url.'6',compact('all','locations','userStates'));

            case 7: return view($this->url.'7',compact('all','locations','userStates'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
