<?php

namespace App\Http\Controllers\Admin\Transaction;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use DateTime;

class PrintPartnerController extends Controller
{
    private $url = 'admin.transaction.printpartner.';
    private $firebase;

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
    }

    public function index()
    {
        $printpartners = $this->database->getReference('Printing_partner')->getValue();
        return view($this->url.'dashboard', compact('printpartners'));
    }

    public function show($id)
    {
        switch ($id) {
            case 'transact':
                $key = request()->input('id');

                if(empty($key)) return view('404');
                $printpartner = $this->database->getReference('Printing_partner')->getChild($key)->getValue();
                if(!$printpartner) return view('404');
                return view($this->url.'transact', compact('printpartner')); break;

            case 'reports':
                return view($this->url.'report'); break;
            default: return view('404');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
