<?php

namespace App\Http\Controllers\Admin\Operation;

use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;
use Validator;

class SubAdminController extends Controller
{
    private $url = 'admin.operation.subadmin.';
    private $firebase;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
    }

    public function index()
    {
        $auth = $this->firebase->getAuth();
        $users = $auth->listUsers();
        $all=null;
        foreach($users as $user => $value){
            // if($value->customAttributes!=null){
                // if (isset($value->customAttributes['subadmin'])) {
                $all[$value->uid] = $value;
                // }
            // }
        }
        // return$all;
        $subadmins = $this->database->getReference('SubAdmins')->getValue();
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'dashboard', compact('subadmins','locations','all'));
    }

    public function show($id)
    {
        $users = $this->database->getReference('Users')->getValue();
        $pps = $this->database->getReference('Printing_partner')->getValue();
        $userStates = $this->userStates($users,$pps);
        $userCities = $this->userCities($users,$pps);
        $locations = $this->database->getReference('Locations')->getValue();

        switch ($id) {
            case 'add':
                return view($this->url.'add', compact('locations','userStates')); break;

            case 'edit':
                $key = request()->input('id');

                if(empty($key)) return view('404');
                try {
                    $user = $this->firebase->getAuth()->getUser($key);
                } catch (\Kreait\Firebase\Exception\Auth\UserNotFound $e) {
                    return view('404');
                }

                $subadmin = $this->database->getReference('SubAdmins/'.$key)->getValue();
                return view($this->url.'edit', compact('locations','userStates','userCities','subadmin','user')); break;

            case 1:
                return $this->multiStateAjax( request('state') ); break;

            case 2:
                return $this->multiCityAjax( request('state'), request('district'), request('city') ); break;

            default:  return view('404'); break;
        }
    }

    public function store(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'username'   => 'required|email|regex:/(.*)@lawnics\.com/i',
            'password' => 'required|confirmed|min:6',
            'name' => 'required',
            'role' => 'required',
        ],
        [
            'username.regex' => 'Email format should be username@lawnics.com',
            'username.required' => 'Please enter an Email!',
            'password.required' => 'Please enter a Password!',
            'password.confirmed' => "Password doesn't match!",
            'name' => 'Please enter a Name!',
            'role' => 'Please enter a Role!',
        ] );

        if($validate->fails())
        {
            return back()->withInput($request->except('password,password_confimation'))->withErrors($validate);
        }

        $auth = $this->firebase->getAuth();
        try{
            $user = $auth->createUserWithEmailAndPassword($request->username,$request->password);
        } catch (\Kreait\Firebase\Exception\Auth\EmailExists $e) {
            return back()->withInput($request->except('password,password_confimation'))->withErrors(['username'=>"User with this email already exists!"]);
        } catch (\Kreait\Firebase\Exception\Auth\AuthError $e) {
            return back()->withInput($request->except('password,password_confimation'))->withErrors(['username'=>"Please enter correct email!"]);
        }

        $auth->updateUser($user->uid, ['displayName' => $request->name]);
        
        $data = $this->setData($request);

        // $updatedUser = $auth->setCustomUserAttributes($user->uid, $data);
        $data = $this->database->getReference('SubAdmins/'.$user->uid)->set($data);
        return redirect('admin/operations/subadmin')->with(['a.toast'=>'Sub admin '.$request->role.' ('.$request->username.') created successfully', 'time'=>4500]);
    }

    public function update(Request $request, $id)
    {
        $validate = Validator::make($request->all(), [
            // 'username'   => 'required|email',
            // 'password' => 'required|confirmed|min:6',
            'name' => 'required',
            'role' => 'required',
        ],
        [
            // 'username.required' => 'Please enter an Email!',
            // 'password.required' => 'Please enter a Password!',
            // 'password.confirmed' => "Password doesn't match!",
            'name' => 'Please enter a Name!',
            'role' => 'Please enter a Role!',
        ] );

        if($validate->fails())
        {
            return back()->withInput($request->except('password,password_confimation'))->withErrors($validate);
        }

        $auth = $this->firebase->getAuth();
        $user = $auth->getUser($id);

        $auth->updateUser($user->uid, ['displayName' => $request->name]);

        $data = $this->setData($request);

        // $updatedUser = $auth->setCustomUserAttributes($id, $data);
        $data = $this->database->getReference('SubAdmins/'.$id)->update($data);

        return redirect('admin/operations/subadmin')->with(['a.toast'=>'Sub admin '.$request->role.' updated successfully', 'time'=>4500]);
    }

    public function destroy($id)
    {
        $this->firebase->getAuth()->deleteUser($id);
        return redirect('admin/operations/subadmin')->with(['a.toast'=>'Sub admin deleted successfully', 'time'=>3500]);
    }

    private function setData($request)
    {
        $customAttributes = [
            'statePermi' => $request->statePermi,
            'cityPermi' => $request->cityPermi,
            'areaPermi' => $request->areaPermi,
            'userPermi' => $request->userPermi,
            'ppPermi' => $request->ppPermi,
            'dpPermi' => $request->dpPermi,
            'uxPermi' => $request->uxPermi,
            'operationPermi' => $request->operationPermi,
            'salesPermi' => $request->salesPermi,
            'transactionPermi' => $request->transactionPermi,
            'spPermi' => $request->spPermi,
            'amPermi' => $request->amPermi,
        ];
        return $data = [
            'permissions' => $customAttributes,
            'role'=>$request->role,
            'subadmin'=>true,
            'email'=>$request->email,
            'gender'=>$request->gender,
            'address'=>$request->address,
            'dob'=>$request->dob,
            'idnumber'=>$request->idnumber,
        ];
    }

    public static function userStates($users, $pps, $userStates=[])
    {
        foreach ($users as $key => $user) {
            if( isset($user['state']) ) {
                if ( !in_array( ucfirst($user['state']), $userStates )) {
                    $userStates[] = ucfirst($user['state']);
                }
            }
        }
        foreach ($pps as $key => $pp) {
            if( isset($user['state']) ) {
                if ( !in_array( ucfirst($pp['state']), $userStates )) {
                    $userStates[] = ucfirst($pp['state']);
                }
            }
        }
        return$userStates??null;
    }
    public static function userCities($users, $pps, $userCities=[])
    {
        foreach ($users as $key => $user) {
            if( isset($user['city']) ) {
                if ( !in_array( ucfirst($user['city']), $userCities )) {
                    $userCities[] = ucfirst($user['city']);
                }
            }
        }
        foreach ($pps as $key => $pp) {
            if( isset($user['city']) ) {
                if ( !in_array( ucfirst($pp['city']), $userCities )) {
                    $userCities[] = ucfirst($pp['city']);
                }
            }
        }
        return$userCities??null;
    }
    /**
        __Ajax requests__
    **/
    private function multiStateAjax($State='', $Data='')
    {
        if ($State=='') return $Data=0;

        for ($i=0; $i < count($State); $i++) { 
            $Data .= $this->stateCityAjax($State[$i]);
        }
        return $Data;
    }
    private function stateCityAjax($State, $data='')
    {
        if ($State) {
            $districts = $this->database->getReference('Locations/'.$State)->getValue();
            $data.='<optgroup label="'.$State.'">';
            if(count($districts)>0) {
                foreach ($districts as $district => $d) {
                    if(Clas::isPlace($district)) {
                        foreach ($d as $city => $areabase) {
                            if(Clas::isPlace($city))
                            $data .= '<option state="'.$State.'">'.$city.' - '.$district.'</option>';
                        }
                    }
                }
                return $data.='</optgroup>';
            }
            else return $data='';
        } else return $data='';
    }

    private function multiCityAjax($State, $District, $City, $Data='')
    {
        if ($State=='') return null;

        for ($i=0; $i < count($State); $i++) { 
            for ($j=0; $j < count($District); $j++) { 
                for ($k=0; $k < count($City); $k++) { 
                    if ($this->database->getReference('Locations/'.$State[$i].'/'.$District[$j].'/'.$City[$k])->getValue()!=null) {
                        $Data .='<optgroup label="'.$City[$k].' - '.$District[$j].'">';
                        $Data .= $this->stateAreaAjax($State[$i], $District[$j], $City[$k]);
                        $Data .='</optgroup>';
                    }
                }
            }
        }
        return $Data;
    }
    private function stateAreaAjax($State, $District, $City, $data='')
    {
        $city = $this->database->getReference('Locations/'.$State.'/'.$District.'/'.$City)->getValue();
        if(count($city)>0) {
            
            foreach ($city as $key => $area) {
                if( Clas::isPlace($key) )
                $data .= '<option state="'.$State.'" district="'.$District.'" city="'.$City.'" value="'.$key.'">'.$area['area'].'</option>';
            }
            return $data;
        }
        else return $data='';
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

}
