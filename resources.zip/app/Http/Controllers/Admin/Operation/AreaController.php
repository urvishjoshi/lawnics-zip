<?php

namespace App\Http\Controllers\Admin\Operation;

use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Validator;

class AreaController extends Controller
{
    private $url = 'admin.operation.area.', $database, $ref, $data,$validate;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
    }

    public function index()
    {
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'dashboard',compact('locations'));
    }

    public function show($id)
    {
        switch ($id) {
            case 'add':
                return view($this->url.'add'); break;

            case 'edit':
                $id = request()->input('id');

                if(empty($id)) return view('404');
                $state = $this->database->getReference('Locations')->getValue();
                foreach ($state as $s => $district) {
                    if(Clas::isPlace($s)){
                    foreach ($district as $d => $city) {
                        if(Clas::isPlace($d)){
                        foreach ($city as $c => $areabase) {
                            if(Clas::isPlace($c)){
                            foreach ($areabase as $key => $area) {
                                if(Clas::isPlace($key)){
                                    if($key==$id) {
                                        $area['key']=$key;
                                        $area['district']=$d;
                                        $area['city']=$c;
                                        $area['state']=$s;
                                        return view($this->url.'edit',compact('area')); break;
                                    } else
                                        continue;
                                }
                            }
                            }
                        }
                        }
                    }
                    }
                }
                return view('404');

            default : return view('404');
        }
    }

    public function store(Request $r)
    {

        if($this->validateAreaData($r)->fails())
            return back()->withInput($r->all())->withErrors($this->validate);
        if ($r->polygonCoords==null)
            return back()->withInput($r->all())->with(['a.toast'=>'Please Insert a Polygon!', 'time'=>10000]);
        if ($r->markerCoords==null)
            return back()->withInput($r->all())->with(['a.toast'=>'Please Place a Marker!', 'time'=>10000]);
        if ( !(Clas::isPlace($r->state) && Clas::isPlace($r->district) && Clas::isPlace($r->area)) )
            return back()->withInput($r->all())->with(['a.toast'=>"Locations shouldn't be any of these: Storages, Packages, Subscriptions, Papers", 'time'=>10000]);
        
        $this->areaData($r);

        $data = $this->database->getReference($this->ref)->push($this->data);

        return redirect('admin/operations/areas')->with(['a.toast'=>'Area: '.$r->state.' -> '.$r->district.' -> '.$r->city.' -> '.$r->area.' added successfully', 'time'=>5000]);
    }

    public function update(Request $request, $id)
    {
        if($this->validateAreaData($request)->fails())
            return back()->withInput($request->all())->withErrors($this->validate);
        $this->areaData($request);

        $data = $this->database->getReference($this->ref.$id)->update($this->data);

        return redirect('admin/operations/areas')->with(['a.toast'=>'Area: '.$request->state.' -> '.$request->district.' -> '.$request->city.' -> '.$request->area.' updated successfully', 'time'=>5000]);
    }

    public function validateAreaData($request)
    {
        $this->validate = Validator::make($request->all(), [
            'state'   => 'required',
            'district'   => 'required',
            'city'   => 'required',
            'area'   => 'required',
            'zoom' => 'required',
        ],
        [
            'state.required' => 'Please enter State name!',
            'district.required' => 'Please enter District!',
            'city.required' => 'Please enter City!',
            'area.required' => 'Please enter Area!',
            'zoom.required' => 'Please enter Zoom level!',
        ] );
        return $this->validate;
    }

    public function areaData($request)
    {
        $polygon = $request->polygonCoords;
        $array = explode(',', $polygon);
        for ($i=0,$j=0; $i < count($array); $i=$i+2,$j++) { 
            $polygonCoords[$j]=[(float)$array[$i],(float)$array[$i+1]];
        }

        $marker = $request->markerCoords;
        $array = explode(',', $marker);
        for ($i=0,$j=0; $i < count($array) ; $i=$i+2,$j++) { 
            $center[$j]=[(float)$array[$i],(float)$array[$i+1]];
        }
        
        $this->ref = 'Locations/'.ucfirst(strtolower($request->state)).'/'.ucfirst(strtolower($request->district)).'/'.ucfirst(strtolower($request->city)).'/';

        $this->data = [
            'area' => ucfirst($request->area),
            'polygonCoords' => $polygonCoords,
            'zoom' => (integer)$request->zoom,
            'center' => $center
        ];
    }

    public function destroy($id)
    {
        $ref = 'Locations/'.request()->state.'/'.request()->district.'/'.request()->city.'/';

        $data = $this->database->getReference($ref.$id)->remove();
        return back()->with(['a.toast'=>'Area '.request()->area.' deleted successfully', 'time'=>3500]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
}
