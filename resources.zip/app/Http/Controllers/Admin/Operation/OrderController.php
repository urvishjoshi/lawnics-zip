<?php

namespace App\Http\Controllers\Admin\Operation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use App\Http\Controllers\Admin\User\ListController as UClas;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Validator;

class OrderController extends Controller
{
    private $url = 'admin.operation.order.';
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
        $this->auth = $firebase->getAuth();
    }

    public function index()
    {
        $users = $this->database->getReference('Users')->getValue();
        $userStates = Uclas::userStates($users);
        return view($this->url.'dashboard',compact('users','userStates'));
    }

    public function show($id)
    {
        switch ($id) {
            case 'add':
                return view($this->url.'profile'); break;

            case 'reports':
                return view($this->url.'report'); break;
                
            case 'order':
                if(empty($id = request('id'))) return view('404');
                $users = $this->database->getReference('Users')->getValue();
                foreach($users as $key => $user){
                    if(isset($user['orders'])){
                        foreach($user['orders'] as $date => $t){
                            foreach($t as $time => $oid){
                                foreach($oid as $orderId => $order){
                                    if ($orderId==request('id')) {
                                        $phone = $this->getPhoneNumbers($key);
                                        return view($this->url.'order',compact('order','id','date','time','user','key','phone'));
                                    } else
                                        continue;
                                }
                            }
                        }
                    }
                }
                return view('404');
            default : return view('404');
        }
    }
    public function getPhoneNumbers($id=null)
    {

        $users=$this->auth->listUsers();
        foreach ($users as $user => $value) {
            $phone[$value->uid]=$value->phoneNumber;
        }
        if($id==null)
        return $phone;
        else return $phone[$id];
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
