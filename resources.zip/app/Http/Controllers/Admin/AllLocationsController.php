<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Database;
use Kreait\Firebase\Storage;
use \App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas;

class AllLocationsController extends Controller
{
    protected $database;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
    }
    public function show($id)
    {
        switch ($id) {
            case 1: return $this->multiStateAjax( request('state') ,'',1);
            case 1.2: return $this->multiStateAjax( request('state') ,'',1.2);
            case 1.5: return $this->multiStateAjax( request('state') ,'',1.5);
            case 2: return $this->multiDistrictAjax( request('state'),request('district') );
            case 3: return $this->multiCityAjax( request('state'),request('district'),request('city') );
            default:return;
        }
    }

    /*  
        __District__  
    */
    public function multiStateAjax($State='', $Data='',$chk)
    {
        if ($State=='') return $Data=0;

        for ($i=0; $i < count($State); $i++) { 
            if ($chk==1) $Data .= $this->userDistrictAjax($State[$i]);
            elseif($chk==1.2) $Data .= $this->userCityAjax($State[$i]);
            else $Data .= $this->districtAjax($State[$i]);
        }
        return $Data;
    }
    public function userCityAjax($State, $data='')
    {
        if ($State) {
            $users = $this->database->getReference('Users')->getValue();
            $pps = $this->database->getReference('Printing_partner')->getValue();
            $data.='<optgroup label="'.$State.'">';
            if(count($users)>0) {
                foreach ($users as $key => $user) {
                    if(isset($user['state']) && ucfirst($user['state'])==$State) {
                        if (!strpos($data, ucfirst($user['city']))) {
                            $data .= '<option>'.ucfirst($user['city']).'</option>';
                        }
                    }
                }
            }
            if(count($pps)>0) {
                foreach ($pps as $key => $pp) {
                    if(isset($pp['state']) && ucfirst($pp['state'])==$State) {
                        if (!strpos($data, ucfirst($pp['city']))) {
                            $data .= '<option>'.ucfirst($pp['city']).'</option>';
                        }
                    }
                }
                return $data.='</optgroup>';
            }
            else return $data='';
        } else return $data='';
    }
    public function userDistrictAjax($State, $data='')
    {
        if ($State) {
            $users = $this->database->getReference('Users')->getValue();
            $data.='<optgroup label="'.$State.'">';
            if(count($users)>0) {
                foreach ($users as $key => $user) {
                    if(isset($user['state']) && ucfirst($user['state'])==$State) {
                        if (!strpos($data, ucfirst($user['city']))) {
                            $data .= '<option>'.ucfirst($user['city']).'</option>';
                        }
                    }
                }
                return $data.='</optgroup>';
            }
            else return $data='';
        } else return $data='';
    }
    public function districtAjax($State, $data='')
    {
        if ($State) {
            $districts = $this->database->getReference('Locations/'.$State)->getValue();
            $data.='<optgroup label="'.$State.'">';
            if(count($districts)>0) {
                foreach ($districts as $district => $d) {
                    if(Clas::isPlace($district)) {
                        $data .= '<option>'.$district.'</option>';
                    }
                }
                return $data.='</optgroup>';
            }
            else return $data='';
        } else return $data='';
    }

    /*  
        __City__  
    */
    public function multiDistrictAjax($State='', $District='', $Data='')
    {
        if ($State=='') return $Data=0;

        for ($i=0; $i < count($State); $i++) { 
            for ($j=0; $j < count($District); $j++) { 
                if ($this->database->getReference('Locations/'.$State[$i].'/'.$District[$j])->getValue()!=null) {
                    $Data .= $this->cityAjax($State[$i], $District[$j]);
                }
            }
        }
        return $Data;
    }
    public function cityAjax($State, $District='', $data='')
    {
        if ($State) {
            $cities = $this->database->getReference('Locations/'.$State.'/'.$District)->getValue();
            $data.='<optgroup label="'.$District.' - '.$State.'">';
            if(count($cities)>0) {
                foreach ($cities as $city => $areabase) {
                    if(Clas::isPlace($city)) {
                        $data .= '<option state="'.$State.'">'.$city.'</option>';
                    }
                }
                return $data.='</optgroup>';
            }
            else return $data='';
        } else return $data='';
    }

    /*  
        __Area__  
    */
    public function multiCityAjax($State, $District, $City, $Data='')
    {
        if ($State=='') return null;

        for ($i=0; $i < count($State); $i++) { 
            for ($j=0; $j < count($District); $j++) { 
                for ($k=0; $k < count($City); $k++) { 
                    if ($this->database->getReference('Locations/'.$State[$i].'/'.$District[$j].'/'.$City[$k])->getValue()!=null) {
                        $Data .='<optgroup label="'.$City[$k].' - '.$District[$j].'">';
                        $Data .= $this->areaAjax($State[$i], $District[$j], $City[$k]);
                        $Data .='</optgroup>';
                    }
                }
            }
        }
        return $Data;
    }
    public function areaAjax($State, $District, $City, $data='')
    {
        $city = $this->database->getReference('Locations/'.$State.'/'.$District.'/'.$City)->getValue();
        if(count($city)>0) {
            
            foreach ($city as $key => $area) {
                if( Clas::isPlace($key) )
                $data .= '<option state="'.$State.'" district="'.$District.'" city="'.$City.'" value="'.$key.'">'.$area['area'].'</option>';
            }
            return $data;
        }
        else return $data='';
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
