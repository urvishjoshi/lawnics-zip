<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Database;
use Kreait\Firebase\Storage;

class PermiController extends Controller
{
    public static function data()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/firebaseKey.json');
        return $data = $firebase= (new Factory)->withServiceAccount($serviceAccount)->create()->getDatabase()
        				->getReference('SubAdmins/'.session('admin_session')->uid)->getValue();
    }
    /*
        Sidebar role managemnet
    */
    public static function userLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['userPermi']) ) return true;
            else return false;
            case 'List':
            for ($i=0; $i < count($data['permissions']['userPermi']); $i++)
                if($data['permissions']['userPermi'][$i]==$link) return true;
            return false;
            case 'Segmentation':
            for ($i=0; $i < count($data['permissions']['userPermi']); $i++)
                if($data['permissions']['userPermi'][$i]==$link) return true;
            return false;
            default: return false;
        }
    }
    public static function ppLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['ppPermi']) ) return true;
            else return false;
            default: return false;
        }
    }
    public static function operationLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['operationPermi']) ) return true;
            else return false;
            case 'Area':
            for ($i=0; $i < count($data['permissions']['operationPermi']); $i++)
                if($data['permissions']['operationPermi'][$i]==$link) return true;
            return false;
            case 'Subadmin':
            for ($i=0; $i < count($data['permissions']['operationPermi']); $i++)
                if($data['permissions']['operationPermi'][$i]==$link) return true;
            return false;
            case 'Order':
            for ($i=0; $i < count($data['permissions']['operationPermi']); $i++)
                if($data['permissions']['operationPermi'][$i]==$link) return true;
            return false;
            default: return false;
        }
    }
    public static function salesLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['salesPermi']) ) return true;
            else return false;
            default: return false;
        }
    }
    public static function transactionLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['transactionPermi']) ) return true;
            else return false;
            case 'User':
            for ($i=0; $i < count($data['permissions']['transactionPermi']); $i++)
                if($data['permissions']['transactionPermi'][$i]==$link) return true;
            return false;
            case 'Printing partner':
            for ($i=0; $i < count($data['permissions']['transactionPermi']); $i++)
                if($data['permissions']['transactionPermi'][$i]==$link) return true;
            return false;
            case 'Delivery partner':
            for ($i=0; $i < count($data['permissions']['transactionPermi']); $i++)
                if($data['permissions']['transactionPermi'][$i]==$link) return true;
            return false;
            default: return false;
        }
    }
    public static function spLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['spPermi']) ) return true;
            else return false;
            case 'Service':
            for ($i=0; $i < count($data['permissions']['spPermi']); $i++)
                if($data['permissions']['spPermi'][$i]==$link) return true;
            return false;
            case 'Timeslot':
            for ($i=0; $i < count($data['permissions']['spPermi']); $i++)
                if($data['permissions']['spPermi'][$i]==$link) return true;
            return false;
            case 'Paper size & Quality':
            for ($i=0; $i < count($data['permissions']['spPermi']); $i++)
                if($data['permissions']['spPermi'][$i]==$link) return true;
            return false;
            default: return false;
        }
    }
    public static function amLink($link='', $data)
    {
        if (isset($data['admin'])) return true;

        switch ($link) {
            case '':
            if ( isset($data['permissions']['amPermi']) ) return true;
            else return false;

            case 'Advocate - About':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case 'Advocate - Privacy Policy':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case 'Advocate - Terms & Policy':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case "Advocate - FAQ's":
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;

            case 'Printing Partner - About':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case 'Printing Partner - Privacy Policy':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case 'Printing Partner - Terms & Policy':
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            case "Printing Partner - FAQ's":
            for ($i=0; $i < count($data['permissions']['amPermi']); $i++)
                if($data['permissions']['amPermi'][$i]==$link) return true;
            return false;
            default: return false;
        }
    }
}
