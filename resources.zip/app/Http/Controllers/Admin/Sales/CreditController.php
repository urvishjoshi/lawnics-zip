<?php

namespace App\Http\Controllers\Admin\Sales;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Admin\User\ListController as UClas;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Illuminate\Http\Request;

class CreditController extends Controller
{
    private $url = 'admin.sales.credits.';
    protected $database;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
    }
    
    public function index()
    {
        $users = $this->database->getReference('Users')->getValue();
        $userStates = Uclas::userStates($users);
        return view($this->url.'dashboard',compact('users','userStates'));
    }

    public function show($id)
    {
        $users = $this->database->getReference('Users')->getValue();
        $userStates = Uclas::userStates($users);
        switch ($id) {
            case 'profile':
                if(empty($id)) return view('404');
                $uId = request('id');
                $user = $this->getUser($uId);
                if(!$user) return view('404');
                return view($this->url.'profile',compact('user','uId','userStates')); break;

            case 'reports':
                return view($this->url.'report','userStates'); break;
        }
    }

    public function getUser($id=null)
    {
        $users = $this->database->getReference('Users')->getValue();
        foreach ($users as $key => $user) {
            if ($id==$key) {
                $phone[$key]=$user;
                return $phone;
            }
        }
        return false;
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
