<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Model\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;
use Session;
use Auth;

class AuthController extends Controller
{
	private $firebase;
	public function __construct()
    {
        $this->middleware('guest:role')->except('logout');

		$serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/firebaseKey.json');
		$this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
		$this->database = $this->firebase->getDatabase();
    }

	public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
	{

	    $validate = Validator::make($request->all(), [
	        'email'   => 'required|email',
	        'password' => 'required|min:6'
	    ],
    	[
    		'email.required' => 'Please enter a Username!',
    		'password.required' => 'Please enter a Password!',
    	] );

	    if($validate->fails())
		{
			return back()->withInput($request->only('email', 'remember'))->withErrors($validate);
		}

	    if ($auth = $this->firebase->getAuth()) {
	    	
			// $auth = $this->firebase->getAuth();
			try {
			    $user = $auth->verifyPassword($request->email, $request->password);
			    Session::put('admin_session',$user);
		        return redirect('admin/dashboard/1');
			}
			catch (\Kreait\Firebase\Exception\Auth\InvalidPassword $e) {
			    return back()->withInput($request->only('email'))->withErrors(['password'=>'Wrong password!']);
			}
			catch (\Kreait\Firebase\Auth\SignIn\FailedToSignIn $e) {
			    return back()->withInput($request->only('email'))->withErrors(['email'=>"Username doesn't exists"]);
		    }
	    }
	    return back()->withInput($request->only('email'))->withErrors(['password'=>'Someting went wrong!']);
	}

	public function logout(Request $request)
    {

        $request->session()->forget('admin_session');

        return redirect()->route('login');
    }
}
