<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Operation\SubAdminController as SAClas;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Auth\UserRecord;
use Kreait\Firebase\Database;
use Kreait\Firebase\Storage;

class LocationPermiController extends Controller
{
	public static function data()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/firebaseKey.json');
        return $data = $firebase= (new Factory)->withServiceAccount($serviceAccount)->create()->getDatabase()
                        ->getReference('SubAdmins/'.session('admin_session')->uid)->getValue();
    }

    public static function userStatePermi($state='', $data, $flag=false)
    {
        if (isset($data['admin'])) return true;
        if (empty($data['permissions']['statePermi'])) return false;

        for ($i=0; $i < count($data['permissions']['statePermi']); $i++)
	        if($data['permissions']['statePermi'][$i]==ucfirst($state))
	        	$flag=true;
		return $flag;
    }
	public static function userCityPermi($state='', $data, $flag=false)
    {
        if (isset($data['admin'])) return true;
        if (empty($data['permissions']['cityPermi'])) return false;

        for ($i=0; $i < count($data['permissions']['cityPermi']); $i++)
	        if($data['permissions']['cityPermi'][$i]==ucfirst($state))
	        	$flag=true;
		return $flag;
    }
}
