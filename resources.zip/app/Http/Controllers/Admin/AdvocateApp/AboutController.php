<?php

namespace App\Http\Controllers\Admin\AdvocateApp;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;

class AboutController extends Controller
{
    private $url = 'admin.advocateapp.about';
    private $firebase;

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
    }

    public function index()
    {
        $about = $this->database->getReference('AdvocateApp/About')->getValue();

        return view($this->url,compact('about'));
    }

    public function store(Request $request)
    {
        $data = [
            'htmlText' => $request->about,
        ];

        $data = $this->database->getReference('AdvocateApp/About')->set($data);
        return back()->with(['a.toast'=>'About updated successfully', 'time'=>3500]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
