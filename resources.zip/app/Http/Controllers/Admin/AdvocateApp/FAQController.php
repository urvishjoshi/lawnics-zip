<?php

namespace App\Http\Controllers\Admin\AdvocateApp;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;

class FAQController extends Controller
{
    private $url = 'admin.advocateapp.faq.';
    private $firebase;

    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
    }

    public function index()
    {
        $faqs = $this->database->getReference('FAQ')->getValue();
        $faqsH = $this->database->getReference('FAQH')->getValue();
        return view($this->url.'dashboard',compact('faqs','faqsH'));
    }

    public function show($id)
    {

        switch ($id) {
            case 'add':
                return view($this->url.'add'); break;

            case 'edit':
                if (($faq['lang'] = request('lang')=='English')) $ref = 'FAQ/'; else $ref = 'FAQH/';
                                    
                if(empty(request('id'))) return view('404');
                $data = $this->database->getReference($ref.'/'.request('id'))->getValue();
                if(!$data) return view('404');

                $faq['heading'] = request('id');
                $faq['question'] = array_keys($data)[0];
                $faq['answer'] = $data[$faq['question']];

                return view($this->url.'edit',compact('faq','id')); break;

            default: return view('404'); break;
        }
    }

    public function store(Request $request)
    {
        if($request->language=='English') $ref = 'FAQ/'; else $ref = 'FAQH/';
        $query = $this->database->getReference($ref.$request->heading)->set($this->data($request));
        return redirect()->route('aa.faqs.index')->with(['a.toast'=> $request->heading.' added successfully', 'time'=>4000]);
    }

    public function update(Request $request, $id)
    {
        if($request->language=='English') $ref = 'FAQ/'; else $ref = 'FAQH/';
        $query = $this->database->getReference($ref.$request->heading)->set($this->data($request));
        return redirect()->route('aa.faqs.index')->with(['a.toast'=> $request->heading.' updated successfully', 'time'=>4000]);
    }

    public function destroy($id)
    {
        if($id==1) $ref = 'FAQ/'; else $ref = 'FAQH/';
        $query = $this->database->getReference($ref.'/'.request('heading').'/'.request('question'))->remove();
        return back()->with(['a.toast'=> 'FAQ deleted successfully', 'time'=>3500]);
    }

    public function data($request)
    {
        return $data = [ $request->question => $request->answer ];
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
}
