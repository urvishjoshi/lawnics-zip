<?php

namespace App\Http\Controllers\Admin\ServiceProduct;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Kreait\Firebase\Auth\UserRecord;
use Validator;

class PaperSnQController extends Controller
{
    private $url = 'admin.serviceproduct.paper.',$firebase;
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $this->firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
        $this->database = $this->firebase->getDatabase();
    }

    public function index()
    {
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'dashboard',compact('locations'));
    }

    public function show($id)
    {
        switch ($id) {
            case 'add':
                return view($this->url.'area');

            case 'edit':
                if(empty($id)) return view('404');
                $state = request('state');
                $district = request('district');
                $city = request('city');
                $areaKey = request('areaKey');
                $area = request('area');
                $key = request('editBtn');

                $active = $this->activeLocations($state,$district,$city,$areaKey,$area);
                
                $ref = 'Locations/'.$state.'/'.$district.'/'.$city.'/'.$areaKey.'/Papers/'.$key;
                $paper = $this->database->getReference($ref)->getValue();
                
                return response()->json([ 
                                            'color'=>$paper['color'],
                                            'quality'=>$paper['quality'],
                                            'credits'=>$paper['credits'],
                                            'size'=>$paper['size'],
                                            'pages'=>$paper['pages'],
                                            'rupees'=>$paper['rupees'],
                                            'area'=>$active['area'],
                                            'city'=>$active['city'],
                                            'state'=>$active['state'],
                                        ]);

            case 1:   return $this->stateAjax();
            
            case 2:   return $this->districtAjax();

            case 2.5: return $this->stateCityAjax();

            case 3:   return $this->cityAjax();

            case 3.5: return $this->stateAreaAjax();

            default:  return view('404');
        }
    }


    public function store(Request $r, $msg='')
    {
        // return$r;
        $data = [
            'size' => $r->size,
            'quality' => $r->quality,
            'credits' => (int)$r->credits,
            'color' => $r->color,
            'pages' => (int)$r->pages,
            'rupees' => (int)$r->rupees,
        ];

        // $ref = $this->getRef($r->statePermi,$r->cityPermi,$r->areaPermi);
        if (isset($r->statePermi)) {
            for ($i=0; $i < count($r->statePermi); $i++) { 
                if (empty($r->cityPermi)) {
                    if ($this->database->getReference('Locations/'.$r->statePermi[$i])->getValue()!=null) {
                        $ref= 'Locations/'.$r->statePermi[$i];
                        if (isset($r->updateBtn))
                            $query = $this->database->getReference($ref.'/Papers/'.$r->updateBtn)->set($data);
                        else
                            $query = $this->database->getReference($ref.'/Papers')->push($data);
                        continue;
                    }
                }
                for ($j=0; $j < count($r->cityPermi); $j++) { $cityDis = explode(' - ',$r->cityPermi[$j]);
                    if (empty($r->areaPermi)) {
                        if($this->database->getReference('Locations/'.$r->statePermi[$i].'/'.$cityDis[1].'/'.$cityDis[0])->getValue()!=null) {
                            $ref= 'Locations/'.$r->statePermi[$i].'/'.$cityDis[1].'/'.$cityDis[0];
                            if (isset($r->updateBtn))
                                $query = $this->database->getReference($ref.'/Papers/'.$r->updateBtn)->set($data);
                            else
                                $query = $this->database->getReference($ref.'/Papers')->push($data);
                            continue;
                        }
                    }
                    for ($k=0; $k < count($r->areaPermi); $k++) { 

                        if($this->database->getReference('Locations/'.$r->statePermi[$i].'/'.$cityDis[1].'/'.$cityDis[0].'/'.$r->areaPermi[$k])->getValue()!=null){
                            $ref = 'Locations/'.$r->statePermi[$i].'/'.$cityDis[1].'/'.$cityDis[0].'/'.$r->areaPermi[$k];
                            // if (isset($r->updateBtn)) { 
                                // if( $this->isLocationChanged($r) ) {
                                //     $oldref = 'Locations/'.$r->oldState.'/'.$r->oldDistrict.'/'.$r->oldCity.'/'.$r->oldAreaKey;    $msg = 'location changed and updated';
                                //     $query = $this->database->getReference($oldref.'/Papers/'.$r->addBtn)->set(null);
                                // } else $msg = 'updated';
                                
                                // $query = $this->database->getReference($ref.'/Papers/'.$r->addBtn)->set($data);
                            // }
                            // else
                            if (isset($r->updateBtn))
                                $query = $this->database->getReference($ref.'/Papers/'.$r->updateBtn)->set($data);
                            else
                                $query = $this->database->getReference($ref.'/Papers')->push($data);
                        }

                    }
                }
            }
        } else {
            if(isset($r->updateBtn))
                $query = $this->database->getReference('Locations/Papers/'.$r->updateBtn)->set($data);
            else
                $query = $this->database->getReference('Locations/Papers')->push($data);
        }
        // else return'Locations/';
        // return$ref??'null';

        if (isset($r->updateBtn))
            return back()->with(['a.toast'=>'Paper updated successfully', 'time'=>4000]);
        else
            return back()->with(['a.toast'=>'Paper added successfully', 'time'=>3500]);
    }

    public function destroy($id, $ref='')
    {
        $state = request('deleteState');
        $district = request('deleteDistrict');
        $city = request('deleteCity');
        $areaKey = request('deleteAreaKey');
        $area = request('deleteArea');

        // $ref = 'Locations/'.$state.'/'.$district.'/'.$city.'/'.$areaKey.'/Papers/'.$id;
        if (isset($state)) {
            $ref= $state;
            if (isset($city)) {
                $ref= $state.'/'.$district.'/'.$city;
                if(isset($areaKey)){
                    $ref = $state.'/'.$district.'/'.$city.'/'.$areaKey;
                }
            }

            $data = $this->database->getReference('Locations/'.$ref.'/Papers/'.$id)->remove();
        } else $data = $this->database->getReference('Locations/Papers/'.$id)->remove();
        // $ref = 'Locations/'.$ref.'/Papers/'.$id;
        return back()->with(['a.toast'=>'Paper deleted successfully', 'time'=>3500]);
    }

    private function activeLocations($state, $district, $city, $areaKey, $area)
    {
        if ($state!='') {
            $s=$this->database->getReference('Locations/')->getValue();
            $active['state']='<option value="">-select-</option>';
            foreach ($s as $key => $value) {
                if ($this->isPlace($key)) {
                    if ($key==$state) $active['state'].='<option selected>'.$key.'</option>';
                    else $active['state'].='<option>'.$key.'</option>';
                }
            }
        } else $active['state']='';

        // $d=$this->database->getReference('Locations/'.$state)->getValue();
        // $active['district']='<option value="">-select State-</option>';
        // foreach ($d as $key => $value) {
        //     if ($this->isPlace($key)) {
        //         if ($key==$district) $active['district'].='<option selected>'.$key.'</option>';
        //         else $active['district'].='<option>'.$key.'</option>';
        //     }
        // }
        if ($city!='') {
            $c=$this->database->getReference('Locations/'.$state.'/'.$district)->getValue();
            $active['city']='<option value="">-select District-</option>';
            foreach ($c as $key => $value) {
                if ($this->isPlace($key)) {
                    if ($key==$city) $active['city'].='<option selected>'.$key.' - '.$district.'</option>';
                    else $active['city'].='<option>'.$key.' - '.$district.'</option>';
                }
            }
        } else $active['city']='';

        if ($areaKey!='') {
            $aK=$this->database->getReference('Locations/'.$state.'/'.$district.'/'.$city)->getValue();
            $active['area']='<option value="">-select City-</option>';
            foreach ($aK as $key => $value) {
                if ($this->isPlace($key)) {
                    if ($key==$areaKey) $active['area'].='<option value="'.$key.'" selected>'.$value['area'].'</option>';
                    else $active['area'].='<option value="'.$key.'">'.$value['area'].'</option>';
                }
            }
        } else $active['area']='';

        return $active;
    }

    private function isLocationChanged($req)
    {
        if (($req->state==$req->oldState)&&($req->district==$req->oldDistrict)&&($req->city==$req->oldCity)&&($req->area==$req->oldAreaKey)) return false; else return true;
    }

    ///**** ajax requests ***\\\
    private function stateAjax()
    {
        if (request('state')) {
            $ref = 'Locations/'.request('state');
            $states = $this->database->getReference($ref)->getValue();
            if(count($states)>0) {
                $data='<option value="">-select-</option><option>All</option>';
                foreach ($states as $state => $s) {
                    if($this->isPlace($state))
                    $data = $data.'<option>'.$state.'</option>';
                }
                return $data;
            }
            else return $data=0;
        } else return $data=0;
    }
    private function districtAjax()
    {
        if (request('district')) {
            $ref = 'Locations/'.request('state').'/'.request('district');
            $districts = $this->database->getReference($ref)->getValue();
            if(count($districts)>0) {
                $data='<option value="">-select-</option><option>All</option>';
                foreach ($districts as $district => $d) {
                    if($this->isPlace($district))
                    $data = $data.'<option>'.$district.'</option>';
                }
                return $data;
            }
            else return $data=0;
        } else return $data=0;
    }
    private function stateCityAjax()
    {
        if (request('state')) {
            $ref = 'Locations/'.request('state');
            $districts = $this->database->getReference($ref)->getValue();
            if(count($districts)>0) {
                $data='<option value="">-select-</option><option>All</option>';
                foreach ($districts as $district => $d) {
                    if($this->isPlace($district)) {
                        foreach ($d as $city => $areabase) {
                            if($this->isPlace($district))
                            $data = $data.'<option>'.$city.'</option>';
                        }
                    }
                }
                return $data;
            }
            else return $data='<option value="">-No City found-</option>';
        } else return $data='<option value="">-No City found-</option>';
    }
    private function stateAreaAjax()
    {
        if (request('city')) { $data=0;
            $ref = 'Locations/'.request('state');
            $districts = $this->database->getReference($ref)->getValue();
            if(count($districts)>0) {
                $data='<option value="">-select-</option><option>All</option>';
                foreach ($districts as $district => $d) {
                    if($this->isPlace($district)) {
                        foreach ($d as $city => $areabase) {
                            if ( request('city')==$city && ($this->isPlace($city)) ) {
                                $dataD = $district;
                                foreach ($areabase as $key => $area) {
                                    if($this->isPlace($key))
                                    $data = $data.'<option value="'.$key.'">'.$area['area'].'</option>';
                                }
                            }
                        }
                    }
                }
                return ['data'=>$data,'district'=>$dataD];
            }
            else return $data=0;
        } else return $data=0;
    }
    private function cityAjax()
    {
        if (request('city')) {
            $ref = 'Locations/'.request('state').'/'.request('district').'/'.request('city');
            $cities = $this->database->getReference($ref)->getValue();
            if(count($cities)>0) {
                $data='<option value="">-select-</option><option>All</option>';
                foreach ($cities as $key => $city) {
                    if($this->isPlace($key))
                    $data = $data.'<option value="'.$key.'">'.$city['area'].'</option>';
                }
                return $data;
            }
            else return $data=0;
        } else return $data=0;
    }

    public static function isPlace($place)
    {   $place = ucfirst($place);
        if($place!='Storages' && $place!='Packages' && $place!='Subscriptions' && $place!='Papers') return true;
        else return false;
    }

    public static function isService($service)
    {
        if($service=='Storages') return true; else false;
        if($service=='Subscriptions') return true; else false;
        if($service=='Packages') return true; else false;
    }

    public static function isPaper($paper)
    {
        if($paper=='Papers') return true; else false;
    }

    public static function activePeroid($s)
    {
        $fromD = implode('-', array_reverse(explode('-', $s['fromDate'])));
        $toD = implode('-', array_reverse(explode('-', $s['toDate'])));
        $dataF=$fromD.' & '.$s['fromHour'].':'.$s['fromMinute'].' '.$s['fromTime'];
        $dataT=$toD.' & '.$s['toHour'].':'.$s['toMinute'].' '.$s['toTime'];
        return ($dataF.' - '.$dataT);

    }
    public function update(Request $request, $id)
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
}
