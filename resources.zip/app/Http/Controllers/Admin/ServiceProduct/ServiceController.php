<?php

namespace App\Http\Controllers\Admin\ServiceProduct;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use App\Http\Controllers\Admin\ServiceProduct\PaperSnQController as Clas;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Validator;

class ServiceController extends Controller
{
    private $url = 'admin.serviceproduct.service.';
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
        $this->state='All';
        $this->district='All';
        $this->city='All';
        $this->area='All';
        $this->areaName='All';
    }

    public function index()
    {
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'dashboard',compact('locations'));
    }
    public function update(Request $request, $id)
    {
        $r = request()->all();
        $imageToBeDelete = request('imageToBeDelete');
        $Skey = request('Skey');
        $ref = $this->checkForRef((object)$r);
        $state = $this->state;
        $district = $this->district;
        $city = $this->city;
        $areaKey = $this->area;
        $areaName = $this->areaName;

        $service = $this->database->getReference('Locations/'.$ref.($serviceName=request('serviceName')).'/'.request('Skey'))->getValue();
        if(!$service) return view('404');
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'edit',compact('locations','service','serviceName','imageToBeDelete','Skey','state','district','city','areaKey','areaName'));
    }

    public function store(Request $r)
    {
        // return $r;
        $data = $this->setData($r);          
        $ref  = $this->checkForRef($r);

        if ($r->editBtn) {
            $data = $this->database->getReference('Locations/'.$ref.$r->editBtn.'/'.$r->Skey)->set($data);
        return redirect('admin/sp/services')->with(['a.toast'=>'Service updated successfully', 'time'=>3500]);
        }

        $data = $this->database->getReference('Locations/'.$ref.ucfirst($r->addBtn))->push($data);
        return redirect('admin/sp/services')->with(['a.toast'=>'Service created successfully', 'time'=>3500]);
    }

    public function destroy($id)
    {
        $r = request()->all();
        $Skey = request('Skey');
        $ref = $this->checkForRef((object)$r).request('serviceName').'/'.request('Skey');
        $data = $this->database->getReference('Locations/'.$ref)->remove();
        return redirect('admin/sp/services')->with(['a.toast'=>'Service deleted successfully', 'time'=>3500]);
    }

    public function create()
    {
        if(empty(request('service'))) return view('404');
        $service = request('service');
        if(($service!='storages'&&$service!='subscriptions'&&$service!='packages')) return view('404');
        $locations = $this->database->getReference('Locations')->getValue();

        return view($this->url.'add',compact('service','locations'));
    }

    public function setData($r)
    {
        $data = [
            'name' => $r->name,
            'desc' => $r->desc,
            'image' => $r->imagePath,
            'imageName' => $r->imageName,
            'designation' => $r->designation,
            'category' => $r->category,
            'validity' => (int)$r->validityInDays,
            'price' => (int)$r->price,
            'minAge' => (int)$r->minAge,
            'maxAge' => (int)$r->maxAge,
            'type' => $r->type,
        ];

        if ($r->limited) {
            $data['limit'] = [
                'fromDate' => $r->fromDate,
                'toDate' => $r->toDate,
                'fromTime' => $r->fromTime,
                'toTime' => $r->toTime,
                'fromMinute' => $r->fromMinute,
                'toMinute' => $r->toMinute,
                'fromHour' => $r->fromHour,
                'toHour' => $r->toHour,
            ];
        }
        if ($r->storage) $data['storage'] = (float)$r->storage;
        if ($r->credits) $data['credits'] = (int)$r->credits;
        return $data;
    }
    public function checkForRef($r)
    {
        if ($r->state=='All' || empty($r->state)) { $this->state='All'; return;}
        else { $this->state=$r->state; $ref = $r->state.'/'; }

        if ($r->district=='All' || empty($r->district)) { $this->district='All'; return $ref; }
        else { $this->district=$r->district; $ref.=$r->district.'/'; }

        if ($r->city=='All' || empty($r->city)) { $this->city='All'; return $ref; }
        else { $this->city=$r->city; $ref.=$r->city.'/'; }

        if ($r->area=='All' || empty($r->area)) { $this->area='All'; return $ref; }
        else { $this->areaName=$r->areaName??''; $this->area=$r->area; $ref.=$r->area.'/'; }

        return $ref;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update1(Request $request, $id)
    {
        return$request;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
}
