<?php

namespace App\Http\Controllers\Admin\ServiceProduct;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Database;
use Validator;

class TimeslotController extends Controller
{
    private $url = 'admin.serviceproduct.timeslot.';
    public function __construct()
    {
        $serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/../firebaseKey.json');
        $firebase= (new Factory)->withServiceAccount($serviceAccount)->create();
                                
        $this->database = $firebase->getDatabase();
    }

    public function index()
    {
        $locations = $this->database->getReference('Locations')->getValue();
        return view($this->url.'dashboard',compact('locations'));
    }

    public function show($id)
    {
        switch ($id) {
            case 1:
                $data = [
                    'fromTime' => request('fromTime'),
                    'toTime' => request('toTime'),
                    'fromMinute' => request('fromMinute'),
                    'toMinute' => request('toMinute'),
                    'fromHour' => request('fromHour'),
                    'toHour' => request('toHour'),
                ];

                if (request('addBtn')!=null) {
                    $query = $this->database->getReference('Locations/'.request('addBtn').'/Timeslots/'.request('modalDays'))->push($data);
                    
                    return with(['msg'=>'Timeslot successfully created']);
                }

                $query = $this->database->getReference('Locations/'.request('editBtn'))->set($data);
                return with(['msg'=>'Timeslot successfully updated']);

            case 2:
                $query = $this->database->getReference('Locations/'.request('location').'/Timeslots/'.request('day'))->getValue();
                if($query<1) return 0;
                foreach ($query as $key => $value) {
                    $data[$key]=$value;
                }
                return$data; break;

            case 3:
                $query = $this->database->getReference('Locations/'.request('ref'))->getValue();
                if($query<1) return 0;
                return$query; break;
            
            case 4:
                if(request('ref')!=null){
                    $query = $this->database->getReference('Locations/'.request('ref'))->remove();
                    return 'deleted';
                }
                else return 'cant delete';

            default:
                # code...
                break;
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return $request;
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
